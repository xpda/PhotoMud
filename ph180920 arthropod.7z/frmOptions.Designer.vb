<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmOptions
#Region "Windows Form Designer generated code "
  <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
    MyBase.New()
    'This call is required by the Windows Form Designer.
    InitializeComponent()
  End Sub
  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
    If Disposing Then
      If Not components Is Nothing Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(Disposing)
  End Sub
  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer
  Public ToolTip1 As ToolTip
  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container()
    Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOptions))
    Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
    Me.cmdHelp = New System.Windows.Forms.Button()
    Me.chkViewToolbar = New System.Windows.Forms.CheckBox()
    Me.chkSlideShowName = New System.Windows.Forms.CheckBox()
    Me.chkSlideShowDescription = New System.Windows.Forms.CheckBox()
    Me.chkDateInCommentCommand = New System.Windows.Forms.CheckBox()
    Me.chkZoomOne = New System.Windows.Forms.CheckBox()
    Me.cmdReset = New System.Windows.Forms.Button()
    Me.lbslideRate = New System.Windows.Forms.Label()
    Me.chkShowTips = New System.Windows.Forms.CheckBox()
    Me.cmdToolbar = New System.Windows.Forms.Button()
    Me.cmbButtonSize = New System.Windows.Forms.ComboBox()
    Me.cmdFileAssoc = New System.Windows.Forms.Button()
    Me.nmColorTolerance = New System.Windows.Forms.NumericUpDown()
    Me.chkMultiUndo = New System.Windows.Forms.CheckBox()
    Me.nmSlideFadeTime = New System.Windows.Forms.NumericUpDown()
    Me.Label17 = New System.Windows.Forms.Label()
    Me.nmSlideRate = New System.Windows.Forms.NumericUpDown()
    Me.nmThumbY = New System.Windows.Forms.NumericUpDown()
    Me.nmThumbX = New System.Windows.Forms.NumericUpDown()
    Me.lbThumbY = New System.Windows.Forms.Label()
    Me.lbThumbX = New System.Windows.Forms.Label()
    Me.chkMultiTagPath = New System.Windows.Forms.CheckBox()
    Me.nmWebCaptionSize = New System.Windows.Forms.NumericUpDown()
    Me.nmWebTitleSize = New System.Windows.Forms.NumericUpDown()
    Me.nmWebCellSpacing = New System.Windows.Forms.NumericUpDown()
    Me.nmWebCellPadding = New System.Windows.Forms.NumericUpDown()
    Me.nmWebTableBorder = New System.Windows.Forms.NumericUpDown()
    Me.nmWebThumbY = New System.Windows.Forms.NumericUpDown()
    Me.nmWebThumbX = New System.Windows.Forms.NumericUpDown()
    Me.nmWebnColumns = New System.Windows.Forms.NumericUpDown()
    Me.txWebGoogleAnalytics = New System.Windows.Forms.TextBox()
    Me.txWebFont = New System.Windows.Forms.TextBox()
    Me.cmdWebForeColor = New System.Windows.Forms.Button()
    Me.cmdWebBackColor = New System.Windows.Forms.Button()
    Me.chkWebConvertUTCtoLocal = New System.Windows.Forms.CheckBox()
    Me.nmWebShadowSize = New System.Windows.Forms.NumericUpDown()
    Me.chkSlideshowPhotoDate = New System.Windows.Forms.CheckBox()
    Me.chkAdjustIndColor = New System.Windows.Forms.CheckBox()
    Me.chkAdjustIndIntensity = New System.Windows.Forms.CheckBox()
    Me.chkAdjustPreserveIntensity = New System.Windows.Forms.CheckBox()
    Me.chkDisableUndo = New System.Windows.Forms.CheckBox()
    Me.chkWebGoogleEvents = New System.Windows.Forms.CheckBox()
    Me.txWebBackcolor = New System.Windows.Forms.TextBox()
    Me.txWebForecolor = New System.Windows.Forms.TextBox()
    Me.chkWebTarget = New System.Windows.Forms.CheckBox()
    Me.chkPNGIndexed = New System.Windows.Forms.CheckBox()
    Me.nmJpgQuality = New System.Windows.Forms.NumericUpDown()
    Me.nmSendJPGQuality = New System.Windows.Forms.NumericUpDown()
    Me.chkDelRawFiles = New System.Windows.Forms.CheckBox()
    Me.nmPngCompression = New System.Windows.Forms.NumericUpDown()
    Me.cmdOK = New System.Windows.Forms.Button()
    Me.cmdCancel = New System.Windows.Forms.Button()
    Me.tab1 = New System.Windows.Forms.TabControl()
    Me.tabGeneral = New System.Windows.Forms.TabPage()
    Me.Label6 = New System.Windows.Forms.Label()
    Me.tabEditing = New System.Windows.Forms.TabPage()
    Me.lbLowerTolerance = New System.Windows.Forms.Label()
    Me.tabSlideShow = New System.Windows.Forms.TabPage()
    Me.optSlideOrderNone = New System.Windows.Forms.RadioButton()
    Me.optSlideOrderRandom = New System.Windows.Forms.RadioButton()
    Me.optSlideOrderFileDate = New System.Windows.Forms.RadioButton()
    Me.optSlideOrderPhotoDate = New System.Windows.Forms.RadioButton()
    Me.optSlideOrderFilename = New System.Windows.Forms.RadioButton()
    Me.tabFile = New System.Windows.Forms.TabPage()
    Me.Label27 = New System.Windows.Forms.Label()
    Me.Frame2 = New System.Windows.Forms.GroupBox()
    Me.lbCompression = New System.Windows.Forms.Label()
    Me.lbJpgCompression = New System.Windows.Forms.Label()
    Me.lbSendJPGCompression = New System.Windows.Forms.Label()
    Me.tabExplore = New System.Windows.Forms.TabPage()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.cmbViewStyle = New System.Windows.Forms.ComboBox()
    Me.tabWebPage = New System.Windows.Forms.TabPage()
    Me.cmbWebCaptionAlign = New System.Windows.Forms.ComboBox()
    Me.Label18 = New System.Windows.Forms.Label()
    Me.Label19 = New System.Windows.Forms.Label()
    Me.chkNormalTitleSize = New System.Windows.Forms.CheckBox()
    Me.chkNormalCaptionSize = New System.Windows.Forms.CheckBox()
    Me.Label16 = New System.Windows.Forms.Label()
    Me.Label14 = New System.Windows.Forms.Label()
    Me.Label12 = New System.Windows.Forms.Label()
    Me.Label11 = New System.Windows.Forms.Label()
    Me.Label10 = New System.Windows.Forms.Label()
    Me.Label8 = New System.Windows.Forms.Label()
    Me.Label7 = New System.Windows.Forms.Label()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.Label3 = New System.Windows.Forms.Label()
    Me.Label5 = New System.Windows.Forms.Label()
    Me.Label4 = New System.Windows.Forms.Label()
    Me.tabDatabase = New System.Windows.Forms.TabPage()
    Me.cmdTest = New System.Windows.Forms.Button()
    Me.Panel1 = New System.Windows.Forms.Panel()
    Me.Label26 = New System.Windows.Forms.Label()
    Me.txBugPath = New System.Windows.Forms.TextBox()
    Me.Label25 = New System.Windows.Forms.Label()
    Me.txDBpassword = New System.Windows.Forms.TextBox()
    Me.txDBuser = New System.Windows.Forms.TextBox()
    Me.txDBdatabase = New System.Windows.Forms.TextBox()
    Me.txDBhost = New System.Windows.Forms.TextBox()
    Me.Label24 = New System.Windows.Forms.Label()
    Me.Label23 = New System.Windows.Forms.Label()
    Me.Label22 = New System.Windows.Forms.Label()
    Me.Label21 = New System.Windows.Forms.Label()
    Me.Label20 = New System.Windows.Forms.Label()
    Me.TabMail = New System.Windows.Forms.TabPage()
    Me.cmdEmailTest = New System.Windows.Forms.Button()
    Me.Panel2 = New System.Windows.Forms.Panel()
    Me.Label28 = New System.Windows.Forms.Label()
    Me.txEmailPort = New System.Windows.Forms.TextBox()
    Me.txEmailPassword = New System.Windows.Forms.TextBox()
    Me.txEmailHost = New System.Windows.Forms.TextBox()
    Me.txEmailAccount = New System.Windows.Forms.TextBox()
    Me.Label30 = New System.Windows.Forms.Label()
    Me.Label31 = New System.Windows.Forms.Label()
    Me.Label32 = New System.Windows.Forms.Label()
    Me.Label34 = New System.Windows.Forms.Label()
    CType(Me.nmColorTolerance, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.nmSlideFadeTime, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.nmSlideRate, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.nmThumbY, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.nmThumbX, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.nmWebCaptionSize, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.nmWebTitleSize, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.nmWebCellSpacing, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.nmWebCellPadding, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.nmWebTableBorder, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.nmWebThumbY, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.nmWebThumbX, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.nmWebnColumns, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.nmWebShadowSize, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.nmJpgQuality, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.nmSendJPGQuality, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.nmPngCompression, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.tab1.SuspendLayout()
    Me.tabGeneral.SuspendLayout()
    Me.tabEditing.SuspendLayout()
    Me.tabSlideShow.SuspendLayout()
    Me.tabFile.SuspendLayout()
    Me.Frame2.SuspendLayout()
    Me.tabExplore.SuspendLayout()
    Me.tabWebPage.SuspendLayout()
    Me.tabDatabase.SuspendLayout()
    Me.Panel1.SuspendLayout()
    Me.TabMail.SuspendLayout()
    Me.Panel2.SuspendLayout()
    Me.SuspendLayout()
    '
    'cmdHelp
    '
    Me.cmdHelp.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.cmdHelp.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.cmdHelp.Image = CType(resources.GetObject("cmdHelp.Image"), System.Drawing.Image)
    Me.cmdHelp.Location = New System.Drawing.Point(294, 598)
    Me.cmdHelp.Name = "cmdHelp"
    Me.cmdHelp.Size = New System.Drawing.Size(44, 44)
    Me.cmdHelp.TabIndex = 50
    Me.cmdHelp.TextAlign = System.Drawing.ContentAlignment.BottomCenter
    Me.ToolTip1.SetToolTip(Me.cmdHelp, "Help")
    Me.cmdHelp.UseVisualStyleBackColor = False
    '
    'chkViewToolbar
    '
    Me.chkViewToolbar.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.chkViewToolbar.Location = New System.Drawing.Point(142, 98)
    Me.chkViewToolbar.Name = "chkViewToolbar"
    Me.chkViewToolbar.Size = New System.Drawing.Size(221, 21)
    Me.chkViewToolbar.TabIndex = 1
    Me.chkViewToolbar.Text = "&Show Toolbar"
    Me.ToolTip1.SetToolTip(Me.chkViewToolbar, "Check to show the toolbars")
    Me.chkViewToolbar.UseVisualStyleBackColor = False
    '
    'chkSlideShowName
    '
    Me.chkSlideShowName.AutoSize = True
    Me.chkSlideShowName.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.chkSlideShowName.Location = New System.Drawing.Point(150, 207)
    Me.chkSlideShowName.Name = "chkSlideShowName"
    Me.chkSlideShowName.Size = New System.Drawing.Size(202, 21)
    Me.chkSlideShowName.TabIndex = 2
    Me.chkSlideShowName.Text = "Show &file name with slides"
    Me.ToolTip1.SetToolTip(Me.chkSlideShowName, "Show the file names during the slideshow")
    Me.chkSlideShowName.UseVisualStyleBackColor = False
    '
    'chkSlideShowDescription
    '
    Me.chkSlideShowDescription.AutoSize = True
    Me.chkSlideShowDescription.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.chkSlideShowDescription.Location = New System.Drawing.Point(150, 237)
    Me.chkSlideShowDescription.Name = "chkSlideShowDescription"
    Me.chkSlideShowDescription.Size = New System.Drawing.Size(254, 21)
    Me.chkSlideShowDescription.TabIndex = 3
    Me.chkSlideShowDescription.Text = "Show photo &description with slides"
    Me.ToolTip1.SetToolTip(Me.chkSlideShowDescription, "Show the photo descriptions during the slideshow.")
    Me.chkSlideShowDescription.UseVisualStyleBackColor = False
    '
    'chkDateInCommentCommand
    '
    Me.chkDateInCommentCommand.AutoSize = True
    Me.chkDateInCommentCommand.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.chkDateInCommentCommand.Location = New System.Drawing.Point(129, 320)
    Me.chkDateInCommentCommand.Name = "chkDateInCommentCommand"
    Me.chkDateInCommentCommand.Size = New System.Drawing.Size(394, 21)
    Me.chkDateInCommentCommand.TabIndex = 6
    Me.chkDateInCommentCommand.Text = "&Allow date and GPS location change in photo comments"
    Me.ToolTip1.SetToolTip(Me.chkDateInCommentCommand, "Leave unchecked to use the Windows keywords field, check to add keywords to the E" & _
        "xif Comment field.")
    Me.chkDateInCommentCommand.UseVisualStyleBackColor = False
    '
    'chkZoomOne
    '
    Me.chkZoomOne.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.chkZoomOne.Location = New System.Drawing.Point(129, 108)
    Me.chkZoomOne.Name = "chkZoomOne"
    Me.chkZoomOne.Size = New System.Drawing.Size(261, 21)
    Me.chkZoomOne.TabIndex = 1
    Me.chkZoomOne.Text = "Begin editing at 1:1 &zoom"
    Me.ToolTip1.SetToolTip(Me.chkZoomOne, "Uncheck to begin editing with the photo fit to the window.")
    Me.chkZoomOne.UseVisualStyleBackColor = False
    '
    'cmdReset
    '
    Me.cmdReset.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.cmdReset.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.cmdReset.Location = New System.Drawing.Point(366, 598)
    Me.cmdReset.Name = "cmdReset"
    Me.cmdReset.Size = New System.Drawing.Size(101, 44)
    Me.cmdReset.TabIndex = 51
    Me.cmdReset.Text = "&Reset All Options"
    Me.ToolTip1.SetToolTip(Me.cmdReset, "Reset all options to the program defaults")
    Me.cmdReset.UseVisualStyleBackColor = False
    '
    'lbslideRate
    '
    Me.lbslideRate.AutoSize = True
    Me.lbslideRate.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.lbslideRate.Location = New System.Drawing.Point(147, 297)
    Me.lbslideRate.Name = "lbslideRate"
    Me.lbslideRate.Size = New System.Drawing.Size(129, 17)
    Me.lbslideRate.TabIndex = 4
    Me.lbslideRate.Text = "&Seconds per slide:"
    Me.ToolTip1.SetToolTip(Me.lbslideRate, "The number of seconds each slide will appear")
    '
    'chkShowTips
    '
    Me.chkShowTips.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.chkShowTips.Location = New System.Drawing.Point(142, 71)
    Me.chkShowTips.Name = "chkShowTips"
    Me.chkShowTips.Size = New System.Drawing.Size(261, 21)
    Me.chkShowTips.TabIndex = 0
    Me.chkShowTips.Text = "Show Ti&ps at Startup"
    Me.ToolTip1.SetToolTip(Me.chkShowTips, "Display useful tips when the program starts.")
    Me.chkShowTips.UseVisualStyleBackColor = False
    '
    'cmdToolbar
    '
    Me.cmdToolbar.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.cmdToolbar.Location = New System.Drawing.Point(142, 174)
    Me.cmdToolbar.Name = "cmdToolbar"
    Me.cmdToolbar.Size = New System.Drawing.Size(114, 46)
    Me.cmdToolbar.TabIndex = 4
    Me.cmdToolbar.Text = "&Customize Toolbar..."
    Me.ToolTip1.SetToolTip(Me.cmdToolbar, "Toolbar Options")
    Me.cmdToolbar.UseVisualStyleBackColor = True
    '
    'cmbButtonSize
    '
    Me.cmbButtonSize.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.cmbButtonSize.FormattingEnabled = True
    Me.cmbButtonSize.Location = New System.Drawing.Point(282, 125)
    Me.cmbButtonSize.Name = "cmbButtonSize"
    Me.cmbButtonSize.Size = New System.Drawing.Size(195, 25)
    Me.cmbButtonSize.TabIndex = 3
    Me.ToolTip1.SetToolTip(Me.cmbButtonSize, "Select large or small toolbar buttons")
    '
    'cmdFileAssoc
    '
    Me.cmdFileAssoc.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.cmdFileAssoc.Location = New System.Drawing.Point(142, 246)
    Me.cmdFileAssoc.Name = "cmdFileAssoc"
    Me.cmdFileAssoc.Size = New System.Drawing.Size(117, 52)
    Me.cmdFileAssoc.TabIndex = 5
    Me.cmdFileAssoc.Text = "&Associate File Types..."
    Me.ToolTip1.SetToolTip(Me.cmdFileAssoc, "Associate file types with this program.")
    Me.cmdFileAssoc.UseVisualStyleBackColor = True
    '
    'nmColorTolerance
    '
    Me.nmColorTolerance.Location = New System.Drawing.Point(321, 163)
    Me.nmColorTolerance.Name = "nmColorTolerance"
    Me.nmColorTolerance.Size = New System.Drawing.Size(69, 25)
    Me.nmColorTolerance.TabIndex = 3
    Me.ToolTip1.SetToolTip(Me.nmColorTolerance, "Make color tolerace larger to select more " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "of the photo, smaller for less.")
    Me.nmColorTolerance.Value = New Decimal(New Integer() {5, 0, 0, 0})
    '
    'chkMultiUndo
    '
    Me.chkMultiUndo.AutoSize = True
    Me.chkMultiUndo.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.chkMultiUndo.Location = New System.Drawing.Point(129, 54)
    Me.chkMultiUndo.Name = "chkMultiUndo"
    Me.chkMultiUndo.Size = New System.Drawing.Size(402, 21)
    Me.chkMultiUndo.TabIndex = 0
    Me.chkMultiUndo.Text = "Enable multi-level &undo (includes redo and saves to disk.)"
    Me.ToolTip1.SetToolTip(Me.chkMultiUndo, "Multi-level undo allows you to undo and redo several operations. " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "However, this " & _
        "can slow down the program if you are working with very large photos.")
    Me.chkMultiUndo.UseVisualStyleBackColor = False
    '
    'nmSlideFadeTime
    '
    Me.nmSlideFadeTime.Location = New System.Drawing.Point(351, 321)
    Me.nmSlideFadeTime.Maximum = New Decimal(New Integer() {2000, 0, 0, 0})
    Me.nmSlideFadeTime.Name = "nmSlideFadeTime"
    Me.nmSlideFadeTime.Size = New System.Drawing.Size(74, 25)
    Me.nmSlideFadeTime.TabIndex = 7
    Me.ToolTip1.SetToolTip(Me.nmSlideFadeTime, "The number of milliseconds (1/1000) used to dissolve from one slide to the next." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Use zero for no dissolve.")
    Me.nmSlideFadeTime.Value = New Decimal(New Integer() {30, 0, 0, 0})
    '
    'Label17
    '
    Me.Label17.AutoSize = True
    Me.Label17.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.Label17.Location = New System.Drawing.Point(147, 323)
    Me.Label17.Name = "Label17"
    Me.Label17.Size = New System.Drawing.Size(195, 17)
    Me.Label17.TabIndex = 6
    Me.Label17.Text = "&Dissolve time (milliseconds):"
    Me.ToolTip1.SetToolTip(Me.Label17, "The number of milliseconds (1/1000) used to dissolve from one slide to the next." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Use zero for no dissolve.")
    '
    'nmSlideRate
    '
    Me.nmSlideRate.Location = New System.Drawing.Point(351, 295)
    Me.nmSlideRate.Maximum = New Decimal(New Integer() {60, 0, 0, 0})
    Me.nmSlideRate.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
    Me.nmSlideRate.Name = "nmSlideRate"
    Me.nmSlideRate.Size = New System.Drawing.Size(74, 25)
    Me.nmSlideRate.TabIndex = 5
    Me.ToolTip1.SetToolTip(Me.nmSlideRate, "The number of seconds each slide will appear")
    Me.nmSlideRate.Value = New Decimal(New Integer() {60, 0, 0, 0})
    '
    'nmThumbY
    '
    Me.nmThumbY.Location = New System.Drawing.Point(299, 157)
    Me.nmThumbY.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
    Me.nmThumbY.Minimum = New Decimal(New Integer() {20, 0, 0, 0})
    Me.nmThumbY.Name = "nmThumbY"
    Me.nmThumbY.Size = New System.Drawing.Size(73, 25)
    Me.nmThumbY.TabIndex = 5
    Me.ToolTip1.SetToolTip(Me.nmThumbY, "The size of the thumbnail or small image of the photo in the explorer listing")
    Me.nmThumbY.Value = New Decimal(New Integer() {240, 0, 0, 0})
    '
    'nmThumbX
    '
    Me.nmThumbX.Location = New System.Drawing.Point(299, 120)
    Me.nmThumbX.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
    Me.nmThumbX.Minimum = New Decimal(New Integer() {20, 0, 0, 0})
    Me.nmThumbX.Name = "nmThumbX"
    Me.nmThumbX.Size = New System.Drawing.Size(73, 25)
    Me.nmThumbX.TabIndex = 3
    Me.ToolTip1.SetToolTip(Me.nmThumbX, "The size of the thumbnail or small image of the photo in the explorer listing")
    Me.nmThumbX.Value = New Decimal(New Integer() {240, 0, 0, 0})
    '
    'lbThumbY
    '
    Me.lbThumbY.AutoSize = True
    Me.lbThumbY.Location = New System.Drawing.Point(120, 159)
    Me.lbThumbY.Name = "lbThumbY"
    Me.lbThumbY.Size = New System.Drawing.Size(174, 17)
    Me.lbThumbY.TabIndex = 4
    Me.lbThumbY.Text = "Thumbnail &height (pixels):"
    Me.ToolTip1.SetToolTip(Me.lbThumbY, "The size of the thumbnail or small image of the photo in the explorer listing")
    '
    'lbThumbX
    '
    Me.lbThumbX.AutoSize = True
    Me.lbThumbX.Location = New System.Drawing.Point(120, 122)
    Me.lbThumbX.Name = "lbThumbX"
    Me.lbThumbX.Size = New System.Drawing.Size(169, 17)
    Me.lbThumbX.TabIndex = 2
    Me.lbThumbX.Text = "Thumbnail &width (pixels):"
    Me.ToolTip1.SetToolTip(Me.lbThumbX, "The size of the thumbnail or small image of the photo in the explorer listing")
    '
    'chkMultiTagPath
    '
    Me.chkMultiTagPath.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.chkMultiTagPath.Location = New System.Drawing.Point(123, 206)
    Me.chkMultiTagPath.Name = "chkMultiTagPath"
    Me.chkMultiTagPath.Size = New System.Drawing.Size(261, 21)
    Me.chkMultiTagPath.TabIndex = 6
    Me.chkMultiTagPath.Text = "Allow tags in &multiple folders"
    Me.ToolTip1.SetToolTip(Me.chkMultiTagPath, "Allow tags in multiple folders, not applicable for thumbnail view")
    Me.chkMultiTagPath.UseVisualStyleBackColor = False
    '
    'nmWebCaptionSize
    '
    Me.nmWebCaptionSize.Location = New System.Drawing.Point(345, 296)
    Me.nmWebCaptionSize.Maximum = New Decimal(New Integer() {48, 0, 0, 0})
    Me.nmWebCaptionSize.Minimum = New Decimal(New Integer() {4, 0, 0, 0})
    Me.nmWebCaptionSize.Name = "nmWebCaptionSize"
    Me.nmWebCaptionSize.Size = New System.Drawing.Size(77, 25)
    Me.nmWebCaptionSize.TabIndex = 21
    Me.ToolTip1.SetToolTip(Me.nmWebCaptionSize, "The size of the photo captions.")
    Me.nmWebCaptionSize.Value = New Decimal(New Integer() {12, 0, 0, 0})
    '
    'nmWebTitleSize
    '
    Me.nmWebTitleSize.Location = New System.Drawing.Point(345, 265)
    Me.nmWebTitleSize.Maximum = New Decimal(New Integer() {72, 0, 0, 0})
    Me.nmWebTitleSize.Minimum = New Decimal(New Integer() {4, 0, 0, 0})
    Me.nmWebTitleSize.Name = "nmWebTitleSize"
    Me.nmWebTitleSize.Size = New System.Drawing.Size(77, 25)
    Me.nmWebTitleSize.TabIndex = 18
    Me.ToolTip1.SetToolTip(Me.nmWebTitleSize, "The size of the web page heading")
    Me.nmWebTitleSize.Value = New Decimal(New Integer() {72, 0, 0, 0})
    '
    'nmWebCellSpacing
    '
    Me.nmWebCellSpacing.Location = New System.Drawing.Point(345, 234)
    Me.nmWebCellSpacing.Name = "nmWebCellSpacing"
    Me.nmWebCellSpacing.Size = New System.Drawing.Size(77, 25)
    Me.nmWebCellSpacing.TabIndex = 16
    Me.ToolTip1.SetToolTip(Me.nmWebCellSpacing, "Cell spacing, or the space between cell borders")
    Me.nmWebCellSpacing.Value = New Decimal(New Integer() {100, 0, 0, 0})
    '
    'nmWebCellPadding
    '
    Me.nmWebCellPadding.Location = New System.Drawing.Point(345, 203)
    Me.nmWebCellPadding.Name = "nmWebCellPadding"
    Me.nmWebCellPadding.Size = New System.Drawing.Size(77, 25)
    Me.nmWebCellPadding.TabIndex = 14
    Me.ToolTip1.SetToolTip(Me.nmWebCellPadding, "Cell padding, or the space between cell contents and the border")
    Me.nmWebCellPadding.Value = New Decimal(New Integer() {100, 0, 0, 0})
    '
    'nmWebTableBorder
    '
    Me.nmWebTableBorder.Location = New System.Drawing.Point(345, 172)
    Me.nmWebTableBorder.Name = "nmWebTableBorder"
    Me.nmWebTableBorder.Size = New System.Drawing.Size(77, 25)
    Me.nmWebTableBorder.TabIndex = 12
    Me.ToolTip1.SetToolTip(Me.nmWebTableBorder, "The thickness of the lines between cells.")
    Me.nmWebTableBorder.Value = New Decimal(New Integer() {100, 0, 0, 0})
    '
    'nmWebThumbY
    '
    Me.nmWebThumbY.Location = New System.Drawing.Point(428, 110)
    Me.nmWebThumbY.Maximum = New Decimal(New Integer() {1024, 0, 0, 0})
    Me.nmWebThumbY.Minimum = New Decimal(New Integer() {20, 0, 0, 0})
    Me.nmWebThumbY.Name = "nmWebThumbY"
    Me.nmWebThumbY.Size = New System.Drawing.Size(77, 25)
    Me.nmWebThumbY.TabIndex = 8
    Me.ToolTip1.SetToolTip(Me.nmWebThumbY, "Thumbnail size in the web page")
    Me.nmWebThumbY.Value = New Decimal(New Integer() {200, 0, 0, 0})
    '
    'nmWebThumbX
    '
    Me.nmWebThumbX.Location = New System.Drawing.Point(345, 110)
    Me.nmWebThumbX.Maximum = New Decimal(New Integer() {1024, 0, 0, 0})
    Me.nmWebThumbX.Minimum = New Decimal(New Integer() {20, 0, 0, 0})
    Me.nmWebThumbX.Name = "nmWebThumbX"
    Me.nmWebThumbX.Size = New System.Drawing.Size(77, 25)
    Me.nmWebThumbX.TabIndex = 7
    Me.ToolTip1.SetToolTip(Me.nmWebThumbX, "Thumbnail size in the web page")
    Me.nmWebThumbX.Value = New Decimal(New Integer() {1000, 0, 0, 0})
    '
    'nmWebnColumns
    '
    Me.nmWebnColumns.Location = New System.Drawing.Point(345, 79)
    Me.nmWebnColumns.Maximum = New Decimal(New Integer() {200, 0, 0, 0})
    Me.nmWebnColumns.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
    Me.nmWebnColumns.Name = "nmWebnColumns"
    Me.nmWebnColumns.Size = New System.Drawing.Size(77, 25)
    Me.nmWebnColumns.TabIndex = 5
    Me.ToolTip1.SetToolTip(Me.nmWebnColumns, "Number of columns in the thumbnail table")
    Me.nmWebnColumns.Value = New Decimal(New Integer() {200, 0, 0, 0})
    '
    'txWebGoogleAnalytics
    '
    Me.txWebGoogleAnalytics.Location = New System.Drawing.Point(345, 389)
    Me.txWebGoogleAnalytics.Name = "txWebGoogleAnalytics"
    Me.txWebGoogleAnalytics.Size = New System.Drawing.Size(206, 25)
    Me.txWebGoogleAnalytics.TabIndex = 26
    Me.ToolTip1.SetToolTip(Me.txWebGoogleAnalytics, "If you use Google Analytics, you can enter your code here and Google Analytics sc" & _
        "ript will be generated for the web page.")
    '
    'txWebFont
    '
    Me.txWebFont.Location = New System.Drawing.Point(345, 358)
    Me.txWebFont.Name = "txWebFont"
    Me.txWebFont.Size = New System.Drawing.Size(206, 25)
    Me.txWebFont.TabIndex = 24
    Me.ToolTip1.SetToolTip(Me.txWebFont, "Font family name for the web page")
    '
    'cmdWebForeColor
    '
    Me.cmdWebForeColor.BackColor = System.Drawing.SystemColors.WindowText
    Me.cmdWebForeColor.Location = New System.Drawing.Point(345, 47)
    Me.cmdWebForeColor.Name = "cmdWebForeColor"
    Me.cmdWebForeColor.Size = New System.Drawing.Size(43, 24)
    Me.cmdWebForeColor.TabIndex = 3
    Me.ToolTip1.SetToolTip(Me.cmdWebForeColor, "Text color for the web page")
    Me.cmdWebForeColor.UseVisualStyleBackColor = False
    '
    'cmdWebBackColor
    '
    Me.cmdWebBackColor.BackColor = System.Drawing.SystemColors.Window
    Me.cmdWebBackColor.Location = New System.Drawing.Point(345, 19)
    Me.cmdWebBackColor.Name = "cmdWebBackColor"
    Me.cmdWebBackColor.Size = New System.Drawing.Size(43, 24)
    Me.cmdWebBackColor.TabIndex = 1
    Me.ToolTip1.SetToolTip(Me.cmdWebBackColor, "Background color of the web page")
    Me.cmdWebBackColor.UseVisualStyleBackColor = False
    '
    'chkWebConvertUTCtoLocal
    '
    Me.chkWebConvertUTCtoLocal.AutoSize = True
    Me.chkWebConvertUTCtoLocal.Location = New System.Drawing.Point(97, 453)
    Me.chkWebConvertUTCtoLocal.Name = "chkWebConvertUTCtoLocal"
    Me.chkWebConvertUTCtoLocal.Size = New System.Drawing.Size(311, 21)
    Me.chkWebConvertUTCtoLocal.TabIndex = 27
    Me.chkWebConvertUTCtoLocal.Text = "Convert photo times from &UTC to local time"
    Me.ToolTip1.SetToolTip(Me.chkWebConvertUTCtoLocal, "If your photo times are in UTC (Greenwich Mean Time), you " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "can automatically con" & _
        "vert them to the computer's local time zone.")
    Me.chkWebConvertUTCtoLocal.UseVisualStyleBackColor = True
    '
    'nmWebShadowSize
    '
    Me.nmWebShadowSize.Location = New System.Drawing.Point(345, 141)
    Me.nmWebShadowSize.Maximum = New Decimal(New Integer() {20, 0, 0, 0})
    Me.nmWebShadowSize.Name = "nmWebShadowSize"
    Me.nmWebShadowSize.Size = New System.Drawing.Size(77, 25)
    Me.nmWebShadowSize.TabIndex = 10
    Me.ToolTip1.SetToolTip(Me.nmWebShadowSize, "Size of the thumbnail drop shadow, in pixels." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Use zero if you don't want a drop " & _
        "shadow.")
    Me.nmWebShadowSize.Value = New Decimal(New Integer() {6, 0, 0, 0})
    '
    'chkSlideshowPhotoDate
    '
    Me.chkSlideshowPhotoDate.AutoSize = True
    Me.chkSlideshowPhotoDate.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.chkSlideshowPhotoDate.Location = New System.Drawing.Point(150, 264)
    Me.chkSlideshowPhotoDate.Name = "chkSlideshowPhotoDate"
    Me.chkSlideshowPhotoDate.Size = New System.Drawing.Size(254, 21)
    Me.chkSlideshowPhotoDate.TabIndex = 13
    Me.chkSlideshowPhotoDate.Text = "Show photo &description with slides"
    Me.ToolTip1.SetToolTip(Me.chkSlideshowPhotoDate, "Show the photo descriptions during the slideshow.")
    Me.chkSlideshowPhotoDate.UseVisualStyleBackColor = False
    '
    'chkAdjustIndColor
    '
    Me.chkAdjustIndColor.AutoSize = True
    Me.chkAdjustIndColor.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.chkAdjustIndColor.Location = New System.Drawing.Point(129, 215)
    Me.chkAdjustIndColor.Name = "chkAdjustIndColor"
    Me.chkAdjustIndColor.Size = New System.Drawing.Size(260, 21)
    Me.chkAdjustIndColor.TabIndex = 49
    Me.chkAdjustIndColor.Text = "Color Adjust with Independent Color"
    Me.ToolTip1.SetToolTip(Me.chkAdjustIndColor, "Uncheck to begin editing with the photo fit to the window.")
    Me.chkAdjustIndColor.UseVisualStyleBackColor = False
    '
    'chkAdjustIndIntensity
    '
    Me.chkAdjustIndIntensity.AutoSize = True
    Me.chkAdjustIndIntensity.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.chkAdjustIndIntensity.Location = New System.Drawing.Point(129, 242)
    Me.chkAdjustIndIntensity.Name = "chkAdjustIndIntensity"
    Me.chkAdjustIndIntensity.Size = New System.Drawing.Size(278, 21)
    Me.chkAdjustIndIntensity.TabIndex = 50
    Me.chkAdjustIndIntensity.Text = "Color Adjust with Independent Intensity"
    Me.ToolTip1.SetToolTip(Me.chkAdjustIndIntensity, "Uncheck to begin editing with the photo fit to the window.")
    Me.chkAdjustIndIntensity.UseVisualStyleBackColor = False
    '
    'chkAdjustPreserveIntensity
    '
    Me.chkAdjustPreserveIntensity.AutoSize = True
    Me.chkAdjustPreserveIntensity.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.chkAdjustPreserveIntensity.Location = New System.Drawing.Point(129, 269)
    Me.chkAdjustPreserveIntensity.Name = "chkAdjustPreserveIntensity"
    Me.chkAdjustPreserveIntensity.Size = New System.Drawing.Size(308, 21)
    Me.chkAdjustPreserveIntensity.TabIndex = 51
    Me.chkAdjustPreserveIntensity.Text = "Preserve Overall Intensity with Color Adjust"
    Me.ToolTip1.SetToolTip(Me.chkAdjustPreserveIntensity, "Uncheck to begin editing with the photo fit to the window.")
    Me.chkAdjustPreserveIntensity.UseVisualStyleBackColor = False
    '
    'chkDisableUndo
    '
    Me.chkDisableUndo.AutoSize = True
    Me.chkDisableUndo.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.chkDisableUndo.Location = New System.Drawing.Point(129, 81)
    Me.chkDisableUndo.Name = "chkDisableUndo"
    Me.chkDisableUndo.Size = New System.Drawing.Size(252, 21)
    Me.chkDisableUndo.TabIndex = 52
    Me.chkDisableUndo.Text = "Disable all undo (to save memory)"
    Me.ToolTip1.SetToolTip(Me.chkDisableUndo, "Multi-level undo allows you to undo and redo several operations. " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "However, this " & _
        "can slow down the program if you are working with very large photos.")
    Me.chkDisableUndo.UseVisualStyleBackColor = False
    '
    'chkWebGoogleEvents
    '
    Me.chkWebGoogleEvents.AutoSize = True
    Me.chkWebGoogleEvents.Location = New System.Drawing.Point(97, 423)
    Me.chkWebGoogleEvents.Name = "chkWebGoogleEvents"
    Me.chkWebGoogleEvents.Size = New System.Drawing.Size(243, 21)
    Me.chkWebGoogleEvents.TabIndex = 31
    Me.chkWebGoogleEvents.Text = "Add Google &Events link to photos"
    Me.ToolTip1.SetToolTip(Me.chkWebGoogleEvents, "If your photo times are in UTC (Greenwich Mean Time), you " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "can automatically con" & _
        "vert them to the computer's local time zone.")
    Me.chkWebGoogleEvents.UseVisualStyleBackColor = True
    '
    'txWebBackcolor
    '
    Me.txWebBackcolor.Location = New System.Drawing.Point(396, 19)
    Me.txWebBackcolor.Name = "txWebBackcolor"
    Me.txWebBackcolor.Size = New System.Drawing.Size(160, 25)
    Me.txWebBackcolor.TabIndex = 32
    Me.ToolTip1.SetToolTip(Me.txWebBackcolor, "Font family name for the web page")
    '
    'txWebForecolor
    '
    Me.txWebForecolor.Location = New System.Drawing.Point(396, 47)
    Me.txWebForecolor.Name = "txWebForecolor"
    Me.txWebForecolor.Size = New System.Drawing.Size(160, 25)
    Me.txWebForecolor.TabIndex = 33
    Me.ToolTip1.SetToolTip(Me.txWebForecolor, "Font family name for the web page")
    '
    'chkWebTarget
    '
    Me.chkWebTarget.AutoSize = True
    Me.chkWebTarget.Location = New System.Drawing.Point(97, 482)
    Me.chkWebTarget.Name = "chkWebTarget"
    Me.chkWebTarget.Size = New System.Drawing.Size(255, 21)
    Me.chkWebTarget.TabIndex = 34
    Me.chkWebTarget.Text = "Open &links in new tabs or windows"
    Me.ToolTip1.SetToolTip(Me.chkWebTarget, "If your photo times are in UTC (Greenwich Mean Time), you " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "can automatically con" & _
        "vert them to the computer's local time zone.")
    Me.chkWebTarget.UseVisualStyleBackColor = True
    '
    'chkPNGIndexed
    '
    Me.chkPNGIndexed.AutoSize = True
    Me.chkPNGIndexed.Location = New System.Drawing.Point(57, 279)
    Me.chkPNGIndexed.Name = "chkPNGIndexed"
    Me.chkPNGIndexed.Size = New System.Drawing.Size(241, 21)
    Me.chkPNGIndexed.TabIndex = 7
    Me.chkPNGIndexed.Text = "Use inde&xed color with PNG files"
    Me.ToolTip1.SetToolTip(Me.chkPNGIndexed, "Indexed color results in smaller PNG files when the images have a smaller number " & _
        "of colors.")
    Me.chkPNGIndexed.UseVisualStyleBackColor = True
    '
    'nmJpgQuality
    '
    Me.nmJpgQuality.Location = New System.Drawing.Point(304, 48)
    Me.nmJpgQuality.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
    Me.nmJpgQuality.Name = "nmJpgQuality"
    Me.nmJpgQuality.Size = New System.Drawing.Size(73, 25)
    Me.nmJpgQuality.TabIndex = 1
    Me.ToolTip1.SetToolTip(Me.nmJpgQuality, "JPG image quality for saving files")
    Me.nmJpgQuality.Value = New Decimal(New Integer() {97, 0, 0, 0})
    '
    'nmSendJPGQuality
    '
    Me.nmSendJPGQuality.Location = New System.Drawing.Point(304, 86)
    Me.nmSendJPGQuality.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
    Me.nmSendJPGQuality.Name = "nmSendJPGQuality"
    Me.nmSendJPGQuality.Size = New System.Drawing.Size(73, 25)
    Me.nmSendJPGQuality.TabIndex = 3
    Me.ToolTip1.SetToolTip(Me.nmSendJPGQuality, "JPG image quality for sending email")
    Me.nmSendJPGQuality.Value = New Decimal(New Integer() {95, 0, 0, 0})
    '
    'chkDelRawFiles
    '
    Me.chkDelRawFiles.AutoSize = True
    Me.chkDelRawFiles.Location = New System.Drawing.Point(57, 372)
    Me.chkDelRawFiles.Name = "chkDelRawFiles"
    Me.chkDelRawFiles.Size = New System.Drawing.Size(228, 21)
    Me.chkDelRawFiles.TabIndex = 37
    Me.chkDelRawFiles.Text = "Delete Raw files with JPG files"
    Me.ToolTip1.SetToolTip(Me.chkDelRawFiles, "Automatically delete Raw files with the same name as JPG files when the JPG files" & _
        " are deleted.")
    Me.chkDelRawFiles.UseVisualStyleBackColor = True
    '
    'nmPngCompression
    '
    Me.nmPngCompression.Location = New System.Drawing.Point(304, 313)
    Me.nmPngCompression.Maximum = New Decimal(New Integer() {9, 0, 0, 0})
    Me.nmPngCompression.Name = "nmPngCompression"
    Me.nmPngCompression.Size = New System.Drawing.Size(73, 25)
    Me.nmPngCompression.TabIndex = 39
    Me.ToolTip1.SetToolTip(Me.nmPngCompression, "Use zero for less compression (faster) to 9 for max compression. Image quality is" & _
        " not affected by the compression level in PNG files.")
    Me.nmPngCompression.Value = New Decimal(New Integer() {7, 0, 0, 0})
    '
    'cmdOK
    '
    Me.cmdOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.cmdOK.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.cmdOK.Location = New System.Drawing.Point(497, 598)
    Me.cmdOK.Name = "cmdOK"
    Me.cmdOK.Size = New System.Drawing.Size(101, 44)
    Me.cmdOK.TabIndex = 52
    Me.cmdOK.Text = "&OK"
    Me.cmdOK.UseVisualStyleBackColor = False
    '
    'cmdCancel
    '
    Me.cmdCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.cmdCancel.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.cmdCancel.Location = New System.Drawing.Point(628, 598)
    Me.cmdCancel.Name = "cmdCancel"
    Me.cmdCancel.Size = New System.Drawing.Size(101, 44)
    Me.cmdCancel.TabIndex = 53
    Me.cmdCancel.Text = "Cancel"
    Me.cmdCancel.UseVisualStyleBackColor = False
    '
    'tab1
    '
    Me.tab1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.tab1.Controls.Add(Me.tabGeneral)
    Me.tab1.Controls.Add(Me.tabEditing)
    Me.tab1.Controls.Add(Me.tabSlideShow)
    Me.tab1.Controls.Add(Me.tabFile)
    Me.tab1.Controls.Add(Me.tabExplore)
    Me.tab1.Controls.Add(Me.tabWebPage)
    Me.tab1.Controls.Add(Me.tabDatabase)
    Me.tab1.Controls.Add(Me.TabMail)
    Me.tab1.Location = New System.Drawing.Point(12, 13)
    Me.tab1.Multiline = True
    Me.tab1.Name = "tab1"
    Me.tab1.SelectedIndex = 0
    Me.tab1.Size = New System.Drawing.Size(733, 566)
    Me.tab1.TabIndex = 39
    '
    'tabGeneral
    '
    Me.tabGeneral.Controls.Add(Me.cmdToolbar)
    Me.tabGeneral.Controls.Add(Me.Label6)
    Me.tabGeneral.Controls.Add(Me.cmbButtonSize)
    Me.tabGeneral.Controls.Add(Me.cmdFileAssoc)
    Me.tabGeneral.Controls.Add(Me.chkViewToolbar)
    Me.tabGeneral.Controls.Add(Me.chkShowTips)
    Me.tabGeneral.Location = New System.Drawing.Point(4, 26)
    Me.tabGeneral.Name = "tabGeneral"
    Me.tabGeneral.Padding = New System.Windows.Forms.Padding(3)
    Me.tabGeneral.Size = New System.Drawing.Size(725, 536)
    Me.tabGeneral.TabIndex = 0
    Me.tabGeneral.Text = "General"
    Me.tabGeneral.UseVisualStyleBackColor = True
    '
    'Label6
    '
    Me.Label6.AutoSize = True
    Me.Label6.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.Label6.Location = New System.Drawing.Point(139, 128)
    Me.Label6.Name = "Label6"
    Me.Label6.Size = New System.Drawing.Size(134, 17)
    Me.Label6.TabIndex = 2
    Me.Label6.Text = "Toolbar &button size:"
    '
    'tabEditing
    '
    Me.tabEditing.Controls.Add(Me.chkDisableUndo)
    Me.tabEditing.Controls.Add(Me.chkAdjustPreserveIntensity)
    Me.tabEditing.Controls.Add(Me.chkAdjustIndIntensity)
    Me.tabEditing.Controls.Add(Me.chkAdjustIndColor)
    Me.tabEditing.Controls.Add(Me.nmColorTolerance)
    Me.tabEditing.Controls.Add(Me.chkDateInCommentCommand)
    Me.tabEditing.Controls.Add(Me.chkMultiUndo)
    Me.tabEditing.Controls.Add(Me.chkZoomOne)
    Me.tabEditing.Controls.Add(Me.lbLowerTolerance)
    Me.tabEditing.Location = New System.Drawing.Point(4, 26)
    Me.tabEditing.Name = "tabEditing"
    Me.tabEditing.Padding = New System.Windows.Forms.Padding(3)
    Me.tabEditing.Size = New System.Drawing.Size(725, 536)
    Me.tabEditing.TabIndex = 1
    Me.tabEditing.Text = "Editing"
    Me.tabEditing.UseVisualStyleBackColor = True
    '
    'lbLowerTolerance
    '
    Me.lbLowerTolerance.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.lbLowerTolerance.Location = New System.Drawing.Point(126, 152)
    Me.lbLowerTolerance.Name = "lbLowerTolerance"
    Me.lbLowerTolerance.Size = New System.Drawing.Size(204, 36)
    Me.lbLowerTolerance.TabIndex = 2
    Me.lbLowerTolerance.Text = "&Tolerance for similar color selection (default 5):"
    '
    'tabSlideShow
    '
    Me.tabSlideShow.Controls.Add(Me.chkSlideshowPhotoDate)
    Me.tabSlideShow.Controls.Add(Me.optSlideOrderNone)
    Me.tabSlideShow.Controls.Add(Me.optSlideOrderRandom)
    Me.tabSlideShow.Controls.Add(Me.optSlideOrderFileDate)
    Me.tabSlideShow.Controls.Add(Me.optSlideOrderPhotoDate)
    Me.tabSlideShow.Controls.Add(Me.optSlideOrderFilename)
    Me.tabSlideShow.Controls.Add(Me.nmSlideFadeTime)
    Me.tabSlideShow.Controls.Add(Me.Label17)
    Me.tabSlideShow.Controls.Add(Me.nmSlideRate)
    Me.tabSlideShow.Controls.Add(Me.chkSlideShowDescription)
    Me.tabSlideShow.Controls.Add(Me.lbslideRate)
    Me.tabSlideShow.Controls.Add(Me.chkSlideShowName)
    Me.tabSlideShow.Location = New System.Drawing.Point(4, 26)
    Me.tabSlideShow.Name = "tabSlideShow"
    Me.tabSlideShow.Padding = New System.Windows.Forms.Padding(3)
    Me.tabSlideShow.Size = New System.Drawing.Size(725, 536)
    Me.tabSlideShow.TabIndex = 2
    Me.tabSlideShow.Text = "Slide Show"
    Me.tabSlideShow.UseVisualStyleBackColor = True
    '
    'optSlideOrderNone
    '
    Me.optSlideOrderNone.AutoSize = True
    Me.optSlideOrderNone.Location = New System.Drawing.Point(150, 160)
    Me.optSlideOrderNone.Name = "optSlideOrderNone"
    Me.optSlideOrderNone.Size = New System.Drawing.Size(165, 21)
    Me.optSlideOrderNone.TabIndex = 12
    Me.optSlideOrderNone.TabStop = True
    Me.optSlideOrderNone.Text = "Do not reorder slides"
    Me.optSlideOrderNone.UseVisualStyleBackColor = True
    '
    'optSlideOrderRandom
    '
    Me.optSlideOrderRandom.AutoSize = True
    Me.optSlideOrderRandom.Location = New System.Drawing.Point(150, 133)
    Me.optSlideOrderRandom.Name = "optSlideOrderRandom"
    Me.optSlideOrderRandom.Size = New System.Drawing.Size(173, 21)
    Me.optSlideOrderRandom.TabIndex = 11
    Me.optSlideOrderRandom.TabStop = True
    Me.optSlideOrderRandom.Text = "Order slides randomly"
    Me.optSlideOrderRandom.UseVisualStyleBackColor = True
    '
    'optSlideOrderFileDate
    '
    Me.optSlideOrderFileDate.AutoSize = True
    Me.optSlideOrderFileDate.Location = New System.Drawing.Point(150, 106)
    Me.optSlideOrderFileDate.Name = "optSlideOrderFileDate"
    Me.optSlideOrderFileDate.Size = New System.Drawing.Size(241, 21)
    Me.optSlideOrderFileDate.TabIndex = 10
    Me.optSlideOrderFileDate.TabStop = True
    Me.optSlideOrderFileDate.Text = "Order slides by file modified date"
    Me.optSlideOrderFileDate.UseVisualStyleBackColor = True
    '
    'optSlideOrderPhotoDate
    '
    Me.optSlideOrderPhotoDate.AutoSize = True
    Me.optSlideOrderPhotoDate.Location = New System.Drawing.Point(150, 79)
    Me.optSlideOrderPhotoDate.Name = "optSlideOrderPhotoDate"
    Me.optSlideOrderPhotoDate.Size = New System.Drawing.Size(200, 21)
    Me.optSlideOrderPhotoDate.TabIndex = 9
    Me.optSlideOrderPhotoDate.TabStop = True
    Me.optSlideOrderPhotoDate.Text = "Order slides by photo date"
    Me.optSlideOrderPhotoDate.UseVisualStyleBackColor = True
    '
    'optSlideOrderFilename
    '
    Me.optSlideOrderFilename.AutoSize = True
    Me.optSlideOrderFilename.Location = New System.Drawing.Point(150, 52)
    Me.optSlideOrderFilename.Name = "optSlideOrderFilename"
    Me.optSlideOrderFilename.Size = New System.Drawing.Size(191, 21)
    Me.optSlideOrderFilename.TabIndex = 8
    Me.optSlideOrderFilename.TabStop = True
    Me.optSlideOrderFilename.Text = "Order slides by file name"
    Me.optSlideOrderFilename.UseVisualStyleBackColor = True
    '
    'tabFile
    '
    Me.tabFile.Controls.Add(Me.nmPngCompression)
    Me.tabFile.Controls.Add(Me.Label27)
    Me.tabFile.Controls.Add(Me.chkDelRawFiles)
    Me.tabFile.Controls.Add(Me.nmSendJPGQuality)
    Me.tabFile.Controls.Add(Me.nmJpgQuality)
    Me.tabFile.Controls.Add(Me.chkPNGIndexed)
    Me.tabFile.Controls.Add(Me.Frame2)
    Me.tabFile.Controls.Add(Me.lbJpgCompression)
    Me.tabFile.Controls.Add(Me.lbSendJPGCompression)
    Me.tabFile.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.tabFile.Location = New System.Drawing.Point(4, 26)
    Me.tabFile.Name = "tabFile"
    Me.tabFile.Padding = New System.Windows.Forms.Padding(3)
    Me.tabFile.Size = New System.Drawing.Size(725, 536)
    Me.tabFile.TabIndex = 3
    Me.tabFile.Text = "File and Compression"
    Me.tabFile.UseVisualStyleBackColor = True
    '
    'Label27
    '
    Me.Label27.AutoSize = True
    Me.Label27.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.Label27.Location = New System.Drawing.Point(54, 315)
    Me.Label27.Name = "Label27"
    Me.Label27.Size = New System.Drawing.Size(170, 17)
    Me.Label27.TabIndex = 38
    Me.Label27.Text = "&PNG Compression (0-9):"
    '
    'Frame2
    '
    Me.Frame2.Controls.Add(Me.lbCompression)
    Me.Frame2.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.Frame2.Location = New System.Drawing.Point(37, 128)
    Me.Frame2.Name = "Frame2"
    Me.Frame2.Padding = New System.Windows.Forms.Padding(0)
    Me.Frame2.Size = New System.Drawing.Size(469, 108)
    Me.Frame2.TabIndex = 36
    Me.Frame2.TabStop = False
    Me.Frame2.Text = "JPG Compression"
    '
    'lbCompression
    '
    Me.lbCompression.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lbCompression.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.lbCompression.Location = New System.Drawing.Point(18, 31)
    Me.lbCompression.Name = "lbCompression"
    Me.lbCompression.Size = New System.Drawing.Size(432, 69)
    Me.lbCompression.TabIndex = 37
    Me.lbCompression.Text = "100 is highest quality and lowest compression (largest file). 1 is highest compre" & _
    "ssion and lowest quality. 95 is a good value for most applications."
    '
    'lbJpgCompression
    '
    Me.lbJpgCompression.AutoSize = True
    Me.lbJpgCompression.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.lbJpgCompression.Location = New System.Drawing.Point(54, 48)
    Me.lbJpgCompression.Name = "lbJpgCompression"
    Me.lbJpgCompression.Size = New System.Drawing.Size(136, 17)
    Me.lbJpgCompression.TabIndex = 0
    Me.lbJpgCompression.Text = "&JPG quality (1-100):"
    '
    'lbSendJPGCompression
    '
    Me.lbSendJPGCompression.AutoSize = True
    Me.lbSendJPGCompression.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.lbSendJPGCompression.Location = New System.Drawing.Point(54, 88)
    Me.lbSendJPGCompression.Name = "lbSendJPGCompression"
    Me.lbSendJPGCompression.Size = New System.Drawing.Size(177, 17)
    Me.lbSendJPGCompression.TabIndex = 2
    Me.lbSendJPGCompression.Text = "&Email JPG quality (1-100):"
    '
    'tabExplore
    '
    Me.tabExplore.Controls.Add(Me.nmThumbY)
    Me.tabExplore.Controls.Add(Me.nmThumbX)
    Me.tabExplore.Controls.Add(Me.lbThumbY)
    Me.tabExplore.Controls.Add(Me.lbThumbX)
    Me.tabExplore.Controls.Add(Me.Label2)
    Me.tabExplore.Controls.Add(Me.cmbViewStyle)
    Me.tabExplore.Controls.Add(Me.chkMultiTagPath)
    Me.tabExplore.Location = New System.Drawing.Point(4, 26)
    Me.tabExplore.Name = "tabExplore"
    Me.tabExplore.Padding = New System.Windows.Forms.Padding(3)
    Me.tabExplore.Size = New System.Drawing.Size(725, 536)
    Me.tabExplore.TabIndex = 4
    Me.tabExplore.Text = "Explorer"
    Me.tabExplore.UseVisualStyleBackColor = True
    '
    'Label2
    '
    Me.Label2.AutoSize = True
    Me.Label2.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.Label2.Location = New System.Drawing.Point(120, 74)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(143, 17)
    Me.Label2.TabIndex = 0
    Me.Label2.Text = "File listing &view style:"
    '
    'cmbViewStyle
    '
    Me.cmbViewStyle.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.cmbViewStyle.FormattingEnabled = True
    Me.cmbViewStyle.Location = New System.Drawing.Point(278, 71)
    Me.cmbViewStyle.Name = "cmbViewStyle"
    Me.cmbViewStyle.Size = New System.Drawing.Size(160, 25)
    Me.cmbViewStyle.TabIndex = 1
    '
    'tabWebPage
    '
    Me.tabWebPage.Controls.Add(Me.chkWebTarget)
    Me.tabWebPage.Controls.Add(Me.txWebForecolor)
    Me.tabWebPage.Controls.Add(Me.txWebBackcolor)
    Me.tabWebPage.Controls.Add(Me.chkWebGoogleEvents)
    Me.tabWebPage.Controls.Add(Me.cmbWebCaptionAlign)
    Me.tabWebPage.Controls.Add(Me.Label18)
    Me.tabWebPage.Controls.Add(Me.nmWebShadowSize)
    Me.tabWebPage.Controls.Add(Me.Label19)
    Me.tabWebPage.Controls.Add(Me.chkNormalTitleSize)
    Me.tabWebPage.Controls.Add(Me.chkNormalCaptionSize)
    Me.tabWebPage.Controls.Add(Me.Label16)
    Me.tabWebPage.Controls.Add(Me.nmWebCaptionSize)
    Me.tabWebPage.Controls.Add(Me.nmWebTitleSize)
    Me.tabWebPage.Controls.Add(Me.nmWebCellSpacing)
    Me.tabWebPage.Controls.Add(Me.nmWebCellPadding)
    Me.tabWebPage.Controls.Add(Me.nmWebTableBorder)
    Me.tabWebPage.Controls.Add(Me.nmWebThumbY)
    Me.tabWebPage.Controls.Add(Me.nmWebThumbX)
    Me.tabWebPage.Controls.Add(Me.nmWebnColumns)
    Me.tabWebPage.Controls.Add(Me.txWebGoogleAnalytics)
    Me.tabWebPage.Controls.Add(Me.Label14)
    Me.tabWebPage.Controls.Add(Me.txWebFont)
    Me.tabWebPage.Controls.Add(Me.Label12)
    Me.tabWebPage.Controls.Add(Me.Label11)
    Me.tabWebPage.Controls.Add(Me.Label10)
    Me.tabWebPage.Controls.Add(Me.Label8)
    Me.tabWebPage.Controls.Add(Me.Label7)
    Me.tabWebPage.Controls.Add(Me.Label1)
    Me.tabWebPage.Controls.Add(Me.Label3)
    Me.tabWebPage.Controls.Add(Me.Label5)
    Me.tabWebPage.Controls.Add(Me.cmdWebForeColor)
    Me.tabWebPage.Controls.Add(Me.Label4)
    Me.tabWebPage.Controls.Add(Me.cmdWebBackColor)
    Me.tabWebPage.Controls.Add(Me.chkWebConvertUTCtoLocal)
    Me.tabWebPage.Location = New System.Drawing.Point(4, 26)
    Me.tabWebPage.Name = "tabWebPage"
    Me.tabWebPage.Padding = New System.Windows.Forms.Padding(3)
    Me.tabWebPage.Size = New System.Drawing.Size(725, 536)
    Me.tabWebPage.TabIndex = 5
    Me.tabWebPage.Text = "Web Page"
    Me.tabWebPage.UseVisualStyleBackColor = True
    '
    'cmbWebCaptionAlign
    '
    Me.cmbWebCaptionAlign.FormattingEnabled = True
    Me.cmbWebCaptionAlign.Items.AddRange(New Object() {"center", "left", "right"})
    Me.cmbWebCaptionAlign.Location = New System.Drawing.Point(345, 327)
    Me.cmbWebCaptionAlign.Name = "cmbWebCaptionAlign"
    Me.cmbWebCaptionAlign.Size = New System.Drawing.Size(206, 25)
    Me.cmbWebCaptionAlign.TabIndex = 30
    '
    'Label18
    '
    Me.Label18.AutoSize = True
    Me.Label18.Location = New System.Drawing.Point(94, 330)
    Me.Label18.Name = "Label18"
    Me.Label18.Size = New System.Drawing.Size(129, 17)
    Me.Label18.TabIndex = 28
    Me.Label18.Text = "Ca&ption alignment:"
    '
    'Label19
    '
    Me.Label19.AutoSize = True
    Me.Label19.Location = New System.Drawing.Point(94, 143)
    Me.Label19.Name = "Label19"
    Me.Label19.Size = New System.Drawing.Size(209, 17)
    Me.Label19.TabIndex = 9
    Me.Label19.Text = "&Drop shadow size (0 for none):"
    '
    'chkNormalTitleSize
    '
    Me.chkNormalTitleSize.AutoSize = True
    Me.chkNormalTitleSize.Location = New System.Drawing.Point(430, 270)
    Me.chkNormalTitleSize.Name = "chkNormalTitleSize"
    Me.chkNormalTitleSize.Size = New System.Drawing.Size(140, 21)
    Me.chkNormalTitleSize.TabIndex = 19
    Me.chkNormalTitleSize.Text = "Use Normal Size"
    Me.chkNormalTitleSize.UseVisualStyleBackColor = True
    '
    'chkNormalCaptionSize
    '
    Me.chkNormalCaptionSize.AutoSize = True
    Me.chkNormalCaptionSize.Location = New System.Drawing.Point(430, 297)
    Me.chkNormalCaptionSize.Name = "chkNormalCaptionSize"
    Me.chkNormalCaptionSize.Size = New System.Drawing.Size(140, 21)
    Me.chkNormalCaptionSize.TabIndex = 22
    Me.chkNormalCaptionSize.Text = "Use Normal Size"
    Me.chkNormalCaptionSize.UseVisualStyleBackColor = True
    '
    'Label16
    '
    Me.Label16.AutoSize = True
    Me.Label16.Location = New System.Drawing.Point(94, 236)
    Me.Label16.Name = "Label16"
    Me.Label16.Size = New System.Drawing.Size(147, 17)
    Me.Label16.TabIndex = 15
    Me.Label16.Text = "Space bet&ween cells:"
    '
    'Label14
    '
    Me.Label14.AutoSize = True
    Me.Label14.Location = New System.Drawing.Point(94, 392)
    Me.Label14.Name = "Label14"
    Me.Label14.Size = New System.Drawing.Size(220, 17)
    Me.Label14.TabIndex = 25
    Me.Label14.Text = "&Google Analytics code (or blank):"
    '
    'Label12
    '
    Me.Label12.AutoSize = True
    Me.Label12.Location = New System.Drawing.Point(94, 361)
    Me.Label12.Name = "Label12"
    Me.Label12.Size = New System.Drawing.Size(82, 17)
    Me.Label12.TabIndex = 23
    Me.Label12.Text = "&Font name:"
    '
    'Label11
    '
    Me.Label11.AutoSize = True
    Me.Label11.Location = New System.Drawing.Point(94, 298)
    Me.Label11.Name = "Label11"
    Me.Label11.Size = New System.Drawing.Size(173, 17)
    Me.Label11.TabIndex = 20
    Me.Label11.Text = "Caption text si&ze (points):"
    '
    'Label10
    '
    Me.Label10.AutoSize = True
    Me.Label10.Location = New System.Drawing.Point(94, 267)
    Me.Label10.Name = "Label10"
    Me.Label10.Size = New System.Drawing.Size(149, 17)
    Me.Label10.TabIndex = 17
    Me.Label10.Text = "Title te&xt size (points):"
    '
    'Label8
    '
    Me.Label8.AutoSize = True
    Me.Label8.Location = New System.Drawing.Point(94, 205)
    Me.Label8.Name = "Label8"
    Me.Label8.Size = New System.Drawing.Size(189, 17)
    Me.Label8.TabIndex = 13
    Me.Label8.Text = "S&pace around cell contents:"
    '
    'Label7
    '
    Me.Label7.AutoSize = True
    Me.Label7.Location = New System.Drawing.Point(94, 174)
    Me.Label7.Name = "Label7"
    Me.Label7.Size = New System.Drawing.Size(123, 17)
    Me.Label7.TabIndex = 11
    Me.Label7.Text = "T&able border size:"
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Location = New System.Drawing.Point(94, 112)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(210, 17)
    Me.Label1.TabIndex = 6
    Me.Label1.Text = "&Thumbnail size (width, height): "
    '
    'Label3
    '
    Me.Label3.AutoSize = True
    Me.Label3.Location = New System.Drawing.Point(94, 81)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(208, 17)
    Me.Label3.TabIndex = 4
    Me.Label3.Text = "&Number of thumbnails per row:"
    '
    'Label5
    '
    Me.Label5.AutoSize = True
    Me.Label5.Location = New System.Drawing.Point(94, 50)
    Me.Label5.Name = "Label5"
    Me.Label5.Size = New System.Drawing.Size(74, 17)
    Me.Label5.TabIndex = 2
    Me.Label5.Text = "Text &color:"
    '
    'Label4
    '
    Me.Label4.AutoSize = True
    Me.Label4.Location = New System.Drawing.Point(94, 22)
    Me.Label4.Name = "Label4"
    Me.Label4.Size = New System.Drawing.Size(126, 17)
    Me.Label4.TabIndex = 0
    Me.Label4.Text = "&Background color:"
    '
    'tabDatabase
    '
    Me.tabDatabase.Controls.Add(Me.cmdTest)
    Me.tabDatabase.Controls.Add(Me.Panel1)
    Me.tabDatabase.Location = New System.Drawing.Point(4, 26)
    Me.tabDatabase.Name = "tabDatabase"
    Me.tabDatabase.Size = New System.Drawing.Size(725, 536)
    Me.tabDatabase.TabIndex = 6
    Me.tabDatabase.Text = "Database"
    Me.tabDatabase.UseVisualStyleBackColor = True
    '
    'cmdTest
    '
    Me.cmdTest.Location = New System.Drawing.Point(268, 403)
    Me.cmdTest.Name = "cmdTest"
    Me.cmdTest.Size = New System.Drawing.Size(118, 37)
    Me.cmdTest.TabIndex = 1
    Me.cmdTest.Text = "&Test settings"
    Me.cmdTest.UseVisualStyleBackColor = True
    '
    'Panel1
    '
    Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.Panel1.Controls.Add(Me.Label26)
    Me.Panel1.Controls.Add(Me.txBugPath)
    Me.Panel1.Controls.Add(Me.Label25)
    Me.Panel1.Controls.Add(Me.txDBpassword)
    Me.Panel1.Controls.Add(Me.txDBuser)
    Me.Panel1.Controls.Add(Me.txDBdatabase)
    Me.Panel1.Controls.Add(Me.txDBhost)
    Me.Panel1.Controls.Add(Me.Label24)
    Me.Panel1.Controls.Add(Me.Label23)
    Me.Panel1.Controls.Add(Me.Label22)
    Me.Panel1.Controls.Add(Me.Label21)
    Me.Panel1.Controls.Add(Me.Label20)
    Me.Panel1.Location = New System.Drawing.Point(88, 82)
    Me.Panel1.Name = "Panel1"
    Me.Panel1.Size = New System.Drawing.Size(494, 281)
    Me.Panel1.TabIndex = 0
    '
    'Label26
    '
    Me.Label26.AutoSize = True
    Me.Label26.Location = New System.Drawing.Point(69, 235)
    Me.Label26.Name = "Label26"
    Me.Label26.Size = New System.Drawing.Size(97, 17)
    Me.Label26.TabIndex = 42
    Me.Label26.Text = "&Image Folder:"
    '
    'txBugPath
    '
    Me.txBugPath.Location = New System.Drawing.Point(215, 232)
    Me.txBugPath.Name = "txBugPath"
    Me.txBugPath.Size = New System.Drawing.Size(212, 25)
    Me.txBugPath.TabIndex = 41
    Me.txBugPath.Text = "c:\bugs\bugpage\images"
    '
    'Label25
    '
    Me.Label25.AutoSize = True
    Me.Label25.Location = New System.Drawing.Point(69, 48)
    Me.Label25.Name = "Label25"
    Me.Label25.Size = New System.Drawing.Size(95, 17)
    Me.Label25.TabIndex = 40
    Me.Label25.Text = "(for bug data)"
    '
    'txDBpassword
    '
    Me.txDBpassword.Location = New System.Drawing.Point(215, 192)
    Me.txDBpassword.Name = "txDBpassword"
    Me.txDBpassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
    Me.txDBpassword.Size = New System.Drawing.Size(212, 25)
    Me.txDBpassword.TabIndex = 8
    Me.txDBpassword.Text = "password"
    '
    'txDBuser
    '
    Me.txDBuser.Location = New System.Drawing.Point(215, 161)
    Me.txDBuser.Name = "txDBuser"
    Me.txDBuser.Size = New System.Drawing.Size(212, 25)
    Me.txDBuser.TabIndex = 6
    Me.txDBuser.Text = "bugs"
    '
    'txDBdatabase
    '
    Me.txDBdatabase.Location = New System.Drawing.Point(215, 130)
    Me.txDBdatabase.Name = "txDBdatabase"
    Me.txDBdatabase.Size = New System.Drawing.Size(212, 25)
    Me.txDBdatabase.TabIndex = 4
    Me.txDBdatabase.Text = "taxa"
    '
    'txDBhost
    '
    Me.txDBhost.Location = New System.Drawing.Point(215, 99)
    Me.txDBhost.Name = "txDBhost"
    Me.txDBhost.Size = New System.Drawing.Size(212, 25)
    Me.txDBhost.TabIndex = 2
    Me.txDBhost.Text = "localhost"
    '
    'Label24
    '
    Me.Label24.AutoSize = True
    Me.Label24.Location = New System.Drawing.Point(69, 30)
    Me.Label24.Name = "Label24"
    Me.Label24.Size = New System.Drawing.Size(198, 17)
    Me.Label24.TabIndex = 39
    Me.Label24.Text = "MySQL Database Information"
    '
    'Label23
    '
    Me.Label23.AutoSize = True
    Me.Label23.Location = New System.Drawing.Point(69, 195)
    Me.Label23.Name = "Label23"
    Me.Label23.Size = New System.Drawing.Size(78, 17)
    Me.Label23.TabIndex = 7
    Me.Label23.Text = "&Password:"
    '
    'Label22
    '
    Me.Label22.AutoSize = True
    Me.Label22.Location = New System.Drawing.Point(69, 164)
    Me.Label22.Name = "Label22"
    Me.Label22.Size = New System.Drawing.Size(84, 17)
    Me.Label22.TabIndex = 5
    Me.Label22.Text = "&User name:"
    '
    'Label21
    '
    Me.Label21.AutoSize = True
    Me.Label21.Location = New System.Drawing.Point(69, 133)
    Me.Label21.Name = "Label21"
    Me.Label21.Size = New System.Drawing.Size(116, 17)
    Me.Label21.TabIndex = 3
    Me.Label21.Text = "&Database name:"
    '
    'Label20
    '
    Me.Label20.AutoSize = True
    Me.Label20.Location = New System.Drawing.Point(69, 102)
    Me.Label20.Name = "Label20"
    Me.Label20.Size = New System.Drawing.Size(91, 17)
    Me.Label20.TabIndex = 1
    Me.Label20.Text = "&MySQL host:"
    '
    'TabMail
    '
    Me.TabMail.Controls.Add(Me.cmdEmailTest)
    Me.TabMail.Controls.Add(Me.Panel2)
    Me.TabMail.Location = New System.Drawing.Point(4, 26)
    Me.TabMail.Name = "TabMail"
    Me.TabMail.Size = New System.Drawing.Size(725, 536)
    Me.TabMail.TabIndex = 7
    Me.TabMail.Text = "Email"
    Me.TabMail.UseVisualStyleBackColor = True
    '
    'cmdEmailTest
    '
    Me.cmdEmailTest.Location = New System.Drawing.Point(287, 412)
    Me.cmdEmailTest.Name = "cmdEmailTest"
    Me.cmdEmailTest.Size = New System.Drawing.Size(140, 37)
    Me.cmdEmailTest.TabIndex = 3
    Me.cmdEmailTest.Text = "&Send test email"
    Me.cmdEmailTest.UseVisualStyleBackColor = True
    '
    'Panel2
    '
    Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.Panel2.Controls.Add(Me.Label28)
    Me.Panel2.Controls.Add(Me.txEmailPort)
    Me.Panel2.Controls.Add(Me.txEmailPassword)
    Me.Panel2.Controls.Add(Me.txEmailHost)
    Me.Panel2.Controls.Add(Me.txEmailAccount)
    Me.Panel2.Controls.Add(Me.Label30)
    Me.Panel2.Controls.Add(Me.Label31)
    Me.Panel2.Controls.Add(Me.Label32)
    Me.Panel2.Controls.Add(Me.Label34)
    Me.Panel2.Location = New System.Drawing.Point(115, 89)
    Me.Panel2.Name = "Panel2"
    Me.Panel2.Size = New System.Drawing.Size(494, 253)
    Me.Panel2.TabIndex = 2
    '
    'Label28
    '
    Me.Label28.AutoSize = True
    Me.Label28.Location = New System.Drawing.Point(69, 183)
    Me.Label28.Name = "Label28"
    Me.Label28.Size = New System.Drawing.Size(93, 17)
    Me.Label28.TabIndex = 17
    Me.Label28.Text = "Port &number:"
    '
    'txEmailPort
    '
    Me.txEmailPort.BackColor = System.Drawing.SystemColors.Window
    Me.txEmailPort.Location = New System.Drawing.Point(215, 180)
    Me.txEmailPort.Name = "txEmailPort"
    Me.txEmailPort.Size = New System.Drawing.Size(212, 25)
    Me.txEmailPort.TabIndex = 18
    Me.txEmailPort.Text = "25"
    '
    'txEmailPassword
    '
    Me.txEmailPassword.Location = New System.Drawing.Point(215, 118)
    Me.txEmailPassword.Name = "txEmailPassword"
    Me.txEmailPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
    Me.txEmailPassword.Size = New System.Drawing.Size(212, 25)
    Me.txEmailPassword.TabIndex = 14
    Me.txEmailPassword.Text = "password"
    '
    'txEmailHost
    '
    Me.txEmailHost.Location = New System.Drawing.Point(215, 149)
    Me.txEmailHost.Name = "txEmailHost"
    Me.txEmailHost.Size = New System.Drawing.Size(212, 25)
    Me.txEmailHost.TabIndex = 15
    Me.txEmailHost.Text = "smtp.gmail.com"
    '
    'txEmailAccount
    '
    Me.txEmailAccount.Location = New System.Drawing.Point(215, 87)
    Me.txEmailAccount.Name = "txEmailAccount"
    Me.txEmailAccount.Size = New System.Drawing.Size(212, 25)
    Me.txEmailAccount.TabIndex = 12
    Me.txEmailAccount.Text = "name@gmail.com"
    '
    'Label30
    '
    Me.Label30.AutoSize = True
    Me.Label30.Location = New System.Drawing.Point(69, 30)
    Me.Label30.Name = "Label30"
    Me.Label30.Size = New System.Drawing.Size(165, 17)
    Me.Label30.TabIndex = 39
    Me.Label30.Text = "Outgoing Email Settings"
    '
    'Label31
    '
    Me.Label31.AutoSize = True
    Me.Label31.Location = New System.Drawing.Point(69, 121)
    Me.Label31.Name = "Label31"
    Me.Label31.Size = New System.Drawing.Size(78, 17)
    Me.Label31.TabIndex = 13
    Me.Label31.Text = "&Password:"
    '
    'Label32
    '
    Me.Label32.AutoSize = True
    Me.Label32.Location = New System.Drawing.Point(69, 152)
    Me.Label32.Name = "Label32"
    Me.Label32.Size = New System.Drawing.Size(83, 17)
    Me.Label32.TabIndex = 15
    Me.Label32.Text = "&Host name:"
    '
    'Label34
    '
    Me.Label34.AutoSize = True
    Me.Label34.Location = New System.Drawing.Point(69, 90)
    Me.Label34.Name = "Label34"
    Me.Label34.Size = New System.Drawing.Size(106, 17)
    Me.Label34.TabIndex = 11
    Me.Label34.Text = "&Account name:"
    '
    'frmOptions
    '
    Me.AcceptButton = Me.cmdOK
    Me.CancelButton = Me.cmdCancel
    Me.ClientSize = New System.Drawing.Size(757, 654)
    Me.Controls.Add(Me.tab1)
    Me.Controls.Add(Me.cmdHelp)
    Me.Controls.Add(Me.cmdReset)
    Me.Controls.Add(Me.cmdCancel)
    Me.Controls.Add(Me.cmdOK)
    Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.Location = New System.Drawing.Point(3, 23)
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "frmOptions"
    Me.ShowInTaskbar = False
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
    Me.Text = "Options"
    CType(Me.nmColorTolerance, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.nmSlideFadeTime, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.nmSlideRate, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.nmThumbY, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.nmThumbX, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.nmWebCaptionSize, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.nmWebTitleSize, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.nmWebCellSpacing, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.nmWebCellPadding, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.nmWebTableBorder, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.nmWebThumbY, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.nmWebThumbX, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.nmWebnColumns, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.nmWebShadowSize, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.nmJpgQuality, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.nmSendJPGQuality, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.nmPngCompression, System.ComponentModel.ISupportInitialize).EndInit()
    Me.tab1.ResumeLayout(False)
    Me.tabGeneral.ResumeLayout(False)
    Me.tabGeneral.PerformLayout()
    Me.tabEditing.ResumeLayout(False)
    Me.tabEditing.PerformLayout()
    Me.tabSlideShow.ResumeLayout(False)
    Me.tabSlideShow.PerformLayout()
    Me.tabFile.ResumeLayout(False)
    Me.tabFile.PerformLayout()
    Me.Frame2.ResumeLayout(False)
    Me.tabExplore.ResumeLayout(False)
    Me.tabExplore.PerformLayout()
    Me.tabWebPage.ResumeLayout(False)
    Me.tabWebPage.PerformLayout()
    Me.tabDatabase.ResumeLayout(False)
    Me.Panel1.ResumeLayout(False)
    Me.Panel1.PerformLayout()
    Me.TabMail.ResumeLayout(False)
    Me.Panel2.ResumeLayout(False)
    Me.Panel2.PerformLayout()
    Me.ResumeLayout(False)

  End Sub
  Public WithEvents cmdOK As System.Windows.Forms.Button
  Public WithEvents cmdCancel As System.Windows.Forms.Button
  Public WithEvents cmdReset As System.Windows.Forms.Button
  Public WithEvents cmdHelp As System.Windows.Forms.Button
  Public WithEvents chkViewToolbar As System.Windows.Forms.CheckBox
  Public WithEvents lbslideRate As System.Windows.Forms.Label
  Public WithEvents chkSlideShowName As System.Windows.Forms.CheckBox
  Public WithEvents chkSlideShowDescription As System.Windows.Forms.CheckBox
  Public WithEvents chkShowTips As System.Windows.Forms.CheckBox
  Friend WithEvents tab1 As System.Windows.Forms.TabControl
  Friend WithEvents tabGeneral As System.Windows.Forms.TabPage
  Friend WithEvents tabEditing As System.Windows.Forms.TabPage
  Friend WithEvents tabSlideShow As System.Windows.Forms.TabPage
  Public WithEvents chkDateInCommentCommand As System.Windows.Forms.CheckBox
  Public WithEvents chkMultiUndo As System.Windows.Forms.CheckBox
  Public WithEvents chkZoomOne As System.Windows.Forms.CheckBox
  Public WithEvents lbLowerTolerance As System.Windows.Forms.Label
  Friend WithEvents tabExplore As System.Windows.Forms.TabPage
  Public WithEvents chkMultiTagPath As System.Windows.Forms.CheckBox
  Friend WithEvents Label2 As System.Windows.Forms.Label
  Friend WithEvents cmbViewStyle As System.Windows.Forms.ComboBox
  Friend WithEvents tabWebPage As System.Windows.Forms.TabPage
  Friend WithEvents chkWebConvertUTCtoLocal As System.Windows.Forms.CheckBox
  Friend WithEvents Label5 As System.Windows.Forms.Label
  Friend WithEvents cmdWebForeColor As System.Windows.Forms.Button
  Friend WithEvents Label4 As System.Windows.Forms.Label
  Friend WithEvents cmdWebBackColor As System.Windows.Forms.Button
  Friend WithEvents cmdFileAssoc As System.Windows.Forms.Button
  Friend WithEvents cmbButtonSize As System.Windows.Forms.ComboBox
  Friend WithEvents cmdToolbar As System.Windows.Forms.Button
  Friend WithEvents Label6 As System.Windows.Forms.Label
  Friend WithEvents lbThumbY As System.Windows.Forms.Label
  Friend WithEvents lbThumbX As System.Windows.Forms.Label
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents Label3 As System.Windows.Forms.Label
  Friend WithEvents txWebGoogleAnalytics As System.Windows.Forms.TextBox
  Friend WithEvents Label14 As System.Windows.Forms.Label
  Friend WithEvents txWebFont As System.Windows.Forms.TextBox
  Friend WithEvents Label12 As System.Windows.Forms.Label
  Friend WithEvents Label11 As System.Windows.Forms.Label
  Friend WithEvents Label10 As System.Windows.Forms.Label
  Friend WithEvents Label8 As System.Windows.Forms.Label
  Friend WithEvents Label7 As System.Windows.Forms.Label
  Friend WithEvents nmColorTolerance As System.Windows.Forms.NumericUpDown
  Friend WithEvents nmSlideRate As System.Windows.Forms.NumericUpDown
  Friend WithEvents nmThumbY As System.Windows.Forms.NumericUpDown
  Friend WithEvents nmThumbX As System.Windows.Forms.NumericUpDown
  Friend WithEvents nmWebThumbY As System.Windows.Forms.NumericUpDown
  Friend WithEvents nmWebThumbX As System.Windows.Forms.NumericUpDown
  Friend WithEvents nmWebnColumns As System.Windows.Forms.NumericUpDown
  Friend WithEvents nmWebTableBorder As System.Windows.Forms.NumericUpDown
  Friend WithEvents nmWebCaptionSize As System.Windows.Forms.NumericUpDown
  Friend WithEvents nmWebTitleSize As System.Windows.Forms.NumericUpDown
  Friend WithEvents nmWebCellSpacing As System.Windows.Forms.NumericUpDown
  Friend WithEvents nmWebCellPadding As System.Windows.Forms.NumericUpDown
  Friend WithEvents Label16 As System.Windows.Forms.Label
  Friend WithEvents chkNormalCaptionSize As System.Windows.Forms.CheckBox
  Friend WithEvents chkNormalTitleSize As System.Windows.Forms.CheckBox
  Friend WithEvents nmSlideFadeTime As System.Windows.Forms.NumericUpDown
  Public WithEvents Label17 As System.Windows.Forms.Label
  Friend WithEvents nmWebShadowSize As System.Windows.Forms.NumericUpDown
  Friend WithEvents Label19 As System.Windows.Forms.Label
  Friend WithEvents optSlideOrderPhotoDate As System.Windows.Forms.RadioButton
  Friend WithEvents optSlideOrderFilename As System.Windows.Forms.RadioButton
  Friend WithEvents optSlideOrderNone As System.Windows.Forms.RadioButton
  Friend WithEvents optSlideOrderRandom As System.Windows.Forms.RadioButton
  Friend WithEvents optSlideOrderFileDate As System.Windows.Forms.RadioButton
  Public WithEvents chkSlideshowPhotoDate As System.Windows.Forms.CheckBox
  Public WithEvents chkAdjustIndColor As System.Windows.Forms.CheckBox
  Public WithEvents chkAdjustIndIntensity As System.Windows.Forms.CheckBox
  Public WithEvents chkAdjustPreserveIntensity As System.Windows.Forms.CheckBox
  Friend WithEvents Label18 As System.Windows.Forms.Label
  Friend WithEvents cmbWebCaptionAlign As System.Windows.Forms.ComboBox
  Public WithEvents chkDisableUndo As System.Windows.Forms.CheckBox
  Friend WithEvents chkWebGoogleEvents As System.Windows.Forms.CheckBox
  Friend WithEvents txWebForecolor As System.Windows.Forms.TextBox
  Friend WithEvents txWebBackcolor As System.Windows.Forms.TextBox
  Friend WithEvents tabDatabase As System.Windows.Forms.TabPage
  Friend WithEvents Panel1 As System.Windows.Forms.Panel
  Friend WithEvents Label23 As System.Windows.Forms.Label
  Friend WithEvents Label22 As System.Windows.Forms.Label
  Friend WithEvents Label21 As System.Windows.Forms.Label
  Friend WithEvents Label20 As System.Windows.Forms.Label
  Friend WithEvents txDBpassword As System.Windows.Forms.TextBox
  Friend WithEvents txDBuser As System.Windows.Forms.TextBox
  Friend WithEvents txDBdatabase As System.Windows.Forms.TextBox
  Friend WithEvents txDBhost As System.Windows.Forms.TextBox
  Friend WithEvents Label24 As System.Windows.Forms.Label
  Friend WithEvents cmdTest As System.Windows.Forms.Button
  Friend WithEvents Label25 As System.Windows.Forms.Label
  Friend WithEvents Label26 As System.Windows.Forms.Label
  Friend WithEvents txBugPath As System.Windows.Forms.TextBox
  Friend WithEvents chkWebTarget As System.Windows.Forms.CheckBox
  Friend WithEvents TabMail As System.Windows.Forms.TabPage
  Friend WithEvents cmdEmailTest As System.Windows.Forms.Button
  Friend WithEvents Panel2 As System.Windows.Forms.Panel
  Friend WithEvents Label28 As System.Windows.Forms.Label
  Friend WithEvents txEmailPort As System.Windows.Forms.TextBox
  Friend WithEvents txEmailPassword As System.Windows.Forms.TextBox
  Friend WithEvents txEmailHost As System.Windows.Forms.TextBox
  Friend WithEvents txEmailAccount As System.Windows.Forms.TextBox
  Friend WithEvents Label30 As System.Windows.Forms.Label
  Friend WithEvents Label31 As System.Windows.Forms.Label
  Friend WithEvents Label32 As System.Windows.Forms.Label
  Friend WithEvents Label34 As System.Windows.Forms.Label
  Friend WithEvents tabFile As System.Windows.Forms.TabPage
  Friend WithEvents nmPngCompression As System.Windows.Forms.NumericUpDown
  Public WithEvents Label27 As System.Windows.Forms.Label
  Friend WithEvents chkDelRawFiles As System.Windows.Forms.CheckBox
  Friend WithEvents nmSendJPGQuality As System.Windows.Forms.NumericUpDown
  Friend WithEvents nmJpgQuality As System.Windows.Forms.NumericUpDown
  Friend WithEvents chkPNGIndexed As System.Windows.Forms.CheckBox
  Public WithEvents Frame2 As System.Windows.Forms.GroupBox
  Public WithEvents lbCompression As System.Windows.Forms.Label
  Public WithEvents lbJpgCompression As System.Windows.Forms.Label
  Public WithEvents lbSendJPGCompression As System.Windows.Forms.Label
#End Region
End Class