Imports System.Resources

Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' TODO: Review the values of the assembly attributes
<Assembly: AssemblyTitle("Photo Mud")> 
<Assembly: AssemblyDescription("A Very Nice Program")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("")> 
<Assembly: AssemblyCopyright("Bob")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: AssemblyCulture("")> 

' Version information for an assembly consists of the following four values:

'	Major version
'	Minor Version
'	Build Number
'	Revision

' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:
<Assembly: AssemblyVersion("6.0.0.*")> 
<Assembly: AssemblyFileVersionAttribute("6.0")> 
<Assembly: NeutralResourcesLanguageAttribute("en-US")> 
<Assembly: ComVisibleAttribute(False)> 
<Assembly: GuidAttribute("F9168C5E-CEB2-4faa-B6BF-329BF39FA1E4")> 