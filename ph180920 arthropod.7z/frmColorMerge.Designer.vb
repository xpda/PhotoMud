<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmColorMerge
#Region "Windows Form Designer generated code "
  <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
    MyBase.New()
    'This call is required by the Windows Form Designer.
    InitializeComponent()
  End Sub
  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
    If Disposing Then
      If Not components Is Nothing Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(Disposing)
  End Sub
  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer
  Public ToolTip1 As ToolTip
  Public WithEvents chkWeight As CheckBox
  Public WithEvents txPath9 As TextBox
  Public WithEvents txR9 As TextBox
  Public WithEvents txG9 As TextBox
  Public WithEvents txWeight9 As TextBox
  Public WithEvents txB9 As TextBox
  Public WithEvents txB8 As TextBox
  Public WithEvents Opt7 As RadioButton
  Public WithEvents txWeight8 As TextBox
  Public WithEvents txG8 As TextBox
  Public WithEvents txR8 As TextBox
  Public WithEvents txPath8 As TextBox
  Public WithEvents txWeight7 As TextBox
  Public WithEvents txB7 As TextBox
  Public WithEvents txG7 As TextBox
  Public WithEvents txR7 As TextBox
  Public WithEvents txPath7 As TextBox
  Public WithEvents txWeight6 As TextBox
  Public WithEvents txB6 As TextBox
  Public WithEvents txG6 As TextBox
  Public WithEvents txR6 As TextBox
  Public WithEvents txPath6 As TextBox
  Public WithEvents txWeight5 As TextBox
  Public WithEvents txB5 As TextBox
  Public WithEvents txG5 As TextBox
  Public WithEvents txR5 As TextBox
  Public WithEvents txPath5 As TextBox
  Public WithEvents txWeight4 As TextBox
  Public WithEvents txB4 As TextBox
  Public WithEvents txG4 As TextBox
  Public WithEvents txR4 As TextBox
  Public WithEvents txPath4 As TextBox
  Public WithEvents txWeight3 As TextBox
  Public WithEvents txB3 As TextBox
  Public WithEvents txG3 As TextBox
  Public WithEvents txR3 As TextBox
  Public WithEvents txPath3 As TextBox
  Public WithEvents txWeight2 As TextBox
  Public WithEvents txB2 As TextBox
  Public WithEvents txG2 As TextBox
  Public WithEvents txR2 As TextBox
  Public WithEvents txPath2 As TextBox
  Public WithEvents txWeight1 As TextBox
  Public WithEvents txB1 As TextBox
  Public WithEvents txG1 As TextBox
  Public WithEvents txR1 As TextBox
  Public WithEvents txPath1 As TextBox
  Public WithEvents txWeight0 As TextBox
  Public WithEvents txB0 As TextBox
  Public WithEvents txG0 As TextBox
  Public WithEvents txR0 As TextBox
  Public WithEvents txPath0 As TextBox
  Public WithEvents Opt6 As RadioButton
  Public WithEvents cmdOK As Button
  Public WithEvents cmdCancel As Button
  Public WithEvents Opt5 As RadioButton
  Public WithEvents Opt4 As RadioButton
  Public WithEvents Opt3 As RadioButton
  Public WithEvents Opt2 As RadioButton
  Public WithEvents Opt1 As RadioButton
  Public WithEvents Opt0 As RadioButton
  Public WithEvents lbFilename As Label
  Public WithEvents lbWeight As Label
  Public WithEvents lbBlue As Label
  Public WithEvents lbGreen As Label
  Public WithEvents lbRed As Label
  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container()
    Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmColorMerge))
    Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
    Me.cmdZoomout = New System.Windows.Forms.Button()
    Me.cmdZoomin = New System.Windows.Forms.Button()
    Me.cmdHelp = New System.Windows.Forms.Button()
    Me.chkWeight = New System.Windows.Forms.CheckBox()
    Me.txR9 = New System.Windows.Forms.TextBox()
    Me.txG9 = New System.Windows.Forms.TextBox()
    Me.txWeight9 = New System.Windows.Forms.TextBox()
    Me.txB9 = New System.Windows.Forms.TextBox()
    Me.txB8 = New System.Windows.Forms.TextBox()
    Me.Opt7 = New System.Windows.Forms.RadioButton()
    Me.txWeight8 = New System.Windows.Forms.TextBox()
    Me.txG8 = New System.Windows.Forms.TextBox()
    Me.txR8 = New System.Windows.Forms.TextBox()
    Me.txWeight7 = New System.Windows.Forms.TextBox()
    Me.txB7 = New System.Windows.Forms.TextBox()
    Me.txG7 = New System.Windows.Forms.TextBox()
    Me.txR7 = New System.Windows.Forms.TextBox()
    Me.txWeight6 = New System.Windows.Forms.TextBox()
    Me.txB6 = New System.Windows.Forms.TextBox()
    Me.txG6 = New System.Windows.Forms.TextBox()
    Me.txR6 = New System.Windows.Forms.TextBox()
    Me.txWeight5 = New System.Windows.Forms.TextBox()
    Me.txB5 = New System.Windows.Forms.TextBox()
    Me.txG5 = New System.Windows.Forms.TextBox()
    Me.txR5 = New System.Windows.Forms.TextBox()
    Me.txWeight4 = New System.Windows.Forms.TextBox()
    Me.txB4 = New System.Windows.Forms.TextBox()
    Me.txG4 = New System.Windows.Forms.TextBox()
    Me.txR4 = New System.Windows.Forms.TextBox()
    Me.txWeight3 = New System.Windows.Forms.TextBox()
    Me.txB3 = New System.Windows.Forms.TextBox()
    Me.txG3 = New System.Windows.Forms.TextBox()
    Me.txR3 = New System.Windows.Forms.TextBox()
    Me.txWeight2 = New System.Windows.Forms.TextBox()
    Me.txB2 = New System.Windows.Forms.TextBox()
    Me.txG2 = New System.Windows.Forms.TextBox()
    Me.txR2 = New System.Windows.Forms.TextBox()
    Me.txWeight1 = New System.Windows.Forms.TextBox()
    Me.txB1 = New System.Windows.Forms.TextBox()
    Me.txG1 = New System.Windows.Forms.TextBox()
    Me.txR1 = New System.Windows.Forms.TextBox()
    Me.txWeight0 = New System.Windows.Forms.TextBox()
    Me.txB0 = New System.Windows.Forms.TextBox()
    Me.txG0 = New System.Windows.Forms.TextBox()
    Me.txR0 = New System.Windows.Forms.TextBox()
    Me.Opt6 = New System.Windows.Forms.RadioButton()
    Me.Opt5 = New System.Windows.Forms.RadioButton()
    Me.Opt4 = New System.Windows.Forms.RadioButton()
    Me.Opt3 = New System.Windows.Forms.RadioButton()
    Me.Opt2 = New System.Windows.Forms.RadioButton()
    Me.Opt1 = New System.Windows.Forms.RadioButton()
    Me.Opt0 = New System.Windows.Forms.RadioButton()
    Me.lbWeight = New System.Windows.Forms.Label()
    Me.cmdOK = New System.Windows.Forms.Button()
    Me.cmdCancel = New System.Windows.Forms.Button()
    Me.txPath9 = New System.Windows.Forms.TextBox()
    Me.txPath8 = New System.Windows.Forms.TextBox()
    Me.txPath7 = New System.Windows.Forms.TextBox()
    Me.txPath6 = New System.Windows.Forms.TextBox()
    Me.txPath5 = New System.Windows.Forms.TextBox()
    Me.txPath4 = New System.Windows.Forms.TextBox()
    Me.txPath3 = New System.Windows.Forms.TextBox()
    Me.txPath2 = New System.Windows.Forms.TextBox()
    Me.txPath1 = New System.Windows.Forms.TextBox()
    Me.txPath0 = New System.Windows.Forms.TextBox()
    Me.lbFilename = New System.Windows.Forms.Label()
    Me.lbBlue = New System.Windows.Forms.Label()
    Me.lbGreen = New System.Windows.Forms.Label()
    Me.lbRed = New System.Windows.Forms.Label()
    Me.pView = New PhotoMud.pViewer()
    CType(Me.pView, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'cmdZoomout
    '
    Me.cmdZoomout.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.cmdZoomout.Image = CType(resources.GetObject("cmdZoomout.Image"), System.Drawing.Image)
    Me.cmdZoomout.Location = New System.Drawing.Point(555, 455)
    Me.cmdZoomout.Name = "cmdZoomout"
    Me.cmdZoomout.Size = New System.Drawing.Size(41, 41)
    Me.cmdZoomout.TabIndex = 75
    Me.cmdZoomout.TextAlign = System.Drawing.ContentAlignment.BottomCenter
    Me.ToolTip1.SetToolTip(Me.cmdZoomout, "Zoom Out")
    Me.cmdZoomout.UseVisualStyleBackColor = False
    '
    'cmdZoomin
    '
    Me.cmdZoomin.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.cmdZoomin.Image = CType(resources.GetObject("cmdZoomin.Image"), System.Drawing.Image)
    Me.cmdZoomin.Location = New System.Drawing.Point(555, 408)
    Me.cmdZoomin.Name = "cmdZoomin"
    Me.cmdZoomin.Size = New System.Drawing.Size(41, 41)
    Me.cmdZoomin.TabIndex = 49
    Me.cmdZoomin.TextAlign = System.Drawing.ContentAlignment.BottomCenter
    Me.ToolTip1.SetToolTip(Me.cmdZoomin, "Zoom In")
    Me.cmdZoomin.UseVisualStyleBackColor = False
    '
    'cmdHelp
    '
    Me.cmdHelp.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.cmdHelp.Image = CType(resources.GetObject("cmdHelp.Image"), System.Drawing.Image)
    Me.cmdHelp.Location = New System.Drawing.Point(655, 360)
    Me.cmdHelp.Name = "cmdHelp"
    Me.cmdHelp.Size = New System.Drawing.Size(41, 39)
    Me.cmdHelp.TabIndex = 50
    Me.cmdHelp.TextAlign = System.Drawing.ContentAlignment.BottomCenter
    Me.ToolTip1.SetToolTip(Me.cmdHelp, "Help")
    Me.cmdHelp.UseVisualStyleBackColor = False
    '
    'chkWeight
    '
    Me.chkWeight.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.chkWeight.Location = New System.Drawing.Point(670, 290)
    Me.chkWeight.Name = "chkWeight"
    Me.chkWeight.Size = New System.Drawing.Size(112, 41)
    Me.chkWeight.TabIndex = 48
    Me.chkWeight.Text = "&Normalize Weights"
    Me.ToolTip1.SetToolTip(Me.chkWeight, "Normalize weights to maintain average brightness")
    Me.chkWeight.UseVisualStyleBackColor = False
    '
    'txR9
    '
    Me.txR9.AcceptsReturn = True
    Me.txR9.BackColor = System.Drawing.SystemColors.Window
    Me.txR9.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txR9.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txR9.Location = New System.Drawing.Point(425, 305)
    Me.txR9.MaxLength = 0
    Me.txR9.Name = "txR9"
    Me.txR9.Size = New System.Drawing.Size(46, 23)
    Me.txR9.TabIndex = 27
    Me.txR9.Text = " "
    Me.ToolTip1.SetToolTip(Me.txR9, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txG9
    '
    Me.txG9.AcceptsReturn = True
    Me.txG9.BackColor = System.Drawing.SystemColors.Window
    Me.txG9.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txG9.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txG9.Location = New System.Drawing.Point(475, 305)
    Me.txG9.MaxLength = 0
    Me.txG9.Name = "txG9"
    Me.txG9.Size = New System.Drawing.Size(46, 23)
    Me.txG9.TabIndex = 28
    Me.txG9.Text = " "
    Me.ToolTip1.SetToolTip(Me.txG9, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txWeight9
    '
    Me.txWeight9.AcceptsReturn = True
    Me.txWeight9.BackColor = System.Drawing.SystemColors.Window
    Me.txWeight9.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txWeight9.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txWeight9.Location = New System.Drawing.Point(585, 305)
    Me.txWeight9.MaxLength = 0
    Me.txWeight9.Name = "txWeight9"
    Me.txWeight9.Size = New System.Drawing.Size(77, 23)
    Me.txWeight9.TabIndex = 39
    Me.txWeight9.Text = " "
    Me.ToolTip1.SetToolTip(Me.txWeight9, "Add a weight factor for this image")
    '
    'txB9
    '
    Me.txB9.AcceptsReturn = True
    Me.txB9.BackColor = System.Drawing.SystemColors.Window
    Me.txB9.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txB9.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txB9.Location = New System.Drawing.Point(525, 305)
    Me.txB9.MaxLength = 0
    Me.txB9.Name = "txB9"
    Me.txB9.Size = New System.Drawing.Size(46, 23)
    Me.txB9.TabIndex = 29
    Me.ToolTip1.SetToolTip(Me.txB9, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txB8
    '
    Me.txB8.AcceptsReturn = True
    Me.txB8.BackColor = System.Drawing.SystemColors.Window
    Me.txB8.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txB8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txB8.Location = New System.Drawing.Point(525, 275)
    Me.txB8.MaxLength = 0
    Me.txB8.Name = "txB8"
    Me.txB8.Size = New System.Drawing.Size(46, 23)
    Me.txB8.TabIndex = 26
    Me.ToolTip1.SetToolTip(Me.txB8, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'Opt7
    '
    Me.Opt7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Opt7.Location = New System.Drawing.Point(670, 250)
    Me.Opt7.Name = "Opt7"
    Me.Opt7.Size = New System.Drawing.Size(101, 26)
    Me.Opt7.TabIndex = 47
    Me.Opt7.TabStop = True
    Me.Opt7.Text = "Gr&ay"
    Me.ToolTip1.SetToolTip(Me.Opt7, "Use color preset values")
    Me.Opt7.UseVisualStyleBackColor = False
    '
    'txWeight8
    '
    Me.txWeight8.AcceptsReturn = True
    Me.txWeight8.BackColor = System.Drawing.SystemColors.Window
    Me.txWeight8.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txWeight8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txWeight8.Location = New System.Drawing.Point(585, 275)
    Me.txWeight8.MaxLength = 0
    Me.txWeight8.Name = "txWeight8"
    Me.txWeight8.Size = New System.Drawing.Size(77, 23)
    Me.txWeight8.TabIndex = 38
    Me.txWeight8.Text = " "
    Me.ToolTip1.SetToolTip(Me.txWeight8, "Add a weight factor for this image")
    '
    'txG8
    '
    Me.txG8.AcceptsReturn = True
    Me.txG8.BackColor = System.Drawing.SystemColors.Window
    Me.txG8.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txG8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txG8.Location = New System.Drawing.Point(475, 275)
    Me.txG8.MaxLength = 0
    Me.txG8.Name = "txG8"
    Me.txG8.Size = New System.Drawing.Size(46, 23)
    Me.txG8.TabIndex = 25
    Me.txG8.Text = " "
    Me.ToolTip1.SetToolTip(Me.txG8, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txR8
    '
    Me.txR8.AcceptsReturn = True
    Me.txR8.BackColor = System.Drawing.SystemColors.Window
    Me.txR8.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txR8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txR8.Location = New System.Drawing.Point(425, 275)
    Me.txR8.MaxLength = 0
    Me.txR8.Name = "txR8"
    Me.txR8.Size = New System.Drawing.Size(46, 23)
    Me.txR8.TabIndex = 24
    Me.txR8.Text = " "
    Me.ToolTip1.SetToolTip(Me.txR8, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txWeight7
    '
    Me.txWeight7.AcceptsReturn = True
    Me.txWeight7.BackColor = System.Drawing.SystemColors.Window
    Me.txWeight7.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txWeight7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txWeight7.Location = New System.Drawing.Point(585, 245)
    Me.txWeight7.MaxLength = 0
    Me.txWeight7.Name = "txWeight7"
    Me.txWeight7.Size = New System.Drawing.Size(77, 23)
    Me.txWeight7.TabIndex = 37
    Me.txWeight7.Text = " "
    Me.ToolTip1.SetToolTip(Me.txWeight7, "Add a weight factor for this image")
    '
    'txB7
    '
    Me.txB7.AcceptsReturn = True
    Me.txB7.BackColor = System.Drawing.SystemColors.Window
    Me.txB7.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txB7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txB7.Location = New System.Drawing.Point(525, 245)
    Me.txB7.MaxLength = 0
    Me.txB7.Name = "txB7"
    Me.txB7.Size = New System.Drawing.Size(46, 23)
    Me.txB7.TabIndex = 23
    Me.txB7.Text = " "
    Me.ToolTip1.SetToolTip(Me.txB7, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txG7
    '
    Me.txG7.AcceptsReturn = True
    Me.txG7.BackColor = System.Drawing.SystemColors.Window
    Me.txG7.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txG7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txG7.Location = New System.Drawing.Point(475, 245)
    Me.txG7.MaxLength = 0
    Me.txG7.Name = "txG7"
    Me.txG7.Size = New System.Drawing.Size(46, 23)
    Me.txG7.TabIndex = 22
    Me.txG7.Text = " "
    Me.ToolTip1.SetToolTip(Me.txG7, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txR7
    '
    Me.txR7.AcceptsReturn = True
    Me.txR7.BackColor = System.Drawing.SystemColors.Window
    Me.txR7.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txR7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txR7.Location = New System.Drawing.Point(425, 245)
    Me.txR7.MaxLength = 0
    Me.txR7.Name = "txR7"
    Me.txR7.Size = New System.Drawing.Size(46, 23)
    Me.txR7.TabIndex = 21
    Me.txR7.Text = " "
    Me.ToolTip1.SetToolTip(Me.txR7, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txWeight6
    '
    Me.txWeight6.AcceptsReturn = True
    Me.txWeight6.BackColor = System.Drawing.SystemColors.Window
    Me.txWeight6.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txWeight6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txWeight6.Location = New System.Drawing.Point(585, 215)
    Me.txWeight6.MaxLength = 0
    Me.txWeight6.Name = "txWeight6"
    Me.txWeight6.Size = New System.Drawing.Size(77, 23)
    Me.txWeight6.TabIndex = 36
    Me.txWeight6.Text = " "
    Me.ToolTip1.SetToolTip(Me.txWeight6, "Add a weight factor for this image")
    '
    'txB6
    '
    Me.txB6.AcceptsReturn = True
    Me.txB6.BackColor = System.Drawing.SystemColors.Window
    Me.txB6.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txB6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txB6.Location = New System.Drawing.Point(525, 215)
    Me.txB6.MaxLength = 0
    Me.txB6.Name = "txB6"
    Me.txB6.Size = New System.Drawing.Size(46, 23)
    Me.txB6.TabIndex = 20
    Me.txB6.Text = " "
    Me.ToolTip1.SetToolTip(Me.txB6, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txG6
    '
    Me.txG6.AcceptsReturn = True
    Me.txG6.BackColor = System.Drawing.SystemColors.Window
    Me.txG6.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txG6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txG6.Location = New System.Drawing.Point(475, 215)
    Me.txG6.MaxLength = 0
    Me.txG6.Name = "txG6"
    Me.txG6.Size = New System.Drawing.Size(46, 23)
    Me.txG6.TabIndex = 19
    Me.txG6.Text = " "
    Me.ToolTip1.SetToolTip(Me.txG6, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txR6
    '
    Me.txR6.AcceptsReturn = True
    Me.txR6.BackColor = System.Drawing.SystemColors.Window
    Me.txR6.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txR6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txR6.Location = New System.Drawing.Point(425, 215)
    Me.txR6.MaxLength = 0
    Me.txR6.Name = "txR6"
    Me.txR6.Size = New System.Drawing.Size(46, 23)
    Me.txR6.TabIndex = 18
    Me.txR6.Text = " "
    Me.ToolTip1.SetToolTip(Me.txR6, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txWeight5
    '
    Me.txWeight5.AcceptsReturn = True
    Me.txWeight5.BackColor = System.Drawing.SystemColors.Window
    Me.txWeight5.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txWeight5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txWeight5.Location = New System.Drawing.Point(585, 185)
    Me.txWeight5.MaxLength = 0
    Me.txWeight5.Name = "txWeight5"
    Me.txWeight5.Size = New System.Drawing.Size(77, 23)
    Me.txWeight5.TabIndex = 35
    Me.txWeight5.Text = " "
    Me.ToolTip1.SetToolTip(Me.txWeight5, "Add a weight factor for this image")
    '
    'txB5
    '
    Me.txB5.AcceptsReturn = True
    Me.txB5.BackColor = System.Drawing.SystemColors.Window
    Me.txB5.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txB5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txB5.Location = New System.Drawing.Point(525, 185)
    Me.txB5.MaxLength = 0
    Me.txB5.Name = "txB5"
    Me.txB5.Size = New System.Drawing.Size(46, 23)
    Me.txB5.TabIndex = 17
    Me.txB5.Text = " "
    Me.ToolTip1.SetToolTip(Me.txB5, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txG5
    '
    Me.txG5.AcceptsReturn = True
    Me.txG5.BackColor = System.Drawing.SystemColors.Window
    Me.txG5.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txG5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txG5.Location = New System.Drawing.Point(475, 185)
    Me.txG5.MaxLength = 0
    Me.txG5.Name = "txG5"
    Me.txG5.Size = New System.Drawing.Size(46, 23)
    Me.txG5.TabIndex = 16
    Me.txG5.Text = " "
    Me.ToolTip1.SetToolTip(Me.txG5, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txR5
    '
    Me.txR5.AcceptsReturn = True
    Me.txR5.BackColor = System.Drawing.SystemColors.Window
    Me.txR5.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txR5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txR5.Location = New System.Drawing.Point(425, 185)
    Me.txR5.MaxLength = 0
    Me.txR5.Name = "txR5"
    Me.txR5.Size = New System.Drawing.Size(46, 23)
    Me.txR5.TabIndex = 15
    Me.txR5.Text = " "
    Me.ToolTip1.SetToolTip(Me.txR5, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txWeight4
    '
    Me.txWeight4.AcceptsReturn = True
    Me.txWeight4.BackColor = System.Drawing.SystemColors.Window
    Me.txWeight4.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txWeight4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txWeight4.Location = New System.Drawing.Point(585, 155)
    Me.txWeight4.MaxLength = 0
    Me.txWeight4.Name = "txWeight4"
    Me.txWeight4.Size = New System.Drawing.Size(77, 23)
    Me.txWeight4.TabIndex = 34
    Me.txWeight4.Text = " "
    Me.ToolTip1.SetToolTip(Me.txWeight4, "Add a weight factor for this image")
    '
    'txB4
    '
    Me.txB4.AcceptsReturn = True
    Me.txB4.BackColor = System.Drawing.SystemColors.Window
    Me.txB4.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txB4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txB4.Location = New System.Drawing.Point(525, 155)
    Me.txB4.MaxLength = 0
    Me.txB4.Name = "txB4"
    Me.txB4.Size = New System.Drawing.Size(46, 23)
    Me.txB4.TabIndex = 14
    Me.txB4.Text = " "
    Me.ToolTip1.SetToolTip(Me.txB4, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txG4
    '
    Me.txG4.AcceptsReturn = True
    Me.txG4.BackColor = System.Drawing.SystemColors.Window
    Me.txG4.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txG4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txG4.Location = New System.Drawing.Point(475, 155)
    Me.txG4.MaxLength = 0
    Me.txG4.Name = "txG4"
    Me.txG4.Size = New System.Drawing.Size(46, 23)
    Me.txG4.TabIndex = 13
    Me.txG4.Text = " "
    Me.ToolTip1.SetToolTip(Me.txG4, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txR4
    '
    Me.txR4.AcceptsReturn = True
    Me.txR4.BackColor = System.Drawing.SystemColors.Window
    Me.txR4.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txR4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txR4.Location = New System.Drawing.Point(425, 155)
    Me.txR4.MaxLength = 0
    Me.txR4.Name = "txR4"
    Me.txR4.Size = New System.Drawing.Size(46, 23)
    Me.txR4.TabIndex = 12
    Me.txR4.Text = " "
    Me.ToolTip1.SetToolTip(Me.txR4, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txWeight3
    '
    Me.txWeight3.AcceptsReturn = True
    Me.txWeight3.BackColor = System.Drawing.SystemColors.Window
    Me.txWeight3.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txWeight3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txWeight3.Location = New System.Drawing.Point(585, 125)
    Me.txWeight3.MaxLength = 0
    Me.txWeight3.Name = "txWeight3"
    Me.txWeight3.Size = New System.Drawing.Size(77, 23)
    Me.txWeight3.TabIndex = 33
    Me.txWeight3.Text = " "
    Me.ToolTip1.SetToolTip(Me.txWeight3, "Add a weight factor for this image")
    '
    'txB3
    '
    Me.txB3.AcceptsReturn = True
    Me.txB3.BackColor = System.Drawing.SystemColors.Window
    Me.txB3.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txB3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txB3.Location = New System.Drawing.Point(525, 125)
    Me.txB3.MaxLength = 0
    Me.txB3.Name = "txB3"
    Me.txB3.Size = New System.Drawing.Size(46, 23)
    Me.txB3.TabIndex = 11
    Me.txB3.Text = " "
    Me.ToolTip1.SetToolTip(Me.txB3, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txG3
    '
    Me.txG3.AcceptsReturn = True
    Me.txG3.BackColor = System.Drawing.SystemColors.Window
    Me.txG3.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txG3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txG3.Location = New System.Drawing.Point(475, 125)
    Me.txG3.MaxLength = 0
    Me.txG3.Name = "txG3"
    Me.txG3.Size = New System.Drawing.Size(46, 23)
    Me.txG3.TabIndex = 10
    Me.txG3.Text = " "
    Me.ToolTip1.SetToolTip(Me.txG3, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txR3
    '
    Me.txR3.AcceptsReturn = True
    Me.txR3.BackColor = System.Drawing.SystemColors.Window
    Me.txR3.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txR3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txR3.Location = New System.Drawing.Point(425, 125)
    Me.txR3.MaxLength = 0
    Me.txR3.Name = "txR3"
    Me.txR3.Size = New System.Drawing.Size(46, 23)
    Me.txR3.TabIndex = 9
    Me.txR3.Text = " "
    Me.ToolTip1.SetToolTip(Me.txR3, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txWeight2
    '
    Me.txWeight2.AcceptsReturn = True
    Me.txWeight2.BackColor = System.Drawing.SystemColors.Window
    Me.txWeight2.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txWeight2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txWeight2.Location = New System.Drawing.Point(585, 95)
    Me.txWeight2.MaxLength = 0
    Me.txWeight2.Name = "txWeight2"
    Me.txWeight2.Size = New System.Drawing.Size(77, 23)
    Me.txWeight2.TabIndex = 32
    Me.txWeight2.Text = " "
    Me.ToolTip1.SetToolTip(Me.txWeight2, "Add a weight factor for this image")
    '
    'txB2
    '
    Me.txB2.AcceptsReturn = True
    Me.txB2.BackColor = System.Drawing.SystemColors.Window
    Me.txB2.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txB2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txB2.Location = New System.Drawing.Point(525, 95)
    Me.txB2.MaxLength = 0
    Me.txB2.Name = "txB2"
    Me.txB2.Size = New System.Drawing.Size(46, 23)
    Me.txB2.TabIndex = 8
    Me.txB2.Text = " "
    Me.ToolTip1.SetToolTip(Me.txB2, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txG2
    '
    Me.txG2.AcceptsReturn = True
    Me.txG2.BackColor = System.Drawing.SystemColors.Window
    Me.txG2.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txG2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txG2.Location = New System.Drawing.Point(475, 95)
    Me.txG2.MaxLength = 0
    Me.txG2.Name = "txG2"
    Me.txG2.Size = New System.Drawing.Size(46, 23)
    Me.txG2.TabIndex = 7
    Me.ToolTip1.SetToolTip(Me.txG2, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txR2
    '
    Me.txR2.AcceptsReturn = True
    Me.txR2.BackColor = System.Drawing.SystemColors.Window
    Me.txR2.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txR2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txR2.Location = New System.Drawing.Point(425, 95)
    Me.txR2.MaxLength = 0
    Me.txR2.Name = "txR2"
    Me.txR2.Size = New System.Drawing.Size(46, 23)
    Me.txR2.TabIndex = 6
    Me.ToolTip1.SetToolTip(Me.txR2, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txWeight1
    '
    Me.txWeight1.AcceptsReturn = True
    Me.txWeight1.BackColor = System.Drawing.SystemColors.Window
    Me.txWeight1.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txWeight1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txWeight1.Location = New System.Drawing.Point(585, 65)
    Me.txWeight1.MaxLength = 0
    Me.txWeight1.Name = "txWeight1"
    Me.txWeight1.Size = New System.Drawing.Size(77, 23)
    Me.txWeight1.TabIndex = 31
    Me.txWeight1.Text = "  "
    Me.ToolTip1.SetToolTip(Me.txWeight1, "Add a weight factor for this image")
    '
    'txB1
    '
    Me.txB1.AcceptsReturn = True
    Me.txB1.BackColor = System.Drawing.SystemColors.Window
    Me.txB1.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txB1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txB1.Location = New System.Drawing.Point(525, 65)
    Me.txB1.MaxLength = 0
    Me.txB1.Name = "txB1"
    Me.txB1.Size = New System.Drawing.Size(46, 23)
    Me.txB1.TabIndex = 5
    Me.txB1.Text = " "
    Me.ToolTip1.SetToolTip(Me.txB1, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txG1
    '
    Me.txG1.AcceptsReturn = True
    Me.txG1.BackColor = System.Drawing.SystemColors.Window
    Me.txG1.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txG1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txG1.Location = New System.Drawing.Point(475, 65)
    Me.txG1.MaxLength = 0
    Me.txG1.Name = "txG1"
    Me.txG1.Size = New System.Drawing.Size(46, 23)
    Me.txG1.TabIndex = 4
    Me.txG1.Text = " "
    Me.ToolTip1.SetToolTip(Me.txG1, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txR1
    '
    Me.txR1.AcceptsReturn = True
    Me.txR1.BackColor = System.Drawing.SystemColors.Window
    Me.txR1.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txR1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txR1.Location = New System.Drawing.Point(425, 65)
    Me.txR1.MaxLength = 0
    Me.txR1.Name = "txR1"
    Me.txR1.Size = New System.Drawing.Size(46, 23)
    Me.txR1.TabIndex = 3
    Me.txR1.Text = " "
    Me.ToolTip1.SetToolTip(Me.txR1, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txWeight0
    '
    Me.txWeight0.AcceptsReturn = True
    Me.txWeight0.BackColor = System.Drawing.SystemColors.Window
    Me.txWeight0.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txWeight0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txWeight0.Location = New System.Drawing.Point(585, 35)
    Me.txWeight0.MaxLength = 0
    Me.txWeight0.Name = "txWeight0"
    Me.txWeight0.Size = New System.Drawing.Size(77, 23)
    Me.txWeight0.TabIndex = 30
    Me.txWeight0.Text = " "
    Me.ToolTip1.SetToolTip(Me.txWeight0, "Add a weight factor for this image")
    '
    'txB0
    '
    Me.txB0.AcceptsReturn = True
    Me.txB0.BackColor = System.Drawing.SystemColors.Window
    Me.txB0.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txB0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txB0.Location = New System.Drawing.Point(525, 35)
    Me.txB0.MaxLength = 0
    Me.txB0.Name = "txB0"
    Me.txB0.Size = New System.Drawing.Size(46, 23)
    Me.txB0.TabIndex = 2
    Me.txB0.Text = " "
    Me.ToolTip1.SetToolTip(Me.txB0, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txG0
    '
    Me.txG0.AcceptsReturn = True
    Me.txG0.BackColor = System.Drawing.SystemColors.Window
    Me.txG0.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txG0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txG0.Location = New System.Drawing.Point(475, 35)
    Me.txG0.MaxLength = 0
    Me.txG0.Name = "txG0"
    Me.txG0.Size = New System.Drawing.Size(46, 23)
    Me.txG0.TabIndex = 1
    Me.txG0.Text = " "
    Me.ToolTip1.SetToolTip(Me.txG0, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'txR0
    '
    Me.txR0.AcceptsReturn = True
    Me.txR0.BackColor = System.Drawing.SystemColors.Window
    Me.txR0.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txR0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txR0.Location = New System.Drawing.Point(425, 35)
    Me.txR0.MaxLength = 0
    Me.txR0.Name = "txR0"
    Me.txR0.Size = New System.Drawing.Size(46, 23)
    Me.txR0.TabIndex = 0
    Me.txR0.Text = " "
    Me.ToolTip1.SetToolTip(Me.txR0, "Color values for red, green, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and blue.")
    '
    'Opt6
    '
    Me.Opt6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Opt6.Location = New System.Drawing.Point(670, 220)
    Me.Opt6.Name = "Opt6"
    Me.Opt6.Size = New System.Drawing.Size(101, 26)
    Me.Opt6.TabIndex = 46
    Me.Opt6.TabStop = True
    Me.Opt6.Text = "&Violet"
    Me.ToolTip1.SetToolTip(Me.Opt6, "Use color preset values")
    Me.Opt6.UseVisualStyleBackColor = False
    '
    'Opt5
    '
    Me.Opt5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Opt5.Location = New System.Drawing.Point(670, 190)
    Me.Opt5.Name = "Opt5"
    Me.Opt5.Size = New System.Drawing.Size(101, 26)
    Me.Opt5.TabIndex = 45
    Me.Opt5.TabStop = True
    Me.Opt5.Text = "&Yellow"
    Me.ToolTip1.SetToolTip(Me.Opt5, "Use color preset values")
    Me.Opt5.UseVisualStyleBackColor = False
    '
    'Opt4
    '
    Me.Opt4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Opt4.Location = New System.Drawing.Point(670, 160)
    Me.Opt4.Name = "Opt4"
    Me.Opt4.Size = New System.Drawing.Size(101, 26)
    Me.Opt4.TabIndex = 44
    Me.Opt4.TabStop = True
    Me.Opt4.Text = "&Magenta"
    Me.ToolTip1.SetToolTip(Me.Opt4, "Use color preset values")
    Me.Opt4.UseVisualStyleBackColor = False
    '
    'Opt3
    '
    Me.Opt3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Opt3.Location = New System.Drawing.Point(670, 130)
    Me.Opt3.Name = "Opt3"
    Me.Opt3.Size = New System.Drawing.Size(101, 26)
    Me.Opt3.TabIndex = 43
    Me.Opt3.TabStop = True
    Me.Opt3.Text = "&Cyan"
    Me.ToolTip1.SetToolTip(Me.Opt3, "Use color preset values")
    Me.Opt3.UseVisualStyleBackColor = False
    '
    'Opt2
    '
    Me.Opt2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Opt2.Location = New System.Drawing.Point(670, 100)
    Me.Opt2.Name = "Opt2"
    Me.Opt2.Size = New System.Drawing.Size(101, 26)
    Me.Opt2.TabIndex = 42
    Me.Opt2.TabStop = True
    Me.Opt2.Text = "&Blue"
    Me.ToolTip1.SetToolTip(Me.Opt2, "Use color preset values")
    Me.Opt2.UseVisualStyleBackColor = False
    '
    'Opt1
    '
    Me.Opt1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Opt1.Location = New System.Drawing.Point(670, 70)
    Me.Opt1.Name = "Opt1"
    Me.Opt1.Size = New System.Drawing.Size(101, 26)
    Me.Opt1.TabIndex = 41
    Me.Opt1.TabStop = True
    Me.Opt1.Text = "&Green"
    Me.ToolTip1.SetToolTip(Me.Opt1, "Use color preset values")
    Me.Opt1.UseVisualStyleBackColor = False
    '
    'Opt0
    '
    Me.Opt0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Opt0.Location = New System.Drawing.Point(670, 40)
    Me.Opt0.Name = "Opt0"
    Me.Opt0.Size = New System.Drawing.Size(101, 26)
    Me.Opt0.TabIndex = 40
    Me.Opt0.TabStop = True
    Me.Opt0.Text = "&Red"
    Me.ToolTip1.SetToolTip(Me.Opt0, "Use color preset values")
    Me.Opt0.UseVisualStyleBackColor = False
    '
    'lbWeight
    '
    Me.lbWeight.AutoSize = True
    Me.lbWeight.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.lbWeight.Location = New System.Drawing.Point(585, 15)
    Me.lbWeight.Name = "lbWeight"
    Me.lbWeight.Size = New System.Drawing.Size(52, 16)
    Me.lbWeight.TabIndex = 3
    Me.lbWeight.Text = "Weight"
    Me.lbWeight.TextAlign = System.Drawing.ContentAlignment.TopCenter
    Me.ToolTip1.SetToolTip(Me.lbWeight, "Add a weight factor for this image")
    '
    'cmdOK
    '
    Me.cmdOK.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.cmdOK.Location = New System.Drawing.Point(633, 416)
    Me.cmdOK.Name = "cmdOK"
    Me.cmdOK.Size = New System.Drawing.Size(91, 31)
    Me.cmdOK.TabIndex = 51
    Me.cmdOK.Text = "&OK"
    Me.cmdOK.UseVisualStyleBackColor = False
    '
    'cmdCancel
    '
    Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.cmdCancel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.cmdCancel.Location = New System.Drawing.Point(633, 466)
    Me.cmdCancel.Name = "cmdCancel"
    Me.cmdCancel.Size = New System.Drawing.Size(91, 31)
    Me.cmdCancel.TabIndex = 52
    Me.cmdCancel.Text = "Cancel"
    Me.cmdCancel.UseVisualStyleBackColor = False
    '
    'txPath9
    '
    Me.txPath9.AcceptsReturn = True
    Me.txPath9.BackColor = System.Drawing.SystemColors.Window
    Me.txPath9.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txPath9.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txPath9.Location = New System.Drawing.Point(20, 305)
    Me.txPath9.MaxLength = 0
    Me.txPath9.Name = "txPath9"
    Me.txPath9.ReadOnly = True
    Me.txPath9.Size = New System.Drawing.Size(386, 23)
    Me.txPath9.TabIndex = 62
    Me.txPath9.TabStop = False
    '
    'txPath8
    '
    Me.txPath8.AcceptsReturn = True
    Me.txPath8.BackColor = System.Drawing.SystemColors.Window
    Me.txPath8.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txPath8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txPath8.Location = New System.Drawing.Point(20, 275)
    Me.txPath8.MaxLength = 0
    Me.txPath8.Name = "txPath8"
    Me.txPath8.ReadOnly = True
    Me.txPath8.Size = New System.Drawing.Size(386, 23)
    Me.txPath8.TabIndex = 61
    Me.txPath8.TabStop = False
    '
    'txPath7
    '
    Me.txPath7.AcceptsReturn = True
    Me.txPath7.BackColor = System.Drawing.SystemColors.Window
    Me.txPath7.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txPath7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txPath7.Location = New System.Drawing.Point(20, 245)
    Me.txPath7.MaxLength = 0
    Me.txPath7.Name = "txPath7"
    Me.txPath7.ReadOnly = True
    Me.txPath7.Size = New System.Drawing.Size(386, 23)
    Me.txPath7.TabIndex = 60
    Me.txPath7.TabStop = False
    Me.txPath7.Text = " "
    '
    'txPath6
    '
    Me.txPath6.AcceptsReturn = True
    Me.txPath6.BackColor = System.Drawing.SystemColors.Window
    Me.txPath6.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txPath6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txPath6.Location = New System.Drawing.Point(20, 215)
    Me.txPath6.MaxLength = 0
    Me.txPath6.Name = "txPath6"
    Me.txPath6.Size = New System.Drawing.Size(386, 23)
    Me.txPath6.TabIndex = 59
    Me.txPath6.TabStop = False
    Me.txPath6.Text = " "
    '
    'txPath5
    '
    Me.txPath5.AcceptsReturn = True
    Me.txPath5.BackColor = System.Drawing.SystemColors.Window
    Me.txPath5.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txPath5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txPath5.Location = New System.Drawing.Point(20, 185)
    Me.txPath5.MaxLength = 0
    Me.txPath5.Name = "txPath5"
    Me.txPath5.ReadOnly = True
    Me.txPath5.Size = New System.Drawing.Size(386, 23)
    Me.txPath5.TabIndex = 58
    Me.txPath5.TabStop = False
    Me.txPath5.Text = " "
    '
    'txPath4
    '
    Me.txPath4.AcceptsReturn = True
    Me.txPath4.BackColor = System.Drawing.SystemColors.Window
    Me.txPath4.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txPath4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txPath4.Location = New System.Drawing.Point(20, 155)
    Me.txPath4.MaxLength = 0
    Me.txPath4.Name = "txPath4"
    Me.txPath4.ReadOnly = True
    Me.txPath4.Size = New System.Drawing.Size(386, 23)
    Me.txPath4.TabIndex = 57
    Me.txPath4.TabStop = False
    Me.txPath4.Text = " "
    '
    'txPath3
    '
    Me.txPath3.AcceptsReturn = True
    Me.txPath3.BackColor = System.Drawing.SystemColors.Window
    Me.txPath3.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txPath3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txPath3.Location = New System.Drawing.Point(20, 125)
    Me.txPath3.MaxLength = 0
    Me.txPath3.Name = "txPath3"
    Me.txPath3.ReadOnly = True
    Me.txPath3.Size = New System.Drawing.Size(386, 23)
    Me.txPath3.TabIndex = 56
    Me.txPath3.TabStop = False
    Me.txPath3.Text = " "
    '
    'txPath2
    '
    Me.txPath2.AcceptsReturn = True
    Me.txPath2.BackColor = System.Drawing.SystemColors.Window
    Me.txPath2.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txPath2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txPath2.Location = New System.Drawing.Point(20, 95)
    Me.txPath2.MaxLength = 0
    Me.txPath2.Name = "txPath2"
    Me.txPath2.ReadOnly = True
    Me.txPath2.Size = New System.Drawing.Size(386, 23)
    Me.txPath2.TabIndex = 55
    Me.txPath2.TabStop = False
    Me.txPath2.Text = " "
    '
    'txPath1
    '
    Me.txPath1.AcceptsReturn = True
    Me.txPath1.BackColor = System.Drawing.SystemColors.Window
    Me.txPath1.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txPath1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txPath1.Location = New System.Drawing.Point(20, 65)
    Me.txPath1.MaxLength = 0
    Me.txPath1.Name = "txPath1"
    Me.txPath1.ReadOnly = True
    Me.txPath1.Size = New System.Drawing.Size(386, 23)
    Me.txPath1.TabIndex = 54
    Me.txPath1.TabStop = False
    Me.txPath1.Text = " "
    '
    'txPath0
    '
    Me.txPath0.AcceptsReturn = True
    Me.txPath0.BackColor = System.Drawing.SystemColors.Window
    Me.txPath0.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txPath0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txPath0.Location = New System.Drawing.Point(20, 35)
    Me.txPath0.MaxLength = 0
    Me.txPath0.Name = "txPath0"
    Me.txPath0.ReadOnly = True
    Me.txPath0.Size = New System.Drawing.Size(386, 23)
    Me.txPath0.TabIndex = 53
    Me.txPath0.TabStop = False
    Me.txPath0.Text = " "
    '
    'lbFilename
    '
    Me.lbFilename.AutoSize = True
    Me.lbFilename.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.lbFilename.Location = New System.Drawing.Point(20, 15)
    Me.lbFilename.Name = "lbFilename"
    Me.lbFilename.Size = New System.Drawing.Size(71, 16)
    Me.lbFilename.TabIndex = 56
    Me.lbFilename.Text = "File Name"
    '
    'lbBlue
    '
    Me.lbBlue.AutoSize = True
    Me.lbBlue.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.lbBlue.Location = New System.Drawing.Point(525, 15)
    Me.lbBlue.Name = "lbBlue"
    Me.lbBlue.Size = New System.Drawing.Size(36, 16)
    Me.lbBlue.TabIndex = 2
    Me.lbBlue.Text = "Blue"
    Me.lbBlue.TextAlign = System.Drawing.ContentAlignment.TopCenter
    '
    'lbGreen
    '
    Me.lbGreen.AutoSize = True
    Me.lbGreen.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.lbGreen.Location = New System.Drawing.Point(475, 15)
    Me.lbGreen.Name = "lbGreen"
    Me.lbGreen.Size = New System.Drawing.Size(48, 16)
    Me.lbGreen.TabIndex = 1
    Me.lbGreen.Text = "Green"
    Me.lbGreen.TextAlign = System.Drawing.ContentAlignment.TopCenter
    '
    'lbRed
    '
    Me.lbRed.AutoSize = True
    Me.lbRed.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.lbRed.Location = New System.Drawing.Point(425, 15)
    Me.lbRed.Name = "lbRed"
    Me.lbRed.Size = New System.Drawing.Size(34, 16)
    Me.lbRed.TabIndex = 0
    Me.lbRed.Text = "Red"
    Me.lbRed.TextAlign = System.Drawing.ContentAlignment.TopCenter
    '
    'pView
    '
    Me.pView.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.pView.BackColor = System.Drawing.SystemColors.ControlDarkDark
    Me.pView.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.Low
    Me.pView.Location = New System.Drawing.Point(20, 347)
    Me.pView.Name = "pView"
    Me.pView.Size = New System.Drawing.Size(526, 311)
    Me.pView.TabIndex = 76
    Me.pView.TabStop = False
    Me.pView.ZoomFactor = 1.0R
    '
    'frmColorMerge
    '
    Me.AcceptButton = Me.cmdOK
    Me.BackColor = System.Drawing.SystemColors.Control
    Me.CancelButton = Me.cmdCancel
    Me.ClientSize = New System.Drawing.Size(784, 670)
    Me.Controls.Add(Me.pView)
    Me.Controls.Add(Me.cmdHelp)
    Me.Controls.Add(Me.cmdZoomout)
    Me.Controls.Add(Me.cmdZoomin)
    Me.Controls.Add(Me.chkWeight)
    Me.Controls.Add(Me.txPath9)
    Me.Controls.Add(Me.txR9)
    Me.Controls.Add(Me.txG9)
    Me.Controls.Add(Me.txWeight9)
    Me.Controls.Add(Me.txB9)
    Me.Controls.Add(Me.txB8)
    Me.Controls.Add(Me.Opt7)
    Me.Controls.Add(Me.txWeight8)
    Me.Controls.Add(Me.txG8)
    Me.Controls.Add(Me.txR8)
    Me.Controls.Add(Me.txPath8)
    Me.Controls.Add(Me.txWeight7)
    Me.Controls.Add(Me.txB7)
    Me.Controls.Add(Me.txG7)
    Me.Controls.Add(Me.txR7)
    Me.Controls.Add(Me.txPath7)
    Me.Controls.Add(Me.txWeight6)
    Me.Controls.Add(Me.txB6)
    Me.Controls.Add(Me.txG6)
    Me.Controls.Add(Me.txR6)
    Me.Controls.Add(Me.txPath6)
    Me.Controls.Add(Me.txWeight5)
    Me.Controls.Add(Me.txB5)
    Me.Controls.Add(Me.txG5)
    Me.Controls.Add(Me.txR5)
    Me.Controls.Add(Me.txPath5)
    Me.Controls.Add(Me.txWeight4)
    Me.Controls.Add(Me.txB4)
    Me.Controls.Add(Me.txG4)
    Me.Controls.Add(Me.txR4)
    Me.Controls.Add(Me.txPath4)
    Me.Controls.Add(Me.txWeight3)
    Me.Controls.Add(Me.txB3)
    Me.Controls.Add(Me.txG3)
    Me.Controls.Add(Me.txR3)
    Me.Controls.Add(Me.txPath3)
    Me.Controls.Add(Me.txWeight2)
    Me.Controls.Add(Me.txB2)
    Me.Controls.Add(Me.txG2)
    Me.Controls.Add(Me.txR2)
    Me.Controls.Add(Me.txPath2)
    Me.Controls.Add(Me.txWeight1)
    Me.Controls.Add(Me.txB1)
    Me.Controls.Add(Me.txG1)
    Me.Controls.Add(Me.txR1)
    Me.Controls.Add(Me.txPath1)
    Me.Controls.Add(Me.txWeight0)
    Me.Controls.Add(Me.txB0)
    Me.Controls.Add(Me.txG0)
    Me.Controls.Add(Me.txR0)
    Me.Controls.Add(Me.txPath0)
    Me.Controls.Add(Me.Opt6)
    Me.Controls.Add(Me.cmdOK)
    Me.Controls.Add(Me.cmdCancel)
    Me.Controls.Add(Me.Opt5)
    Me.Controls.Add(Me.Opt4)
    Me.Controls.Add(Me.Opt3)
    Me.Controls.Add(Me.Opt2)
    Me.Controls.Add(Me.Opt1)
    Me.Controls.Add(Me.Opt0)
    Me.Controls.Add(Me.lbFilename)
    Me.Controls.Add(Me.lbWeight)
    Me.Controls.Add(Me.lbBlue)
    Me.Controls.Add(Me.lbGreen)
    Me.Controls.Add(Me.lbRed)
    Me.Cursor = System.Windows.Forms.Cursors.Default
    Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.Location = New System.Drawing.Point(3, 30)
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "frmColorMerge"
    Me.ShowInTaskbar = False
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "Merge Color Separations"
    CType(Me.pView, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)
    Me.PerformLayout()

End Sub
 Public WithEvents cmdZoomout As System.Windows.Forms.Button
 Public WithEvents cmdZoomin As System.Windows.Forms.Button
 Public WithEvents cmdHelp As System.Windows.Forms.Button
 Friend WithEvents pView As PhotoMud.pViewer
#End Region
End Class