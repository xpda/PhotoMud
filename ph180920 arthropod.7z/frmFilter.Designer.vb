<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmFilter
#Region "Windows Form Designer generated code "
  <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
    MyBase.New()
    'This call is required by the Windows Form Designer.
    InitializeComponent()
  End Sub
  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
    If Disposing Then
      If Not components Is Nothing Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(Disposing)
  End Sub
  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer
  Public ToolTip1 As ToolTip
  Public WithEvents cmdClearFilter As Button
  Public WithEvents optSize7x7 As RadioButton
  Public WithEvents txFilter46 As TextBox
  Public WithEvents txFilter47 As TextBox
  Public WithEvents txFilter48 As TextBox
  Public WithEvents txFilter42 As TextBox
  Public WithEvents txFilter43 As TextBox
  Public WithEvents txFilter44 As TextBox
  Public WithEvents txFilter45 As TextBox
  Public WithEvents txFilter39 As TextBox
  Public WithEvents txFilter40 As TextBox
  Public WithEvents txFilter41 As TextBox
  Public WithEvents txFilter35 As TextBox
  Public WithEvents txFilter36 As TextBox
  Public WithEvents txFilter37 As TextBox
  Public WithEvents txFilter38 As TextBox
  Public WithEvents txFilter32 As TextBox
  Public WithEvents txFilter33 As TextBox
  Public WithEvents txFilter34 As TextBox
  Public WithEvents txFilter28 As TextBox
  Public WithEvents txFilter29 As TextBox
  Public WithEvents txFilter30 As TextBox
  Public WithEvents txFilter31 As TextBox
  Public WithEvents txFilter25 As TextBox
  Public WithEvents txFilter26 As TextBox
  Public WithEvents txFilter27 As TextBox
  Public WithEvents cmdLoadFilter As Button
  Public WithEvents cmdSaveFilter As Button
  Public WithEvents cmdOK As Button
  Public WithEvents cmdCancel As Button
  Public WithEvents cmbFilter As ComboBox
  Public WithEvents optSize5x5 As RadioButton
  Public WithEvents optSize3x3 As RadioButton
  Public WithEvents txFilter24 As TextBox
  Public WithEvents txFilter23 As TextBox
  Public WithEvents txFilter22 As TextBox
  Public WithEvents txFilter21 As TextBox
  Public WithEvents txFilter20 As TextBox
  Public WithEvents txFilter19 As TextBox
  Public WithEvents txFilter18 As TextBox
  Public WithEvents txFilter17 As TextBox
  Public WithEvents txFilter16 As TextBox
  Public WithEvents txFilter15 As TextBox
  Public WithEvents txFilter14 As TextBox
  Public WithEvents txFilter13 As TextBox
  Public WithEvents txFilter12 As TextBox
  Public WithEvents txFilter11 As TextBox
  Public WithEvents txFilter10 As TextBox
  Public WithEvents txFilter9 As TextBox
  Public WithEvents txFilter8 As TextBox
  Public WithEvents txFilter7 As TextBox
  Public WithEvents txFilter6 As TextBox
  Public WithEvents txFilter5 As TextBox
  Public WithEvents txFilter4 As TextBox
  Public WithEvents txFilter3 As TextBox
  Public WithEvents txFilter2 As TextBox
  Public WithEvents txFilter1 As TextBox
  Public WithEvents txFilter0 As TextBox
  Public WithEvents cmdStart As Button
  'Public WithEvents lead1 As AxLEADArray
  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container()
    Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmFilter))
    Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
    Me.cmdHelp = New System.Windows.Forms.Button()
    Me.cmdClearFilter = New System.Windows.Forms.Button()
    Me.optSize7x7 = New System.Windows.Forms.RadioButton()
    Me.cmdLoadFilter = New System.Windows.Forms.Button()
    Me.cmdSaveFilter = New System.Windows.Forms.Button()
    Me.cmbFilter = New System.Windows.Forms.ComboBox()
    Me.optSize5x5 = New System.Windows.Forms.RadioButton()
    Me.optSize3x3 = New System.Windows.Forms.RadioButton()
    Me.cmdStart = New System.Windows.Forms.Button()
    Me.txFilter46 = New System.Windows.Forms.TextBox()
    Me.txFilter47 = New System.Windows.Forms.TextBox()
    Me.txFilter48 = New System.Windows.Forms.TextBox()
    Me.txFilter42 = New System.Windows.Forms.TextBox()
    Me.txFilter43 = New System.Windows.Forms.TextBox()
    Me.txFilter44 = New System.Windows.Forms.TextBox()
    Me.txFilter45 = New System.Windows.Forms.TextBox()
    Me.txFilter39 = New System.Windows.Forms.TextBox()
    Me.txFilter40 = New System.Windows.Forms.TextBox()
    Me.txFilter41 = New System.Windows.Forms.TextBox()
    Me.txFilter35 = New System.Windows.Forms.TextBox()
    Me.txFilter36 = New System.Windows.Forms.TextBox()
    Me.txFilter37 = New System.Windows.Forms.TextBox()
    Me.txFilter38 = New System.Windows.Forms.TextBox()
    Me.txFilter32 = New System.Windows.Forms.TextBox()
    Me.txFilter33 = New System.Windows.Forms.TextBox()
    Me.txFilter34 = New System.Windows.Forms.TextBox()
    Me.txFilter28 = New System.Windows.Forms.TextBox()
    Me.txFilter29 = New System.Windows.Forms.TextBox()
    Me.txFilter30 = New System.Windows.Forms.TextBox()
    Me.txFilter31 = New System.Windows.Forms.TextBox()
    Me.txFilter25 = New System.Windows.Forms.TextBox()
    Me.txFilter26 = New System.Windows.Forms.TextBox()
    Me.txFilter27 = New System.Windows.Forms.TextBox()
    Me.cmdOK = New System.Windows.Forms.Button()
    Me.cmdCancel = New System.Windows.Forms.Button()
    Me.txFilter24 = New System.Windows.Forms.TextBox()
    Me.txFilter23 = New System.Windows.Forms.TextBox()
    Me.txFilter22 = New System.Windows.Forms.TextBox()
    Me.txFilter21 = New System.Windows.Forms.TextBox()
    Me.txFilter20 = New System.Windows.Forms.TextBox()
    Me.txFilter19 = New System.Windows.Forms.TextBox()
    Me.txFilter18 = New System.Windows.Forms.TextBox()
    Me.txFilter17 = New System.Windows.Forms.TextBox()
    Me.txFilter16 = New System.Windows.Forms.TextBox()
    Me.txFilter15 = New System.Windows.Forms.TextBox()
    Me.txFilter14 = New System.Windows.Forms.TextBox()
    Me.txFilter13 = New System.Windows.Forms.TextBox()
    Me.txFilter12 = New System.Windows.Forms.TextBox()
    Me.txFilter11 = New System.Windows.Forms.TextBox()
    Me.txFilter10 = New System.Windows.Forms.TextBox()
    Me.txFilter9 = New System.Windows.Forms.TextBox()
    Me.txFilter8 = New System.Windows.Forms.TextBox()
    Me.txFilter7 = New System.Windows.Forms.TextBox()
    Me.txFilter6 = New System.Windows.Forms.TextBox()
    Me.txFilter5 = New System.Windows.Forms.TextBox()
    Me.txFilter4 = New System.Windows.Forms.TextBox()
    Me.txFilter3 = New System.Windows.Forms.TextBox()
    Me.txFilter2 = New System.Windows.Forms.TextBox()
    Me.txFilter1 = New System.Windows.Forms.TextBox()
    Me.txFilter0 = New System.Windows.Forms.TextBox()
    Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
    Me.lbSpeed = New System.Windows.Forms.ToolStripStatusLabel()
    Me.Progressbar1 = New System.Windows.Forms.ToolStripProgressBar()
    Me.ProgressBar2 = New System.Windows.Forms.ProgressBar()
    Me.aView = New PhotoMud.ctlViewCompare()
    Me.StatusStrip1.SuspendLayout()
    Me.SuspendLayout()
    '
    'cmdHelp
    '
    Me.cmdHelp.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.cmdHelp.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.cmdHelp.Image = CType(resources.GetObject("cmdHelp.Image"), System.Drawing.Image)
    Me.cmdHelp.Location = New System.Drawing.Point(799, 521)
    Me.cmdHelp.Name = "cmdHelp"
    Me.cmdHelp.Size = New System.Drawing.Size(41, 39)
    Me.cmdHelp.TabIndex = 61
    Me.cmdHelp.TextAlign = System.Drawing.ContentAlignment.BottomCenter
    Me.ToolTip1.SetToolTip(Me.cmdHelp, "Help")
    Me.cmdHelp.UseVisualStyleBackColor = False
    '
    'cmdClearFilter
    '
    Me.cmdClearFilter.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.cmdClearFilter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.cmdClearFilter.Location = New System.Drawing.Point(516, 578)
    Me.cmdClearFilter.Name = "cmdClearFilter"
    Me.cmdClearFilter.Size = New System.Drawing.Size(101, 31)
    Me.cmdClearFilter.TabIndex = 57
    Me.cmdClearFilter.Text = "&Clear Filter"
    Me.ToolTip1.SetToolTip(Me.cmdClearFilter, "Clear the current filter")
    Me.cmdClearFilter.UseVisualStyleBackColor = False
    '
    'optSize7x7
    '
    Me.optSize7x7.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.optSize7x7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.optSize7x7.Location = New System.Drawing.Point(250, 525)
    Me.optSize7x7.Name = "optSize7x7"
    Me.optSize7x7.Size = New System.Drawing.Size(102, 19)
    Me.optSize7x7.TabIndex = 52
    Me.optSize7x7.TabStop = True
    Me.optSize7x7.Text = "7x7 filter"
    Me.ToolTip1.SetToolTip(Me.optSize7x7, "Filter size")
    Me.optSize7x7.UseVisualStyleBackColor = False
    '
    'cmdLoadFilter
    '
    Me.cmdLoadFilter.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.cmdLoadFilter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.cmdLoadFilter.Location = New System.Drawing.Point(516, 478)
    Me.cmdLoadFilter.Name = "cmdLoadFilter"
    Me.cmdLoadFilter.Size = New System.Drawing.Size(101, 31)
    Me.cmdLoadFilter.TabIndex = 55
    Me.cmdLoadFilter.Text = "&Load Filter"
    Me.ToolTip1.SetToolTip(Me.cmdLoadFilter, "Load a filter from disk")
    Me.cmdLoadFilter.UseVisualStyleBackColor = False
    '
    'cmdSaveFilter
    '
    Me.cmdSaveFilter.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.cmdSaveFilter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.cmdSaveFilter.Location = New System.Drawing.Point(516, 528)
    Me.cmdSaveFilter.Name = "cmdSaveFilter"
    Me.cmdSaveFilter.Size = New System.Drawing.Size(101, 31)
    Me.cmdSaveFilter.TabIndex = 56
    Me.cmdSaveFilter.Text = "Save &Filter"
    Me.ToolTip1.SetToolTip(Me.cmdSaveFilter, "Save a filter to disk")
    Me.cmdSaveFilter.UseVisualStyleBackColor = False
    '
    'cmbFilter
    '
    Me.cmbFilter.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.cmbFilter.BackColor = System.Drawing.SystemColors.Window
    Me.cmbFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.cmbFilter.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.cmbFilter.Location = New System.Drawing.Point(245, 435)
    Me.cmbFilter.Name = "cmbFilter"
    Me.cmbFilter.Size = New System.Drawing.Size(181, 25)
    Me.cmbFilter.TabIndex = 49
    Me.ToolTip1.SetToolTip(Me.cmbFilter, "Load a predefined filter")
    '
    'optSize5x5
    '
    Me.optSize5x5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.optSize5x5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.optSize5x5.Location = New System.Drawing.Point(250, 500)
    Me.optSize5x5.Name = "optSize5x5"
    Me.optSize5x5.Size = New System.Drawing.Size(102, 19)
    Me.optSize5x5.TabIndex = 51
    Me.optSize5x5.TabStop = True
    Me.optSize5x5.Text = "5x5 filter"
    Me.ToolTip1.SetToolTip(Me.optSize5x5, "Filter size")
    Me.optSize5x5.UseVisualStyleBackColor = False
    '
    'optSize3x3
    '
    Me.optSize3x3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.optSize3x3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.optSize3x3.Location = New System.Drawing.Point(250, 475)
    Me.optSize3x3.Name = "optSize3x3"
    Me.optSize3x3.Size = New System.Drawing.Size(102, 19)
    Me.optSize3x3.TabIndex = 50
    Me.optSize3x3.TabStop = True
    Me.optSize3x3.Text = "3x3 filter"
    Me.ToolTip1.SetToolTip(Me.optSize3x3, "Filter size")
    Me.optSize3x3.UseVisualStyleBackColor = False
    '
    'cmdStart
    '
    Me.cmdStart.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.cmdStart.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.cmdStart.Location = New System.Drawing.Point(656, 478)
    Me.cmdStart.Name = "cmdStart"
    Me.cmdStart.Size = New System.Drawing.Size(101, 31)
    Me.cmdStart.TabIndex = 58
    Me.cmdStart.Text = "S&tart"
    Me.ToolTip1.SetToolTip(Me.cmdStart, "Apply the filter to the photo")
    Me.cmdStart.UseVisualStyleBackColor = False
    '
    'txFilter46
    '
    Me.txFilter46.AcceptsReturn = True
    Me.txFilter46.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter46.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter46.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter46.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter46.Location = New System.Drawing.Point(140, 585)
    Me.txFilter46.MaxLength = 0
    Me.txFilter46.Name = "txFilter46"
    Me.txFilter46.Size = New System.Drawing.Size(31, 25)
    Me.txFilter46.TabIndex = 46
    Me.txFilter46.Text = "0"
    Me.txFilter46.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter47
    '
    Me.txFilter47.AcceptsReturn = True
    Me.txFilter47.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter47.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter47.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter47.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter47.Location = New System.Drawing.Point(170, 585)
    Me.txFilter47.MaxLength = 0
    Me.txFilter47.Name = "txFilter47"
    Me.txFilter47.Size = New System.Drawing.Size(31, 25)
    Me.txFilter47.TabIndex = 47
    Me.txFilter47.Text = "0"
    Me.txFilter47.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter48
    '
    Me.txFilter48.AcceptsReturn = True
    Me.txFilter48.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter48.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter48.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter48.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter48.Location = New System.Drawing.Point(200, 585)
    Me.txFilter48.MaxLength = 0
    Me.txFilter48.Name = "txFilter48"
    Me.txFilter48.Size = New System.Drawing.Size(31, 25)
    Me.txFilter48.TabIndex = 48
    Me.txFilter48.Text = "0"
    Me.txFilter48.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter42
    '
    Me.txFilter42.AcceptsReturn = True
    Me.txFilter42.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter42.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter42.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter42.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter42.Location = New System.Drawing.Point(20, 585)
    Me.txFilter42.MaxLength = 0
    Me.txFilter42.Name = "txFilter42"
    Me.txFilter42.Size = New System.Drawing.Size(31, 25)
    Me.txFilter42.TabIndex = 42
    Me.txFilter42.Text = "0"
    Me.txFilter42.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter43
    '
    Me.txFilter43.AcceptsReturn = True
    Me.txFilter43.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter43.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter43.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter43.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter43.Location = New System.Drawing.Point(50, 585)
    Me.txFilter43.MaxLength = 0
    Me.txFilter43.Name = "txFilter43"
    Me.txFilter43.Size = New System.Drawing.Size(31, 25)
    Me.txFilter43.TabIndex = 43
    Me.txFilter43.Text = "0"
    Me.txFilter43.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter44
    '
    Me.txFilter44.AcceptsReturn = True
    Me.txFilter44.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter44.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter44.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter44.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter44.Location = New System.Drawing.Point(80, 585)
    Me.txFilter44.MaxLength = 0
    Me.txFilter44.Name = "txFilter44"
    Me.txFilter44.Size = New System.Drawing.Size(31, 25)
    Me.txFilter44.TabIndex = 44
    Me.txFilter44.Text = "0"
    Me.txFilter44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter45
    '
    Me.txFilter45.AcceptsReturn = True
    Me.txFilter45.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter45.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter45.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter45.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter45.Location = New System.Drawing.Point(110, 585)
    Me.txFilter45.MaxLength = 0
    Me.txFilter45.Name = "txFilter45"
    Me.txFilter45.Size = New System.Drawing.Size(31, 25)
    Me.txFilter45.TabIndex = 45
    Me.txFilter45.Text = "0"
    Me.txFilter45.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter39
    '
    Me.txFilter39.AcceptsReturn = True
    Me.txFilter39.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter39.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter39.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter39.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter39.Location = New System.Drawing.Point(140, 560)
    Me.txFilter39.MaxLength = 0
    Me.txFilter39.Name = "txFilter39"
    Me.txFilter39.Size = New System.Drawing.Size(31, 25)
    Me.txFilter39.TabIndex = 39
    Me.txFilter39.Text = "0"
    Me.txFilter39.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter40
    '
    Me.txFilter40.AcceptsReturn = True
    Me.txFilter40.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter40.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter40.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter40.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter40.Location = New System.Drawing.Point(170, 560)
    Me.txFilter40.MaxLength = 0
    Me.txFilter40.Name = "txFilter40"
    Me.txFilter40.Size = New System.Drawing.Size(31, 25)
    Me.txFilter40.TabIndex = 40
    Me.txFilter40.Text = "0"
    Me.txFilter40.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter41
    '
    Me.txFilter41.AcceptsReturn = True
    Me.txFilter41.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter41.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter41.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter41.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter41.Location = New System.Drawing.Point(200, 560)
    Me.txFilter41.MaxLength = 0
    Me.txFilter41.Name = "txFilter41"
    Me.txFilter41.Size = New System.Drawing.Size(31, 25)
    Me.txFilter41.TabIndex = 41
    Me.txFilter41.Text = "0"
    Me.txFilter41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter35
    '
    Me.txFilter35.AcceptsReturn = True
    Me.txFilter35.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter35.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter35.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter35.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter35.Location = New System.Drawing.Point(20, 560)
    Me.txFilter35.MaxLength = 0
    Me.txFilter35.Name = "txFilter35"
    Me.txFilter35.Size = New System.Drawing.Size(31, 25)
    Me.txFilter35.TabIndex = 35
    Me.txFilter35.Text = "0"
    Me.txFilter35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter36
    '
    Me.txFilter36.AcceptsReturn = True
    Me.txFilter36.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter36.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter36.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter36.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter36.Location = New System.Drawing.Point(50, 560)
    Me.txFilter36.MaxLength = 0
    Me.txFilter36.Name = "txFilter36"
    Me.txFilter36.Size = New System.Drawing.Size(31, 25)
    Me.txFilter36.TabIndex = 36
    Me.txFilter36.Text = "0"
    Me.txFilter36.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter37
    '
    Me.txFilter37.AcceptsReturn = True
    Me.txFilter37.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter37.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter37.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter37.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter37.Location = New System.Drawing.Point(80, 560)
    Me.txFilter37.MaxLength = 0
    Me.txFilter37.Name = "txFilter37"
    Me.txFilter37.Size = New System.Drawing.Size(31, 25)
    Me.txFilter37.TabIndex = 37
    Me.txFilter37.Text = "0"
    Me.txFilter37.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter38
    '
    Me.txFilter38.AcceptsReturn = True
    Me.txFilter38.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter38.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter38.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter38.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter38.Location = New System.Drawing.Point(110, 560)
    Me.txFilter38.MaxLength = 0
    Me.txFilter38.Name = "txFilter38"
    Me.txFilter38.Size = New System.Drawing.Size(31, 25)
    Me.txFilter38.TabIndex = 38
    Me.txFilter38.Text = "0"
    Me.txFilter38.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter32
    '
    Me.txFilter32.AcceptsReturn = True
    Me.txFilter32.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter32.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter32.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter32.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter32.Location = New System.Drawing.Point(140, 535)
    Me.txFilter32.MaxLength = 0
    Me.txFilter32.Name = "txFilter32"
    Me.txFilter32.Size = New System.Drawing.Size(31, 25)
    Me.txFilter32.TabIndex = 32
    Me.txFilter32.Text = "0"
    Me.txFilter32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter33
    '
    Me.txFilter33.AcceptsReturn = True
    Me.txFilter33.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter33.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter33.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter33.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter33.Location = New System.Drawing.Point(170, 535)
    Me.txFilter33.MaxLength = 0
    Me.txFilter33.Name = "txFilter33"
    Me.txFilter33.Size = New System.Drawing.Size(31, 25)
    Me.txFilter33.TabIndex = 33
    Me.txFilter33.Text = "0"
    Me.txFilter33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter34
    '
    Me.txFilter34.AcceptsReturn = True
    Me.txFilter34.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter34.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter34.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter34.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter34.Location = New System.Drawing.Point(200, 535)
    Me.txFilter34.MaxLength = 0
    Me.txFilter34.Name = "txFilter34"
    Me.txFilter34.Size = New System.Drawing.Size(31, 25)
    Me.txFilter34.TabIndex = 34
    Me.txFilter34.Text = "0"
    Me.txFilter34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter28
    '
    Me.txFilter28.AcceptsReturn = True
    Me.txFilter28.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter28.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter28.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter28.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter28.Location = New System.Drawing.Point(20, 535)
    Me.txFilter28.MaxLength = 0
    Me.txFilter28.Name = "txFilter28"
    Me.txFilter28.Size = New System.Drawing.Size(31, 25)
    Me.txFilter28.TabIndex = 28
    Me.txFilter28.Text = "0"
    Me.txFilter28.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter29
    '
    Me.txFilter29.AcceptsReturn = True
    Me.txFilter29.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter29.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter29.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter29.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter29.Location = New System.Drawing.Point(50, 535)
    Me.txFilter29.MaxLength = 0
    Me.txFilter29.Name = "txFilter29"
    Me.txFilter29.Size = New System.Drawing.Size(31, 25)
    Me.txFilter29.TabIndex = 29
    Me.txFilter29.Text = "0"
    Me.txFilter29.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter30
    '
    Me.txFilter30.AcceptsReturn = True
    Me.txFilter30.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter30.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter30.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter30.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter30.Location = New System.Drawing.Point(80, 535)
    Me.txFilter30.MaxLength = 0
    Me.txFilter30.Name = "txFilter30"
    Me.txFilter30.Size = New System.Drawing.Size(31, 25)
    Me.txFilter30.TabIndex = 30
    Me.txFilter30.Text = "0"
    Me.txFilter30.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter31
    '
    Me.txFilter31.AcceptsReturn = True
    Me.txFilter31.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter31.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter31.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter31.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter31.Location = New System.Drawing.Point(110, 535)
    Me.txFilter31.MaxLength = 0
    Me.txFilter31.Name = "txFilter31"
    Me.txFilter31.Size = New System.Drawing.Size(31, 25)
    Me.txFilter31.TabIndex = 31
    Me.txFilter31.Text = "0"
    Me.txFilter31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter25
    '
    Me.txFilter25.AcceptsReturn = True
    Me.txFilter25.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter25.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter25.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter25.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter25.Location = New System.Drawing.Point(140, 510)
    Me.txFilter25.MaxLength = 0
    Me.txFilter25.Name = "txFilter25"
    Me.txFilter25.Size = New System.Drawing.Size(31, 25)
    Me.txFilter25.TabIndex = 25
    Me.txFilter25.Text = "0"
    Me.txFilter25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter26
    '
    Me.txFilter26.AcceptsReturn = True
    Me.txFilter26.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter26.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter26.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter26.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter26.Location = New System.Drawing.Point(170, 510)
    Me.txFilter26.MaxLength = 0
    Me.txFilter26.Name = "txFilter26"
    Me.txFilter26.Size = New System.Drawing.Size(31, 25)
    Me.txFilter26.TabIndex = 26
    Me.txFilter26.Text = "0"
    Me.txFilter26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter27
    '
    Me.txFilter27.AcceptsReturn = True
    Me.txFilter27.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter27.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter27.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter27.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter27.Location = New System.Drawing.Point(200, 510)
    Me.txFilter27.MaxLength = 0
    Me.txFilter27.Name = "txFilter27"
    Me.txFilter27.Size = New System.Drawing.Size(31, 25)
    Me.txFilter27.TabIndex = 27
    Me.txFilter27.Text = "0"
    Me.txFilter27.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'cmdOK
    '
    Me.cmdOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.cmdOK.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.cmdOK.Location = New System.Drawing.Point(656, 578)
    Me.cmdOK.Name = "cmdOK"
    Me.cmdOK.Size = New System.Drawing.Size(101, 31)
    Me.cmdOK.TabIndex = 60
    Me.cmdOK.Text = "&OK"
    Me.cmdOK.UseVisualStyleBackColor = False
    '
    'cmdCancel
    '
    Me.cmdCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.cmdCancel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.cmdCancel.Location = New System.Drawing.Point(656, 528)
    Me.cmdCancel.Name = "cmdCancel"
    Me.cmdCancel.Size = New System.Drawing.Size(101, 31)
    Me.cmdCancel.TabIndex = 59
    Me.cmdCancel.Text = "Cancel"
    Me.cmdCancel.UseVisualStyleBackColor = False
    '
    'txFilter24
    '
    Me.txFilter24.AcceptsReturn = True
    Me.txFilter24.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter24.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter24.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter24.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter24.Location = New System.Drawing.Point(110, 510)
    Me.txFilter24.MaxLength = 0
    Me.txFilter24.Name = "txFilter24"
    Me.txFilter24.Size = New System.Drawing.Size(31, 25)
    Me.txFilter24.TabIndex = 24
    Me.txFilter24.Text = "0"
    Me.txFilter24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter23
    '
    Me.txFilter23.AcceptsReturn = True
    Me.txFilter23.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter23.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter23.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter23.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter23.Location = New System.Drawing.Point(80, 510)
    Me.txFilter23.MaxLength = 0
    Me.txFilter23.Name = "txFilter23"
    Me.txFilter23.Size = New System.Drawing.Size(31, 25)
    Me.txFilter23.TabIndex = 23
    Me.txFilter23.Text = "0"
    Me.txFilter23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter22
    '
    Me.txFilter22.AcceptsReturn = True
    Me.txFilter22.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter22.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter22.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter22.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter22.Location = New System.Drawing.Point(50, 510)
    Me.txFilter22.MaxLength = 0
    Me.txFilter22.Name = "txFilter22"
    Me.txFilter22.Size = New System.Drawing.Size(31, 25)
    Me.txFilter22.TabIndex = 22
    Me.txFilter22.Text = "0"
    Me.txFilter22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter21
    '
    Me.txFilter21.AcceptsReturn = True
    Me.txFilter21.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter21.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter21.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter21.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter21.Location = New System.Drawing.Point(20, 510)
    Me.txFilter21.MaxLength = 0
    Me.txFilter21.Name = "txFilter21"
    Me.txFilter21.Size = New System.Drawing.Size(31, 25)
    Me.txFilter21.TabIndex = 21
    Me.txFilter21.Text = "0"
    Me.txFilter21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter20
    '
    Me.txFilter20.AcceptsReturn = True
    Me.txFilter20.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter20.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter20.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter20.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter20.Location = New System.Drawing.Point(200, 485)
    Me.txFilter20.MaxLength = 0
    Me.txFilter20.Name = "txFilter20"
    Me.txFilter20.Size = New System.Drawing.Size(31, 25)
    Me.txFilter20.TabIndex = 20
    Me.txFilter20.Text = "0"
    Me.txFilter20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter19
    '
    Me.txFilter19.AcceptsReturn = True
    Me.txFilter19.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter19.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter19.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter19.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter19.Location = New System.Drawing.Point(170, 485)
    Me.txFilter19.MaxLength = 0
    Me.txFilter19.Name = "txFilter19"
    Me.txFilter19.Size = New System.Drawing.Size(31, 25)
    Me.txFilter19.TabIndex = 19
    Me.txFilter19.Text = "0"
    Me.txFilter19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter18
    '
    Me.txFilter18.AcceptsReturn = True
    Me.txFilter18.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter18.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter18.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter18.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter18.Location = New System.Drawing.Point(140, 485)
    Me.txFilter18.MaxLength = 0
    Me.txFilter18.Name = "txFilter18"
    Me.txFilter18.Size = New System.Drawing.Size(31, 25)
    Me.txFilter18.TabIndex = 18
    Me.txFilter18.Text = "0"
    Me.txFilter18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter17
    '
    Me.txFilter17.AcceptsReturn = True
    Me.txFilter17.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter17.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter17.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter17.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter17.Location = New System.Drawing.Point(110, 485)
    Me.txFilter17.MaxLength = 0
    Me.txFilter17.Name = "txFilter17"
    Me.txFilter17.Size = New System.Drawing.Size(31, 25)
    Me.txFilter17.TabIndex = 17
    Me.txFilter17.Text = "0"
    Me.txFilter17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter16
    '
    Me.txFilter16.AcceptsReturn = True
    Me.txFilter16.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter16.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter16.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter16.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter16.Location = New System.Drawing.Point(80, 485)
    Me.txFilter16.MaxLength = 0
    Me.txFilter16.Name = "txFilter16"
    Me.txFilter16.Size = New System.Drawing.Size(31, 25)
    Me.txFilter16.TabIndex = 16
    Me.txFilter16.Text = "0"
    Me.txFilter16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter15
    '
    Me.txFilter15.AcceptsReturn = True
    Me.txFilter15.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter15.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter15.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter15.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter15.Location = New System.Drawing.Point(50, 485)
    Me.txFilter15.MaxLength = 0
    Me.txFilter15.Name = "txFilter15"
    Me.txFilter15.Size = New System.Drawing.Size(31, 25)
    Me.txFilter15.TabIndex = 15
    Me.txFilter15.Text = "0"
    Me.txFilter15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter14
    '
    Me.txFilter14.AcceptsReturn = True
    Me.txFilter14.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter14.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter14.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter14.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter14.Location = New System.Drawing.Point(20, 485)
    Me.txFilter14.MaxLength = 0
    Me.txFilter14.Name = "txFilter14"
    Me.txFilter14.Size = New System.Drawing.Size(31, 25)
    Me.txFilter14.TabIndex = 14
    Me.txFilter14.Text = "0"
    Me.txFilter14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter13
    '
    Me.txFilter13.AcceptsReturn = True
    Me.txFilter13.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter13.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter13.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter13.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter13.Location = New System.Drawing.Point(200, 460)
    Me.txFilter13.MaxLength = 0
    Me.txFilter13.Name = "txFilter13"
    Me.txFilter13.Size = New System.Drawing.Size(31, 25)
    Me.txFilter13.TabIndex = 13
    Me.txFilter13.Text = "0"
    Me.txFilter13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter12
    '
    Me.txFilter12.AcceptsReturn = True
    Me.txFilter12.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter12.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter12.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter12.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter12.Location = New System.Drawing.Point(170, 460)
    Me.txFilter12.MaxLength = 0
    Me.txFilter12.Name = "txFilter12"
    Me.txFilter12.Size = New System.Drawing.Size(31, 25)
    Me.txFilter12.TabIndex = 12
    Me.txFilter12.Text = "0"
    Me.txFilter12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter11
    '
    Me.txFilter11.AcceptsReturn = True
    Me.txFilter11.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter11.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter11.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter11.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter11.Location = New System.Drawing.Point(140, 460)
    Me.txFilter11.MaxLength = 0
    Me.txFilter11.Name = "txFilter11"
    Me.txFilter11.Size = New System.Drawing.Size(31, 25)
    Me.txFilter11.TabIndex = 11
    Me.txFilter11.Text = "0"
    Me.txFilter11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter10
    '
    Me.txFilter10.AcceptsReturn = True
    Me.txFilter10.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter10.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter10.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter10.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter10.Location = New System.Drawing.Point(110, 460)
    Me.txFilter10.MaxLength = 0
    Me.txFilter10.Name = "txFilter10"
    Me.txFilter10.Size = New System.Drawing.Size(31, 25)
    Me.txFilter10.TabIndex = 10
    Me.txFilter10.Text = "0"
    Me.txFilter10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter9
    '
    Me.txFilter9.AcceptsReturn = True
    Me.txFilter9.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter9.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter9.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter9.Location = New System.Drawing.Point(80, 460)
    Me.txFilter9.MaxLength = 0
    Me.txFilter9.Name = "txFilter9"
    Me.txFilter9.Size = New System.Drawing.Size(31, 25)
    Me.txFilter9.TabIndex = 9
    Me.txFilter9.Text = "0"
    Me.txFilter9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter8
    '
    Me.txFilter8.AcceptsReturn = True
    Me.txFilter8.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter8.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter8.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter8.Location = New System.Drawing.Point(50, 460)
    Me.txFilter8.MaxLength = 0
    Me.txFilter8.Name = "txFilter8"
    Me.txFilter8.Size = New System.Drawing.Size(31, 25)
    Me.txFilter8.TabIndex = 8
    Me.txFilter8.Text = "0"
    Me.txFilter8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter7
    '
    Me.txFilter7.AcceptsReturn = True
    Me.txFilter7.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter7.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter7.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter7.Location = New System.Drawing.Point(20, 460)
    Me.txFilter7.MaxLength = 0
    Me.txFilter7.Name = "txFilter7"
    Me.txFilter7.Size = New System.Drawing.Size(31, 25)
    Me.txFilter7.TabIndex = 7
    Me.txFilter7.Text = "0"
    Me.txFilter7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter6
    '
    Me.txFilter6.AcceptsReturn = True
    Me.txFilter6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter6.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter6.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter6.Location = New System.Drawing.Point(200, 435)
    Me.txFilter6.MaxLength = 0
    Me.txFilter6.Name = "txFilter6"
    Me.txFilter6.Size = New System.Drawing.Size(31, 25)
    Me.txFilter6.TabIndex = 6
    Me.txFilter6.Text = "0"
    Me.txFilter6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter5
    '
    Me.txFilter5.AcceptsReturn = True
    Me.txFilter5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter5.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter5.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter5.Location = New System.Drawing.Point(170, 435)
    Me.txFilter5.MaxLength = 0
    Me.txFilter5.Name = "txFilter5"
    Me.txFilter5.Size = New System.Drawing.Size(31, 25)
    Me.txFilter5.TabIndex = 5
    Me.txFilter5.Text = "0"
    Me.txFilter5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter4
    '
    Me.txFilter4.AcceptsReturn = True
    Me.txFilter4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter4.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter4.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter4.Location = New System.Drawing.Point(140, 435)
    Me.txFilter4.MaxLength = 0
    Me.txFilter4.Name = "txFilter4"
    Me.txFilter4.Size = New System.Drawing.Size(31, 25)
    Me.txFilter4.TabIndex = 4
    Me.txFilter4.Text = "0"
    Me.txFilter4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter3
    '
    Me.txFilter3.AcceptsReturn = True
    Me.txFilter3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter3.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter3.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter3.Location = New System.Drawing.Point(110, 435)
    Me.txFilter3.MaxLength = 0
    Me.txFilter3.Name = "txFilter3"
    Me.txFilter3.Size = New System.Drawing.Size(31, 25)
    Me.txFilter3.TabIndex = 3
    Me.txFilter3.Text = "0"
    Me.txFilter3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter2
    '
    Me.txFilter2.AcceptsReturn = True
    Me.txFilter2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter2.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter2.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter2.Location = New System.Drawing.Point(80, 435)
    Me.txFilter2.MaxLength = 0
    Me.txFilter2.Name = "txFilter2"
    Me.txFilter2.Size = New System.Drawing.Size(31, 25)
    Me.txFilter2.TabIndex = 2
    Me.txFilter2.Text = "0"
    Me.txFilter2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter1
    '
    Me.txFilter1.AcceptsReturn = True
    Me.txFilter1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter1.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter1.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter1.Location = New System.Drawing.Point(50, 435)
    Me.txFilter1.MaxLength = 0
    Me.txFilter1.Name = "txFilter1"
    Me.txFilter1.Size = New System.Drawing.Size(31, 25)
    Me.txFilter1.TabIndex = 1
    Me.txFilter1.Text = "0"
    Me.txFilter1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'txFilter0
    '
    Me.txFilter0.AcceptsReturn = True
    Me.txFilter0.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.txFilter0.BackColor = System.Drawing.SystemColors.Window
    Me.txFilter0.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFilter0.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txFilter0.Location = New System.Drawing.Point(20, 435)
    Me.txFilter0.MaxLength = 0
    Me.txFilter0.Name = "txFilter0"
    Me.txFilter0.Size = New System.Drawing.Size(31, 25)
    Me.txFilter0.TabIndex = 0
    Me.txFilter0.Text = "0"
    Me.txFilter0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'StatusStrip1
    '
    Me.StatusStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
    Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lbSpeed, Me.Progressbar1})
    Me.StatusStrip1.Location = New System.Drawing.Point(0, 645)
    Me.StatusStrip1.Name = "StatusStrip1"
    Me.StatusStrip1.Size = New System.Drawing.Size(973, 26)
    Me.StatusStrip1.TabIndex = 73
    Me.StatusStrip1.Text = "StatusStrip1"
    '
    'lbSpeed
    '
    Me.lbSpeed.Name = "lbSpeed"
    Me.lbSpeed.Size = New System.Drawing.Size(0, 21)
    '
    'Progressbar1
    '
    Me.Progressbar1.Name = "Progressbar1"
    Me.Progressbar1.Size = New System.Drawing.Size(200, 20)
    '
    'ProgressBar2
    '
    Me.ProgressBar2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.ProgressBar2.Location = New System.Drawing.Point(782, 594)
    Me.ProgressBar2.Name = "ProgressBar2"
    Me.ProgressBar2.Size = New System.Drawing.Size(169, 15)
    Me.ProgressBar2.TabIndex = 78
    Me.ProgressBar2.Visible = False
    '
    'aView
    '
    Me.aView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.aView.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
    Me.aView.Location = New System.Drawing.Point(3, 3)
    Me.aView.Name = "aView"
    Me.aView.NextButtons = False
    Me.aView.pCenter = New System.Drawing.Point(0, 0)
    Me.aView.SingleView = False
    Me.aView.Size = New System.Drawing.Size(967, 425)
    Me.aView.TabIndex = 79
    Me.aView.zoomFactor = 0.0R
    '
    'frmFilter
    '
    Me.AcceptButton = Me.cmdOK
    Me.BackColor = System.Drawing.SystemColors.Control
    Me.CancelButton = Me.cmdCancel
    Me.ClientSize = New System.Drawing.Size(973, 671)
    Me.Controls.Add(Me.aView)
    Me.Controls.Add(Me.ProgressBar2)
    Me.Controls.Add(Me.StatusStrip1)
    Me.Controls.Add(Me.cmdHelp)
    Me.Controls.Add(Me.cmdClearFilter)
    Me.Controls.Add(Me.optSize7x7)
    Me.Controls.Add(Me.txFilter46)
    Me.Controls.Add(Me.txFilter47)
    Me.Controls.Add(Me.txFilter48)
    Me.Controls.Add(Me.txFilter42)
    Me.Controls.Add(Me.txFilter43)
    Me.Controls.Add(Me.txFilter44)
    Me.Controls.Add(Me.txFilter45)
    Me.Controls.Add(Me.txFilter39)
    Me.Controls.Add(Me.txFilter40)
    Me.Controls.Add(Me.txFilter41)
    Me.Controls.Add(Me.txFilter35)
    Me.Controls.Add(Me.txFilter36)
    Me.Controls.Add(Me.txFilter37)
    Me.Controls.Add(Me.txFilter38)
    Me.Controls.Add(Me.txFilter32)
    Me.Controls.Add(Me.txFilter33)
    Me.Controls.Add(Me.txFilter34)
    Me.Controls.Add(Me.txFilter28)
    Me.Controls.Add(Me.txFilter29)
    Me.Controls.Add(Me.txFilter30)
    Me.Controls.Add(Me.txFilter31)
    Me.Controls.Add(Me.txFilter25)
    Me.Controls.Add(Me.txFilter26)
    Me.Controls.Add(Me.txFilter27)
    Me.Controls.Add(Me.cmdLoadFilter)
    Me.Controls.Add(Me.cmdSaveFilter)
    Me.Controls.Add(Me.cmdOK)
    Me.Controls.Add(Me.cmdCancel)
    Me.Controls.Add(Me.cmbFilter)
    Me.Controls.Add(Me.optSize5x5)
    Me.Controls.Add(Me.optSize3x3)
    Me.Controls.Add(Me.txFilter24)
    Me.Controls.Add(Me.txFilter23)
    Me.Controls.Add(Me.txFilter22)
    Me.Controls.Add(Me.txFilter21)
    Me.Controls.Add(Me.txFilter20)
    Me.Controls.Add(Me.txFilter19)
    Me.Controls.Add(Me.txFilter18)
    Me.Controls.Add(Me.txFilter17)
    Me.Controls.Add(Me.txFilter16)
    Me.Controls.Add(Me.txFilter15)
    Me.Controls.Add(Me.txFilter14)
    Me.Controls.Add(Me.txFilter13)
    Me.Controls.Add(Me.txFilter12)
    Me.Controls.Add(Me.txFilter11)
    Me.Controls.Add(Me.txFilter10)
    Me.Controls.Add(Me.txFilter9)
    Me.Controls.Add(Me.txFilter8)
    Me.Controls.Add(Me.txFilter7)
    Me.Controls.Add(Me.txFilter6)
    Me.Controls.Add(Me.txFilter5)
    Me.Controls.Add(Me.txFilter4)
    Me.Controls.Add(Me.txFilter3)
    Me.Controls.Add(Me.txFilter2)
    Me.Controls.Add(Me.txFilter1)
    Me.Controls.Add(Me.txFilter0)
    Me.Controls.Add(Me.cmdStart)
    Me.Cursor = System.Windows.Forms.Cursors.Default
    Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.Location = New System.Drawing.Point(3, 23)
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "frmFilter"
    Me.ShowInTaskbar = False
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
    Me.Text = "Filter Workshop"
    Me.StatusStrip1.ResumeLayout(False)
    Me.StatusStrip1.PerformLayout()
    Me.ResumeLayout(False)
    Me.PerformLayout()

End Sub
 Public WithEvents cmdHelp As System.Windows.Forms.Button
 Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
 Friend WithEvents lbSpeed As System.Windows.Forms.ToolStripStatusLabel
 Friend WithEvents Progressbar1 As System.Windows.Forms.ToolStripProgressBar
 Friend WithEvents ProgressBar2 As System.Windows.Forms.ProgressBar
 Friend WithEvents aView As PhotoMud.ctlViewCompare
#End Region
End Class