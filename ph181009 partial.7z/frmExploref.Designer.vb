<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmExploref
#Region "Windows Form Designer generated code "
  <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
    MyBase.New()
    'This is required by the Windows Form Designer.
    InitializeComponent()
  End Sub
  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
    If Disposing Then
      If Not components Is Nothing Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(Disposing)
  End Sub
  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer
  Public ToolTip1 As ToolTip
  Public WithEvents mnuFileOpen As ToolStripMenuItem
  Public WithEvents mnuFileOpenCurrent As ToolStripMenuItem
  Public WithEvents mnuFileSaveAs As ToolStripMenuItem
  Public WithEvents mnuFileNew As ToolStripMenuItem
  Public WithEvents fileline3 As ToolStripSeparator
  Public WithEvents mnuFileAcquire As ToolStripMenuItem
  Public WithEvents mnufileline12 As ToolStripSeparator
  Public WithEvents mnuFilePrint As ToolStripMenuItem
  Public WithEvents mnuFilePrintTagged As ToolStripMenuItem
  Public WithEvents fileline1 As ToolStripSeparator
  Public WithEvents mnuFileSend As ToolStripMenuItem
  Public WithEvents mnuFileSendTagged As ToolStripMenuItem
  Public WithEvents mnuFileLine4 As ToolStripSeparator
  Public WithEvents mnuFileCopy As ToolStripMenuItem
  Public WithEvents mnuFileConvert As ToolStripMenuItem
  Public WithEvents fileline5 As ToolStripSeparator
  Public WithEvents mnufileedit As ToolStripMenuItem
  Public WithEvents fileline2 As ToolStripSeparator
  Public WithEvents mnuFileExit As ToolStripMenuItem
  Public WithEvents mnuLine4 As ToolStripSeparator
  Public WithEvents mnuFile As ToolStripMenuItem
  Public WithEvents mnuEditCopyFile As ToolStripMenuItem
  Public WithEvents mnuEditCopyImage As ToolStripMenuItem
  Public WithEvents mnuEditCopyfilename As ToolStripMenuItem
  Public WithEvents mnuEditPaste As ToolStripMenuItem
  Public WithEvents mnuEditPasteNew As ToolStripMenuItem
  Public WithEvents editline7 As ToolStripSeparator
  Public WithEvents mnuEditDelete As ToolStripMenuItem
  Public WithEvents mnuEditRename As ToolStripMenuItem
  Public WithEvents editline3 As ToolStripSeparator
  Public WithEvents mnuEditRotateLeft As ToolStripMenuItem
  Public WithEvents mnuEditRotateRight As ToolStripMenuItem
  Public WithEvents mnuEditLine1 As ToolStripSeparator
  Public WithEvents mnuEditTagselectedfiles As ToolStripMenuItem
  Public WithEvents mnuEditSelecttagged As ToolStripMenuItem
  Public WithEvents mnuEditCleartags As ToolStripMenuItem
  Public WithEvents mnuEditTagPrevious As ToolStripMenuItem
  Public WithEvents editline2 As ToolStripSeparator
  Public WithEvents mnuEditSelectall As ToolStripMenuItem
  Public WithEvents mnuEdit As ToolStripMenuItem
  Public WithEvents mnuUpOneLevel As ToolStripMenuItem
  Public WithEvents mnuViewPrevious As ToolStripMenuItem
  Public WithEvents mnuViewNext As ToolStripMenuItem
  Public WithEvents mnuviewline3 As ToolStripSeparator
  Public WithEvents mnuViewFullscreen As ToolStripMenuItem
  Public WithEvents mnuViewToolbar As ToolStripMenuItem
  Public WithEvents mnuViewRefresh As ToolStripMenuItem
  Public WithEvents viewline1 As ToolStripSeparator
  Public WithEvents mnuViewStyleThumbnails As ToolStripMenuItem
  Public WithEvents mnuViewStyleDetails As ToolStripMenuItem
  Public WithEvents mnuView As ToolStripMenuItem
  Public WithEvents mnuToolsInfo As ToolStripMenuItem
  Public WithEvents mnuToolsComment As ToolStripMenuItem
  Public WithEvents toolsline1 As ToolStripSeparator
  Public WithEvents mnuToolsWebpage As ToolStripMenuItem
  Public WithEvents mnuToolsWallpaper As ToolStripMenuItem
  Public WithEvents mnuToolsSlideshow As ToolStripMenuItem
  Public WithEvents mnuToolsMergeColor As ToolStripMenuItem
  Public WithEvents toolsline9 As ToolStripSeparator
  Public WithEvents mnuToolsSearch As ToolStripMenuItem
  Public WithEvents mnuToolsPicSearch As ToolStripMenuItem
  Public WithEvents toolsline2 As ToolStripSeparator
  Public WithEvents mnuToolsAssoc As ToolStripMenuItem
  Public WithEvents mnuToolsToolbar As ToolStripMenuItem
  Public WithEvents mnuToolsOptions As ToolStripMenuItem
  Public WithEvents mnuTools As ToolStripMenuItem
  Public WithEvents mnuHelpHelpTopics As ToolStripMenuItem
  Public WithEvents mnuHelpHelpIndex As ToolStripMenuItem
  Public WithEvents mnuHelpTips As ToolStripMenuItem
  Public WithEvents helpLine1 As ToolStripSeparator
  Public WithEvents mnuHelpUpdate As ToolStripMenuItem
  Public WithEvents helpline2 As ToolStripSeparator
  Public WithEvents mnuHelpAbout As ToolStripMenuItem
  Public WithEvents mnuHelp As ToolStripMenuItem
  Public WithEvents mnu As MenuStrip
  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container()
    Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmExploref))
    Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
    Me.mnu = New System.Windows.Forms.MenuStrip()
    Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileOpen = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileOpenCurrent = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileSaveAs = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileNew = New System.Windows.Forms.ToolStripMenuItem()
    Me.fileline3 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuFileAcquire = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnufileline12 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuFilePrint = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFilePrintTagged = New System.Windows.Forms.ToolStripMenuItem()
    Me.fileline1 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuFileSend = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileSendTagged = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileLine4 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuFileCopy = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileConvert = New System.Windows.Forms.ToolStripMenuItem()
    Me.fileline5 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnufileedit = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileCloseAll = New System.Windows.Forms.ToolStripMenuItem()
    Me.fileline2 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuFileExit = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuFileMru1 = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileMru2 = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileMru3 = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileMru4 = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileMru5 = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileMru6 = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileMru7 = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileMru8 = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileMru9 = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuLine4 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuEdit = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditCopyFile = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditCopyImage = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditCopyfilename = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditPaste = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditPasteNew = New System.Windows.Forms.ToolStripMenuItem()
    Me.editline7 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuEditDelete = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditRename = New System.Windows.Forms.ToolStripMenuItem()
    Me.editline3 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuEditRotateLeft = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditRotateRight = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditLine1 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuEditTagselectedfiles = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditSelecttagged = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditCleartags = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditTagDirMatches = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditTagPrevious = New System.Windows.Forms.ToolStripMenuItem()
    Me.editline2 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuEditSelectall = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuView = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuUpOneLevel = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuViewPrevious = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuViewNext = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuviewline3 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuViewFullscreen = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuViewToolbar = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuViewRefresh = New System.Windows.Forms.ToolStripMenuItem()
    Me.viewline1 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuViewStyleThumbnails = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuViewStyleDetails = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuTools = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuToolsInfo = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuToolsComment = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuToolsBatchInfoCopy = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuToolsBugseparator = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuToolsBugPhotos = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuToolsLinkBugPhotos = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuToolsBugQuery = New System.Windows.Forms.ToolStripMenuItem()
    Me.toolsline1 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuToolsWebpage = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuToolsWallpaper = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuToolsSlideshow = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuToolsMergeColor = New System.Windows.Forms.ToolStripMenuItem()
    Me.toolsline9 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuToolsSearch = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuToolsPicSearch = New System.Windows.Forms.ToolStripMenuItem()
    Me.toolsline2 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuToolsAssoc = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuToolsFileFilter = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuToolsCalendar = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuToolsToolbar = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuToolsOptions = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuWindow = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuHelp = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuHelpHelpTopics = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuHelpHelpIndex = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuHelpTips = New System.Windows.Forms.ToolStripMenuItem()
    Me.helpLine1 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuHelpRegister = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuHelpUpdate = New System.Windows.Forms.ToolStripMenuItem()
    Me.helpline2 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuHelpAbout = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnxToolStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
    Me.mnxTSmallIcons = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnxTLargeIcons = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnxTCustomize = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnxTHideToolbar = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnxTHelp = New System.Windows.Forms.ToolStripMenuItem()
    Me.imgTreeView = New System.Windows.Forms.ImageList(Me.components)
    Me.mnxListView = New System.Windows.Forms.ContextMenuStrip(Me.components)
    Me.mnxFSaveAs = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnxFPrint = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnxFemail = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnxFMap = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnxFProperties = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnxFComment = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnxFOpen = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnxFCopyFile = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnxFCopyImage = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnxFCopyFilename = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnxFPasteFile = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnxFDelete = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnxFRename = New System.Windows.Forms.ToolStripMenuItem()
    Me.imgThumbnails = New System.Windows.Forms.ImageList(Me.components)
    Me.imgSmallIcons = New System.Windows.Forms.ImageList(Me.components)
    Me.bkgThumb = New System.ComponentModel.BackgroundWorker()
    Me.bkgPhotoDates = New System.ComponentModel.BackgroundWorker()
    Me.dirWatch = New System.IO.FileSystemWatcher()
    Me.Toolstrip1 = New System.Windows.Forms.ToolStrip()
    Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
    Me.ListView1 = New System.Windows.Forms.ListView()
    Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
    Me.lbStatus = New System.Windows.Forms.ToolStripStatusLabel()
    Me.txFolder = New System.Windows.Forms.TextBox()
    Me.TreeView = New System.Windows.Forms.TreeView()
    Me.mnxTreeview = New System.Windows.Forms.ContextMenuStrip(Me.components)
    Me.mnxTreeviewNewFolder = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnxTreeviewRenameFolder = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnxTreeviewDeleteFolder = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnxTreeviewRefresh = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnxTreeviewTagFolder = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnxTreeviewTagFolderSub = New System.Windows.Forms.ToolStripMenuItem()
    Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
    Me.mnxViewStyle = New System.Windows.Forms.ContextMenuStrip(Me.components)
    Me.mnxVThumbnails = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnxVDetails = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnu.SuspendLayout()
    Me.mnxToolStrip.SuspendLayout()
    Me.mnxListView.SuspendLayout()
    CType(Me.dirWatch, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SplitContainer2.Panel2.SuspendLayout()
    Me.SplitContainer2.SuspendLayout()
    Me.StatusStrip1.SuspendLayout()
    Me.mnxTreeview.SuspendLayout()
    CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SplitContainer1.Panel1.SuspendLayout()
    Me.SplitContainer1.Panel2.SuspendLayout()
    Me.SplitContainer1.SuspendLayout()
    Me.mnxViewStyle.SuspendLayout()
    Me.SuspendLayout()
    '
    'mnu
    '
    Me.mnu.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.mnu.ImageScalingSize = New System.Drawing.Size(20, 20)
    Me.mnu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuEdit, Me.mnuView, Me.mnuTools, Me.mnuWindow, Me.mnuHelp})
    Me.mnu.Location = New System.Drawing.Point(0, 0)
    Me.mnu.Name = "mnu"
    Me.mnu.Size = New System.Drawing.Size(977, 28)
    Me.mnu.TabIndex = 8
    '
    'mnuFile
    '
    Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileOpen, Me.mnuFileOpenCurrent, Me.mnuFileSaveAs, Me.mnuFileNew, Me.fileline3, Me.mnuFileAcquire, Me.mnufileline12, Me.mnuFilePrint, Me.mnuFilePrintTagged, Me.fileline1, Me.mnuFileSend, Me.mnuFileSendTagged, Me.mnuFileLine4, Me.mnuFileCopy, Me.mnuFileConvert, Me.fileline5, Me.mnufileedit, Me.mnuFileCloseAll, Me.fileline2, Me.mnuFileExit, Me.ToolStripSeparator1, Me.mnuFileMru1, Me.mnuFileMru2, Me.mnuFileMru3, Me.mnuFileMru4, Me.mnuFileMru5, Me.mnuFileMru6, Me.mnuFileMru7, Me.mnuFileMru8, Me.mnuFileMru9, Me.mnuLine4})
    Me.mnuFile.Name = "mnuFile"
    Me.mnuFile.Size = New System.Drawing.Size(40, 24)
    Me.mnuFile.Text = "&File"
    '
    'mnuFileOpen
    '
    Me.mnuFileOpen.Name = "mnuFileOpen"
    Me.mnuFileOpen.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
    Me.mnuFileOpen.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileOpen.Text = "&Open..."
    Me.mnuFileOpen.ToolTipText = "Open a file in Photo Mud Editor."
    '
    'mnuFileOpenCurrent
    '
    Me.mnuFileOpenCurrent.Name = "mnuFileOpenCurrent"
    Me.mnuFileOpenCurrent.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileOpenCurrent.Text = "Edit Se&lected File(s)"
    Me.mnuFileOpenCurrent.ToolTipText = "Edit the selected file(s) in Photo Mud Editor."
    '
    'mnuFileSaveAs
    '
    Me.mnuFileSaveAs.Name = "mnuFileSaveAs"
    Me.mnuFileSaveAs.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileSaveAs.Text = "Save &As..."
    Me.mnuFileSaveAs.ToolTipText = "Save the selected photo to a specified file."
    '
    'mnuFileNew
    '
    Me.mnuFileNew.Name = "mnuFileNew"
    Me.mnuFileNew.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
    Me.mnuFileNew.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileNew.Text = "&New..."
    Me.mnuFileNew.ToolTipText = "Create a new image in Photo Mud Editor."
    '
    'fileline3
    '
    Me.fileline3.Name = "fileline3"
    Me.fileline3.Size = New System.Drawing.Size(249, 6)
    '
    'mnuFileAcquire
    '
    Me.mnuFileAcquire.Name = "mnuFileAcquire"
    Me.mnuFileAcquire.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileAcquire.Text = "Scan..."
    Me.mnuFileAcquire.ToolTipText = "Scan a photo or document and load it into Photo Mud Editor."
    '
    'mnufileline12
    '
    Me.mnufileline12.Name = "mnufileline12"
    Me.mnufileline12.Size = New System.Drawing.Size(249, 6)
    '
    'mnuFilePrint
    '
    Me.mnuFilePrint.Name = "mnuFilePrint"
    Me.mnuFilePrint.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
    Me.mnuFilePrint.Size = New System.Drawing.Size(252, 26)
    Me.mnuFilePrint.Text = "&Print..."
    Me.mnuFilePrint.ToolTipText = "Print the selected photo(s)."
    '
    'mnuFilePrintTagged
    '
    Me.mnuFilePrintTagged.Name = "mnuFilePrintTagged"
    Me.mnuFilePrintTagged.Size = New System.Drawing.Size(252, 26)
    Me.mnuFilePrintTagged.Text = "Print &Tagged Photos..."
    Me.mnuFilePrintTagged.ToolTipText = "Print the tagged photos."
    '
    'fileline1
    '
    Me.fileline1.Name = "fileline1"
    Me.fileline1.Size = New System.Drawing.Size(249, 6)
    '
    'mnuFileSend
    '
    Me.mnuFileSend.Name = "mnuFileSend"
    Me.mnuFileSend.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileSend.Text = "E&mail Photo..."
    Me.mnuFileSend.ToolTipText = "Email the selected photo(s)."
    '
    'mnuFileSendTagged
    '
    Me.mnuFileSendTagged.Name = "mnuFileSendTagged"
    Me.mnuFileSendTagged.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileSendTagged.Text = "&Email Tagged Photos..."
    Me.mnuFileSendTagged.ToolTipText = "Email the tagged photos."
    '
    'mnuFileLine4
    '
    Me.mnuFileLine4.Name = "mnuFileLine4"
    Me.mnuFileLine4.Size = New System.Drawing.Size(249, 6)
    '
    'mnuFileCopy
    '
    Me.mnuFileCopy.Name = "mnuFileCopy"
    Me.mnuFileCopy.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileCopy.Text = "Copy &File to Disk..."
    Me.mnuFileCopy.ToolTipText = "Copy the selected file to another location on the hard drive."
    '
    'mnuFileConvert
    '
    Me.mnuFileConvert.Name = "mnuFileConvert"
    Me.mnuFileConvert.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileConvert.Text = "Con&vert Tagged Photos..."
    Me.mnuFileConvert.ToolTipText = "Convert photos from one format to another, optionally resizing them."
    '
    'fileline5
    '
    Me.fileline5.Name = "fileline5"
    Me.fileline5.Size = New System.Drawing.Size(249, 6)
    '
    'mnufileedit
    '
    Me.mnufileedit.Name = "mnufileedit"
    Me.mnufileedit.ShortcutKeys = System.Windows.Forms.Keys.F6
    Me.mnufileedit.Size = New System.Drawing.Size(252, 26)
    Me.mnufileedit.Text = "Photo Mud E&ditor"
    Me.mnufileedit.ToolTipText = "Show Photo Mud Editor."
    '
    'mnuFileCloseAll
    '
    Me.mnuFileCloseAll.Name = "mnuFileCloseAll"
    Me.mnuFileCloseAll.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileCloseAll.Text = "C&lose All"
    '
    'fileline2
    '
    Me.fileline2.Name = "fileline2"
    Me.fileline2.Size = New System.Drawing.Size(249, 6)
    '
    'mnuFileExit
    '
    Me.mnuFileExit.Name = "mnuFileExit"
    Me.mnuFileExit.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileExit.Text = "E&xit"
    Me.mnuFileExit.ToolTipText = "Exit the program."
    '
    'ToolStripSeparator1
    '
    Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
    Me.ToolStripSeparator1.Size = New System.Drawing.Size(249, 6)
    '
    'mnuFileMru1
    '
    Me.mnuFileMru1.MergeAction = System.Windows.Forms.MergeAction.Insert
    Me.mnuFileMru1.MergeIndex = 151
    Me.mnuFileMru1.Name = "mnuFileMru1"
    Me.mnuFileMru1.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileMru1.Text = "1"
    Me.mnuFileMru1.Visible = False
    '
    'mnuFileMru2
    '
    Me.mnuFileMru2.MergeAction = System.Windows.Forms.MergeAction.Insert
    Me.mnuFileMru2.MergeIndex = 152
    Me.mnuFileMru2.Name = "mnuFileMru2"
    Me.mnuFileMru2.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileMru2.Text = "2"
    Me.mnuFileMru2.Visible = False
    '
    'mnuFileMru3
    '
    Me.mnuFileMru3.MergeAction = System.Windows.Forms.MergeAction.Insert
    Me.mnuFileMru3.MergeIndex = 153
    Me.mnuFileMru3.Name = "mnuFileMru3"
    Me.mnuFileMru3.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileMru3.Text = "3"
    Me.mnuFileMru3.Visible = False
    '
    'mnuFileMru4
    '
    Me.mnuFileMru4.MergeAction = System.Windows.Forms.MergeAction.Insert
    Me.mnuFileMru4.MergeIndex = 154
    Me.mnuFileMru4.Name = "mnuFileMru4"
    Me.mnuFileMru4.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileMru4.Text = "4"
    Me.mnuFileMru4.Visible = False
    '
    'mnuFileMru5
    '
    Me.mnuFileMru5.MergeAction = System.Windows.Forms.MergeAction.Insert
    Me.mnuFileMru5.MergeIndex = 155
    Me.mnuFileMru5.Name = "mnuFileMru5"
    Me.mnuFileMru5.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileMru5.Text = "5"
    Me.mnuFileMru5.Visible = False
    '
    'mnuFileMru6
    '
    Me.mnuFileMru6.MergeAction = System.Windows.Forms.MergeAction.Insert
    Me.mnuFileMru6.MergeIndex = 156
    Me.mnuFileMru6.Name = "mnuFileMru6"
    Me.mnuFileMru6.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileMru6.Text = "6"
    Me.mnuFileMru6.Visible = False
    '
    'mnuFileMru7
    '
    Me.mnuFileMru7.MergeAction = System.Windows.Forms.MergeAction.Insert
    Me.mnuFileMru7.MergeIndex = 157
    Me.mnuFileMru7.Name = "mnuFileMru7"
    Me.mnuFileMru7.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileMru7.Text = "7"
    Me.mnuFileMru7.Visible = False
    '
    'mnuFileMru8
    '
    Me.mnuFileMru8.MergeAction = System.Windows.Forms.MergeAction.Insert
    Me.mnuFileMru8.MergeIndex = 158
    Me.mnuFileMru8.Name = "mnuFileMru8"
    Me.mnuFileMru8.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileMru8.Text = "8"
    Me.mnuFileMru8.Visible = False
    '
    'mnuFileMru9
    '
    Me.mnuFileMru9.MergeAction = System.Windows.Forms.MergeAction.Insert
    Me.mnuFileMru9.MergeIndex = 159
    Me.mnuFileMru9.Name = "mnuFileMru9"
    Me.mnuFileMru9.Size = New System.Drawing.Size(252, 26)
    Me.mnuFileMru9.Text = "9"
    Me.mnuFileMru9.Visible = False
    '
    'mnuLine4
    '
    Me.mnuLine4.Name = "mnuLine4"
    Me.mnuLine4.Size = New System.Drawing.Size(249, 6)
    '
    'mnuEdit
    '
    Me.mnuEdit.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuEditCopyFile, Me.mnuEditCopyImage, Me.mnuEditCopyfilename, Me.mnuEditPaste, Me.mnuEditPasteNew, Me.editline7, Me.mnuEditDelete, Me.mnuEditRename, Me.editline3, Me.mnuEditRotateLeft, Me.mnuEditRotateRight, Me.mnuEditLine1, Me.mnuEditTagselectedfiles, Me.mnuEditSelecttagged, Me.mnuEditCleartags, Me.mnuEditTagDirMatches, Me.mnuEditTagPrevious, Me.editline2, Me.mnuEditSelectall})
    Me.mnuEdit.Name = "mnuEdit"
    Me.mnuEdit.Size = New System.Drawing.Size(43, 24)
    Me.mnuEdit.Text = "&Edit"
    '
    'mnuEditCopyFile
    '
    Me.mnuEditCopyFile.Name = "mnuEditCopyFile"
    Me.mnuEditCopyFile.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
    Me.mnuEditCopyFile.Size = New System.Drawing.Size(323, 26)
    Me.mnuEditCopyFile.Text = "&Copy File to Clipboard"
    Me.mnuEditCopyFile.ToolTipText = "Copy the selected file to the Windows Clipboard."
    '
    'mnuEditCopyImage
    '
    Me.mnuEditCopyImage.Name = "mnuEditCopyImage"
    Me.mnuEditCopyImage.Size = New System.Drawing.Size(323, 26)
    Me.mnuEditCopyImage.Text = "Copy &Image  to Clipboard"
    Me.mnuEditCopyImage.ToolTipText = "Copy the selected file's image or picture to the Windows Clipboard."
    '
    'mnuEditCopyfilename
    '
    Me.mnuEditCopyfilename.Name = "mnuEditCopyfilename"
    Me.mnuEditCopyfilename.Size = New System.Drawing.Size(323, 26)
    Me.mnuEditCopyfilename.Text = "Copy File &Name to Clipboard"
    Me.mnuEditCopyfilename.ToolTipText = "Copy the selected file's name to the Window Clipboard."
    '
    'mnuEditPaste
    '
    Me.mnuEditPaste.Name = "mnuEditPaste"
    Me.mnuEditPaste.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
    Me.mnuEditPaste.Size = New System.Drawing.Size(323, 26)
    Me.mnuEditPaste.Text = "&Paste File"
    Me.mnuEditPaste.ToolTipText = "Paste the file in the clipboard to the currently selected folder."
    '
    'mnuEditPasteNew
    '
    Me.mnuEditPasteNew.Name = "mnuEditPasteNew"
    Me.mnuEditPasteNew.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Q), System.Windows.Forms.Keys)
    Me.mnuEditPasteNew.Size = New System.Drawing.Size(323, 26)
    Me.mnuEditPasteNew.Text = "Paste Image to New &Window"
    Me.mnuEditPasteNew.ToolTipText = "Paste the image in the clipboard into a new Photo Mud Editor window."
    '
    'editline7
    '
    Me.editline7.Name = "editline7"
    Me.editline7.Size = New System.Drawing.Size(320, 6)
    '
    'mnuEditDelete
    '
    Me.mnuEditDelete.Name = "mnuEditDelete"
    Me.mnuEditDelete.Size = New System.Drawing.Size(323, 26)
    Me.mnuEditDelete.Text = "&Delete File"
    Me.mnuEditDelete.ToolTipText = "Delete the currently selected file(s) from the hard drive."
    '
    'mnuEditRename
    '
    Me.mnuEditRename.Name = "mnuEditRename"
    Me.mnuEditRename.ShortcutKeys = System.Windows.Forms.Keys.F2
    Me.mnuEditRename.Size = New System.Drawing.Size(323, 26)
    Me.mnuEditRename.Text = "&Rename File"
    Me.mnuEditRename.ToolTipText = "Rename the selected file."
    '
    'editline3
    '
    Me.editline3.Name = "editline3"
    Me.editline3.Size = New System.Drawing.Size(320, 6)
    '
    'mnuEditRotateLeft
    '
    Me.mnuEditRotateLeft.Name = "mnuEditRotateLeft"
    Me.mnuEditRotateLeft.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.L), System.Windows.Forms.Keys)
    Me.mnuEditRotateLeft.Size = New System.Drawing.Size(323, 26)
    Me.mnuEditRotateLeft.Text = "Rotate &Left"
    Me.mnuEditRotateLeft.ToolTipText = "Rotate the selected photo 90� to the left."
    '
    'mnuEditRotateRight
    '
    Me.mnuEditRotateRight.Name = "mnuEditRotateRight"
    Me.mnuEditRotateRight.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.R), System.Windows.Forms.Keys)
    Me.mnuEditRotateRight.Size = New System.Drawing.Size(323, 26)
    Me.mnuEditRotateRight.Text = "Rotate &Right"
    Me.mnuEditRotateRight.ToolTipText = "Rotate the selected photo 90� to the right."
    '
    'mnuEditLine1
    '
    Me.mnuEditLine1.Name = "mnuEditLine1"
    Me.mnuEditLine1.Size = New System.Drawing.Size(320, 6)
    '
    'mnuEditTagselectedfiles
    '
    Me.mnuEditTagselectedfiles.Name = "mnuEditTagselectedfiles"
    Me.mnuEditTagselectedfiles.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.T), System.Windows.Forms.Keys)
    Me.mnuEditTagselectedfiles.Size = New System.Drawing.Size(323, 26)
    Me.mnuEditTagselectedfiles.Text = "&Tag Selected Photos"
    Me.mnuEditTagselectedfiles.ToolTipText = "Tag all selected files in the current folder."
    '
    'mnuEditSelecttagged
    '
    Me.mnuEditSelecttagged.Name = "mnuEditSelecttagged"
    Me.mnuEditSelecttagged.Size = New System.Drawing.Size(323, 26)
    Me.mnuEditSelecttagged.Text = "&Select Tagged Photos"
    Me.mnuEditSelecttagged.ToolTipText = "Select all tagged files in the current folder."
    '
    'mnuEditCleartags
    '
    Me.mnuEditCleartags.Name = "mnuEditCleartags"
    Me.mnuEditCleartags.Size = New System.Drawing.Size(323, 26)
    Me.mnuEditCleartags.Text = "C&lear All Tags"
    Me.mnuEditCleartags.ToolTipText = "Clear all tagged files."
    '
    'mnuEditTagDirMatches
    '
    Me.mnuEditTagDirMatches.Name = "mnuEditTagDirMatches"
    Me.mnuEditTagDirMatches.Size = New System.Drawing.Size(323, 26)
    Me.mnuEditTagDirMatches.Text = "Tag &Matching Photos"
    '
    'mnuEditTagPrevious
    '
    Me.mnuEditTagPrevious.Name = "mnuEditTagPrevious"
    Me.mnuEditTagPrevious.Size = New System.Drawing.Size(323, 26)
    Me.mnuEditTagPrevious.Text = "Set Previous Ta&gs"
    Me.mnuEditTagPrevious.ToolTipText = "Tag the files that were tagged before the previous operation."
    '
    'editline2
    '
    Me.editline2.Name = "editline2"
    Me.editline2.Size = New System.Drawing.Size(320, 6)
    '
    'mnuEditSelectall
    '
    Me.mnuEditSelectall.Name = "mnuEditSelectall"
    Me.mnuEditSelectall.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
    Me.mnuEditSelectall.Size = New System.Drawing.Size(323, 26)
    Me.mnuEditSelectall.Text = "Select &All"
    Me.mnuEditSelectall.ToolTipText = "Select all files in the current folder."
    '
    'mnuView
    '
    Me.mnuView.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuUpOneLevel, Me.mnuViewPrevious, Me.mnuViewNext, Me.mnuviewline3, Me.mnuViewFullscreen, Me.mnuViewToolbar, Me.mnuViewRefresh, Me.viewline1, Me.mnuViewStyleThumbnails, Me.mnuViewStyleDetails})
    Me.mnuView.Name = "mnuView"
    Me.mnuView.Size = New System.Drawing.Size(49, 24)
    Me.mnuView.Text = "&View"
    '
    'mnuUpOneLevel
    '
    Me.mnuUpOneLevel.Name = "mnuUpOneLevel"
    Me.mnuUpOneLevel.Size = New System.Drawing.Size(203, 26)
    Me.mnuUpOneLevel.Text = "&Up One Level"
    Me.mnuUpOneLevel.ToolTipText = "Move up to the next higher folder, the parent folder of the current folder."
    '
    'mnuViewPrevious
    '
    Me.mnuViewPrevious.Name = "mnuViewPrevious"
    Me.mnuViewPrevious.Size = New System.Drawing.Size(203, 26)
    Me.mnuViewPrevious.Text = "&Previous Folder"
    Me.mnuViewPrevious.ToolTipText = "Move to the previous folder."
    '
    'mnuViewNext
    '
    Me.mnuViewNext.Name = "mnuViewNext"
    Me.mnuViewNext.Size = New System.Drawing.Size(203, 26)
    Me.mnuViewNext.Text = "Ne&xt Folder"
    Me.mnuViewNext.ToolTipText = "Move to the next folder (after a move to the previous folder)."
    '
    'mnuviewline3
    '
    Me.mnuviewline3.Name = "mnuviewline3"
    Me.mnuviewline3.Size = New System.Drawing.Size(200, 6)
    '
    'mnuViewFullscreen
    '
    Me.mnuViewFullscreen.Name = "mnuViewFullscreen"
    Me.mnuViewFullscreen.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.M), System.Windows.Forms.Keys)
    Me.mnuViewFullscreen.Size = New System.Drawing.Size(203, 26)
    Me.mnuViewFullscreen.Text = "&Full Screen"
    Me.mnuViewFullscreen.ToolTipText = "View the selected photo on the full screen."
    '
    'mnuViewToolbar
    '
    Me.mnuViewToolbar.Checked = True
    Me.mnuViewToolbar.CheckState = System.Windows.Forms.CheckState.Checked
    Me.mnuViewToolbar.Name = "mnuViewToolbar"
    Me.mnuViewToolbar.Size = New System.Drawing.Size(203, 26)
    Me.mnuViewToolbar.Text = "&Show Toolbar"
    Me.mnuViewToolbar.ToolTipText = "Show or hide the toolbar."
    '
    'mnuViewRefresh
    '
    Me.mnuViewRefresh.Name = "mnuViewRefresh"
    Me.mnuViewRefresh.ShortcutKeys = System.Windows.Forms.Keys.F5
    Me.mnuViewRefresh.Size = New System.Drawing.Size(203, 26)
    Me.mnuViewRefresh.Text = "&Refresh"
    Me.mnuViewRefresh.ToolTipText = "Refresh the screen."
    '
    'viewline1
    '
    Me.viewline1.Name = "viewline1"
    Me.viewline1.Size = New System.Drawing.Size(200, 6)
    '
    'mnuViewStyleThumbnails
    '
    Me.mnuViewStyleThumbnails.Checked = True
    Me.mnuViewStyleThumbnails.CheckState = System.Windows.Forms.CheckState.Checked
    Me.mnuViewStyleThumbnails.Name = "mnuViewStyleThumbnails"
    Me.mnuViewStyleThumbnails.Size = New System.Drawing.Size(203, 26)
    Me.mnuViewStyleThumbnails.Text = "View &Thumbnails"
    Me.mnuViewStyleThumbnails.ToolTipText = "Select the Thumbnails view style."
    '
    'mnuViewStyleDetails
    '
    Me.mnuViewStyleDetails.Name = "mnuViewStyleDetails"
    Me.mnuViewStyleDetails.Size = New System.Drawing.Size(203, 26)
    Me.mnuViewStyleDetails.Text = "View &Details"
    Me.mnuViewStyleDetails.ToolTipText = "Select the Details view style."
    '
    'mnuTools
    '
    Me.mnuTools.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuToolsInfo, Me.mnuToolsComment, Me.mnuToolsBatchInfoCopy, Me.mnuToolsBugseparator, Me.mnuToolsBugPhotos, Me.mnuToolsLinkBugPhotos, Me.mnuToolsBugQuery, Me.toolsline1, Me.mnuToolsWebpage, Me.mnuToolsWallpaper, Me.mnuToolsSlideshow, Me.mnuToolsMergeColor, Me.toolsline9, Me.mnuToolsSearch, Me.mnuToolsPicSearch, Me.toolsline2, Me.mnuToolsAssoc, Me.mnuToolsFileFilter, Me.ToolStripSeparator8, Me.mnuToolsCalendar, Me.ToolStripSeparator9, Me.mnuToolsToolbar, Me.mnuToolsOptions})
    Me.mnuTools.Name = "mnuTools"
    Me.mnuTools.Size = New System.Drawing.Size(55, 24)
    Me.mnuTools.Text = "&Tools"
    '
    'mnuToolsInfo
    '
    Me.mnuToolsInfo.Name = "mnuToolsInfo"
    Me.mnuToolsInfo.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.I), System.Windows.Forms.Keys)
    Me.mnuToolsInfo.Size = New System.Drawing.Size(295, 26)
    Me.mnuToolsInfo.Text = "Photo &Information..."
    Me.mnuToolsInfo.ToolTipText = "Display information about a photo, including comments and camera settings. "
    '
    'mnuToolsComment
    '
    Me.mnuToolsComment.Name = "mnuToolsComment"
    Me.mnuToolsComment.Size = New System.Drawing.Size(295, 26)
    Me.mnuToolsComment.Text = "Enter Photo &Comments..."
    Me.mnuToolsComment.ToolTipText = "Enter photo comments to be saved with the file."
    '
    'mnuToolsBatchInfoCopy
    '
    Me.mnuToolsBatchInfoCopy.Name = "mnuToolsBatchInfoCopy"
    Me.mnuToolsBatchInfoCopy.Size = New System.Drawing.Size(295, 26)
    Me.mnuToolsBatchInfoCopy.Text = "Photo In&formation Batch Copy..."
    '
    'mnuToolsBugseparator
    '
    Me.mnuToolsBugseparator.Name = "mnuToolsBugseparator"
    Me.mnuToolsBugseparator.Size = New System.Drawing.Size(292, 6)
    '
    'mnuToolsBugPhotos
    '
    Me.mnuToolsBugPhotos.Name = "mnuToolsBugPhotos"
    Me.mnuToolsBugPhotos.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.G), System.Windows.Forms.Keys)
    Me.mnuToolsBugPhotos.Size = New System.Drawing.Size(295, 26)
    Me.mnuToolsBugPhotos.Text = "&Bug Data Entry"
    '
    'mnuToolsLinkBugPhotos
    '
    Me.mnuToolsLinkBugPhotos.Name = "mnuToolsLinkBugPhotos"
    Me.mnuToolsLinkBugPhotos.ShortcutKeys = System.Windows.Forms.Keys.F4
    Me.mnuToolsLinkBugPhotos.Size = New System.Drawing.Size(295, 26)
    Me.mnuToolsLinkBugPhotos.Text = "Lin&k Tagged Bug Photos"
    '
    'mnuToolsBugQuery
    '
    Me.mnuToolsBugQuery.Name = "mnuToolsBugQuery"
    Me.mnuToolsBugQuery.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F), System.Windows.Forms.Keys)
    Me.mnuToolsBugQuery.Size = New System.Drawing.Size(295, 26)
    Me.mnuToolsBugQuery.Text = "Bug &Query"
    '
    'toolsline1
    '
    Me.toolsline1.Name = "toolsline1"
    Me.toolsline1.Size = New System.Drawing.Size(292, 6)
    '
    'mnuToolsWebpage
    '
    Me.mnuToolsWebpage.Name = "mnuToolsWebpage"
    Me.mnuToolsWebpage.Size = New System.Drawing.Size(295, 26)
    Me.mnuToolsWebpage.Text = "Make Thumbnail Web &Page..."
    Me.mnuToolsWebpage.ToolTipText = "Make a web page out of selected or tagged photos."
    '
    'mnuToolsWallpaper
    '
    Me.mnuToolsWallpaper.Name = "mnuToolsWallpaper"
    Me.mnuToolsWallpaper.Size = New System.Drawing.Size(295, 26)
    Me.mnuToolsWallpaper.Text = "Set as &Wallpaper"
    Me.mnuToolsWallpaper.ToolTipText = "Set the current photo as Windows Wallpaper."
    '
    'mnuToolsSlideshow
    '
    Me.mnuToolsSlideshow.Name = "mnuToolsSlideshow"
    Me.mnuToolsSlideshow.Size = New System.Drawing.Size(295, 26)
    Me.mnuToolsSlideshow.Text = "&Slide Show..."
    Me.mnuToolsSlideshow.ToolTipText = "Show a slide show of selected or tagged photos."
    '
    'mnuToolsMergeColor
    '
    Me.mnuToolsMergeColor.Name = "mnuToolsMergeColor"
    Me.mnuToolsMergeColor.Size = New System.Drawing.Size(295, 26)
    Me.mnuToolsMergeColor.Text = "&Merge Color Separations..."
    Me.mnuToolsMergeColor.ToolTipText = "Merge color separations of a photo."
    '
    'toolsline9
    '
    Me.toolsline9.Name = "toolsline9"
    Me.toolsline9.Size = New System.Drawing.Size(292, 6)
    '
    'mnuToolsSearch
    '
    Me.mnuToolsSearch.Name = "mnuToolsSearch"
    Me.mnuToolsSearch.Size = New System.Drawing.Size(295, 26)
    Me.mnuToolsSearch.Text = "Search P&hoto Comments..."
    Me.mnuToolsSearch.ToolTipText = "Search Photo comments on the hard drive."
    '
    'mnuToolsPicSearch
    '
    Me.mnuToolsPicSearch.Name = "mnuToolsPicSearch"
    Me.mnuToolsPicSearch.Size = New System.Drawing.Size(295, 26)
    Me.mnuToolsPicSearch.Text = "Search for &Duplicates..."
    Me.mnuToolsPicSearch.ToolTipText = "Search for duplicate photos on the hard drive."
    '
    'toolsline2
    '
    Me.toolsline2.Name = "toolsline2"
    Me.toolsline2.Size = New System.Drawing.Size(292, 6)
    '
    'mnuToolsAssoc
    '
    Me.mnuToolsAssoc.Name = "mnuToolsAssoc"
    Me.mnuToolsAssoc.Size = New System.Drawing.Size(295, 26)
    Me.mnuToolsAssoc.Text = "&Associate File Types..."
    Me.mnuToolsAssoc.ToolTipText = "Select file types to be associated with Photo Mud."
    '
    'mnuToolsFileFilter
    '
    Me.mnuToolsFileFilter.Name = "mnuToolsFileFilter"
    Me.mnuToolsFileFilter.Size = New System.Drawing.Size(295, 26)
    Me.mnuToolsFileFilter.Text = "Select Photo File T&ypes..."
    Me.mnuToolsFileFilter.ToolTipText = "Select file types to be displayed in Photo Mud Explorer."
    '
    'ToolStripSeparator8
    '
    Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
    Me.ToolStripSeparator8.Size = New System.Drawing.Size(292, 6)
    '
    'mnuToolsCalendar
    '
    Me.mnuToolsCalendar.Name = "mnuToolsCalendar"
    Me.mnuToolsCalendar.Size = New System.Drawing.Size(295, 26)
    Me.mnuToolsCalendar.Text = "Print Ca&lendar..."
    Me.mnuToolsCalendar.ToolTipText = "Print a monthly calendar using selected photos."
    '
    'ToolStripSeparator9
    '
    Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
    Me.ToolStripSeparator9.Size = New System.Drawing.Size(292, 6)
    '
    'mnuToolsToolbar
    '
    Me.mnuToolsToolbar.Name = "mnuToolsToolbar"
    Me.mnuToolsToolbar.Size = New System.Drawing.Size(295, 26)
    Me.mnuToolsToolbar.Text = "Customi&ze Toolbar..."
    Me.mnuToolsToolbar.ToolTipText = "Select tools for the toolbar, and other toolbar options."
    '
    'mnuToolsOptions
    '
    Me.mnuToolsOptions.Name = "mnuToolsOptions"
    Me.mnuToolsOptions.Size = New System.Drawing.Size(295, 26)
    Me.mnuToolsOptions.Text = "&Options..."
    Me.mnuToolsOptions.ToolTipText = "Set Photo Mud options and preferences."
    '
    'mnuWindow
    '
    Me.mnuWindow.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator7})
    Me.mnuWindow.Name = "mnuWindow"
    Me.mnuWindow.Size = New System.Drawing.Size(70, 24)
    Me.mnuWindow.Text = "&Window"
    '
    'ToolStripSeparator7
    '
    Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
    Me.ToolStripSeparator7.Size = New System.Drawing.Size(63, 6)
    '
    'mnuHelp
    '
    Me.mnuHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuHelpHelpTopics, Me.mnuHelpHelpIndex, Me.mnuHelpTips, Me.helpLine1, Me.mnuHelpRegister, Me.mnuHelpUpdate, Me.helpline2, Me.mnuHelpAbout})
    Me.mnuHelp.Name = "mnuHelp"
    Me.mnuHelp.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F), System.Windows.Forms.Keys)
    Me.mnuHelp.Size = New System.Drawing.Size(48, 24)
    Me.mnuHelp.Text = "&Help"
    '
    'mnuHelpHelpTopics
    '
    Me.mnuHelpHelpTopics.Name = "mnuHelpHelpTopics"
    Me.mnuHelpHelpTopics.Size = New System.Drawing.Size(253, 26)
    Me.mnuHelpHelpTopics.Text = "&Help"
    Me.mnuHelpHelpTopics.ToolTipText = "Show the Help Contents."
    '
    'mnuHelpHelpIndex
    '
    Me.mnuHelpHelpIndex.Name = "mnuHelpHelpIndex"
    Me.mnuHelpHelpIndex.Size = New System.Drawing.Size(253, 26)
    Me.mnuHelpHelpIndex.Text = "Help Inde&x"
    Me.mnuHelpHelpIndex.ToolTipText = "Show the Help Index."
    '
    'mnuHelpTips
    '
    Me.mnuHelpTips.Name = "mnuHelpTips"
    Me.mnuHelpTips.Size = New System.Drawing.Size(253, 26)
    Me.mnuHelpTips.Text = "Show &Tips of the Day"
    Me.mnuHelpTips.ToolTipText = "Show the Photo Mud Tips."
    '
    'helpLine1
    '
    Me.helpLine1.Name = "helpLine1"
    Me.helpLine1.Size = New System.Drawing.Size(250, 6)
    '
    'mnuHelpRegister
    '
    Me.mnuHelpRegister.Name = "mnuHelpRegister"
    Me.mnuHelpRegister.Size = New System.Drawing.Size(253, 26)
    Me.mnuHelpRegister.Text = "&Register Photo Mud Online"
    Me.mnuHelpRegister.ToolTipText = "Go to the Photo Mud web site and register the program."
    Me.mnuHelpRegister.Visible = False
    '
    'mnuHelpUpdate
    '
    Me.mnuHelpUpdate.Name = "mnuHelpUpdate"
    Me.mnuHelpUpdate.Size = New System.Drawing.Size(253, 26)
    Me.mnuHelpUpdate.Text = "Check for &Updates Online"
    Me.mnuHelpUpdate.ToolTipText = "Go to the Photo Mud web site and check for updates."
    '
    'helpline2
    '
    Me.helpline2.Name = "helpline2"
    Me.helpline2.Size = New System.Drawing.Size(250, 6)
    '
    'mnuHelpAbout
    '
    Me.mnuHelpAbout.Name = "mnuHelpAbout"
    Me.mnuHelpAbout.Size = New System.Drawing.Size(253, 26)
    Me.mnuHelpAbout.Text = "&About Photo Mud"
    '
    'mnxToolStrip
    '
    Me.mnxToolStrip.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.mnxToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
    Me.mnxToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnxTSmallIcons, Me.mnxTLargeIcons, Me.ToolStripSeparator5, Me.mnxTCustomize, Me.mnxTHideToolbar, Me.ToolStripSeparator6, Me.mnxTHelp})
    Me.mnxToolStrip.Name = "mnuToolStrip"
    Me.mnxToolStrip.Size = New System.Drawing.Size(198, 126)
    '
    'mnxTSmallIcons
    '
    Me.mnxTSmallIcons.Name = "mnxTSmallIcons"
    Me.mnxTSmallIcons.Size = New System.Drawing.Size(197, 22)
    Me.mnxTSmallIcons.Text = "&Small Icons"
    '
    'mnxTLargeIcons
    '
    Me.mnxTLargeIcons.Name = "mnxTLargeIcons"
    Me.mnxTLargeIcons.Size = New System.Drawing.Size(197, 22)
    Me.mnxTLargeIcons.Text = "&Large Icons"
    '
    'ToolStripSeparator5
    '
    Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
    Me.ToolStripSeparator5.Size = New System.Drawing.Size(194, 6)
    '
    'mnxTCustomize
    '
    Me.mnxTCustomize.Name = "mnxTCustomize"
    Me.mnxTCustomize.Size = New System.Drawing.Size(197, 22)
    Me.mnxTCustomize.Text = "&Customize Toolbar"
    '
    'mnxTHideToolbar
    '
    Me.mnxTHideToolbar.CheckOnClick = True
    Me.mnxTHideToolbar.Name = "mnxTHideToolbar"
    Me.mnxTHideToolbar.Size = New System.Drawing.Size(197, 22)
    Me.mnxTHideToolbar.Text = "Hide &Toolbar"
    '
    'ToolStripSeparator6
    '
    Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
    Me.ToolStripSeparator6.Size = New System.Drawing.Size(194, 6)
    '
    'mnxTHelp
    '
    Me.mnxTHelp.Name = "mnxTHelp"
    Me.mnxTHelp.Size = New System.Drawing.Size(197, 22)
    Me.mnxTHelp.Text = "&Help"
    '
    'imgTreeView
    '
    Me.imgTreeView.ImageStream = CType(resources.GetObject("imgTreeView.ImageStream"), System.Windows.Forms.ImageListStreamer)
    Me.imgTreeView.TransparentColor = System.Drawing.Color.Transparent
    Me.imgTreeView.Images.SetKeyName(0, "ClosedFolder")
    Me.imgTreeView.Images.SetKeyName(1, "OpenFolder")
    '
    'mnxListView
    '
    Me.mnxListView.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.mnxListView.ImageScalingSize = New System.Drawing.Size(20, 20)
    Me.mnxListView.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnxFSaveAs, Me.mnxFPrint, Me.mnxFemail, Me.mnxFMap, Me.ToolStripSeparator2, Me.mnxFProperties, Me.mnxFComment, Me.ToolStripSeparator3, Me.mnxFOpen, Me.mnxFCopyFile, Me.mnxFCopyImage, Me.mnxFCopyFilename, Me.mnxFPasteFile, Me.ToolStripSeparator4, Me.mnxFDelete, Me.mnxFRename})
    Me.mnxListView.Name = "ContextMenuStrip1"
    Me.mnxListView.Size = New System.Drawing.Size(187, 308)
    '
    'mnxFSaveAs
    '
    Me.mnxFSaveAs.Name = "mnxFSaveAs"
    Me.mnxFSaveAs.Size = New System.Drawing.Size(186, 22)
    Me.mnxFSaveAs.Text = "Save &As"
    '
    'mnxFPrint
    '
    Me.mnxFPrint.Name = "mnxFPrint"
    Me.mnxFPrint.Size = New System.Drawing.Size(186, 22)
    Me.mnxFPrint.Text = "&Print"
    '
    'mnxFemail
    '
    Me.mnxFemail.Name = "mnxFemail"
    Me.mnxFemail.Size = New System.Drawing.Size(186, 22)
    Me.mnxFemail.Text = "e&Mail"
    '
    'mnxFMap
    '
    Me.mnxFMap.Name = "mnxFMap"
    Me.mnxFMap.Size = New System.Drawing.Size(186, 22)
    Me.mnxFMap.Text = "Sho&w on Map"
    '
    'ToolStripSeparator2
    '
    Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
    Me.ToolStripSeparator2.Size = New System.Drawing.Size(183, 6)
    '
    'mnxFProperties
    '
    Me.mnxFProperties.Name = "mnxFProperties"
    Me.mnxFProperties.Size = New System.Drawing.Size(186, 22)
    Me.mnxFProperties.Text = "Photo P&roperties"
    '
    'mnxFComment
    '
    Me.mnxFComment.Name = "mnxFComment"
    Me.mnxFComment.Size = New System.Drawing.Size(186, 22)
    Me.mnxFComment.Text = "&Enter Description"
    '
    'ToolStripSeparator3
    '
    Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
    Me.ToolStripSeparator3.Size = New System.Drawing.Size(183, 6)
    '
    'mnxFOpen
    '
    Me.mnxFOpen.Name = "mnxFOpen"
    Me.mnxFOpen.Size = New System.Drawing.Size(186, 22)
    Me.mnxFOpen.Text = "&Open"
    '
    'mnxFCopyFile
    '
    Me.mnxFCopyFile.Name = "mnxFCopyFile"
    Me.mnxFCopyFile.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
    Me.mnxFCopyFile.Size = New System.Drawing.Size(186, 22)
    Me.mnxFCopyFile.Text = "&Copy File"
    '
    'mnxFCopyImage
    '
    Me.mnxFCopyImage.Name = "mnxFCopyImage"
    Me.mnxFCopyImage.Size = New System.Drawing.Size(186, 22)
    Me.mnxFCopyImage.Text = "Copy &Image"
    '
    'mnxFCopyFilename
    '
    Me.mnxFCopyFilename.Name = "mnxFCopyFilename"
    Me.mnxFCopyFilename.Size = New System.Drawing.Size(186, 22)
    Me.mnxFCopyFilename.Text = "Copy &Filename"
    '
    'mnxFPasteFile
    '
    Me.mnxFPasteFile.Name = "mnxFPasteFile"
    Me.mnxFPasteFile.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
    Me.mnxFPasteFile.Size = New System.Drawing.Size(186, 22)
    Me.mnxFPasteFile.Text = "Pa&ste File"
    '
    'ToolStripSeparator4
    '
    Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
    Me.ToolStripSeparator4.Size = New System.Drawing.Size(183, 6)
    '
    'mnxFDelete
    '
    Me.mnxFDelete.Name = "mnxFDelete"
    Me.mnxFDelete.Size = New System.Drawing.Size(186, 22)
    Me.mnxFDelete.Text = "&Delete"
    '
    'mnxFRename
    '
    Me.mnxFRename.Name = "mnxFRename"
    Me.mnxFRename.Size = New System.Drawing.Size(186, 22)
    Me.mnxFRename.Text = "Rena&me"
    '
    'imgThumbnails
    '
    Me.imgThumbnails.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
    Me.imgThumbnails.ImageSize = New System.Drawing.Size(36, 36)
    Me.imgThumbnails.TransparentColor = System.Drawing.Color.Transparent
    '
    'imgSmallIcons
    '
    Me.imgSmallIcons.ImageStream = CType(resources.GetObject("imgSmallIcons.ImageStream"), System.Windows.Forms.ImageListStreamer)
    Me.imgSmallIcons.TransparentColor = System.Drawing.Color.Transparent
    Me.imgSmallIcons.Images.SetKeyName(0, "16uparrow.png")
    Me.imgSmallIcons.Images.SetKeyName(1, "16rightarrow.png")
    '
    'bkgThumb
    '
    '
    'bkgPhotoDates
    '
    '
    'dirWatch
    '
    Me.dirWatch.EnableRaisingEvents = True
    Me.dirWatch.SynchronizingObject = Me
    '
    'Toolstrip1
    '
    Me.Toolstrip1.ContextMenuStrip = Me.mnxToolStrip
    Me.Toolstrip1.Font = New System.Drawing.Font("Tahoma", 8.0!)
    Me.Toolstrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
    Me.Toolstrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
    Me.Toolstrip1.Location = New System.Drawing.Point(0, 28)
    Me.Toolstrip1.Name = "Toolstrip1"
    Me.Toolstrip1.Size = New System.Drawing.Size(977, 25)
    Me.Toolstrip1.TabIndex = 2
    '
    'SplitContainer2
    '
    Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
    Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
    Me.SplitContainer2.Name = "SplitContainer2"
    Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
    Me.SplitContainer2.Panel1MinSize = 0
    '
    'SplitContainer2.Panel2
    '
    Me.SplitContainer2.Panel2.Controls.Add(Me.ListView1)
    Me.SplitContainer2.Panel2.Controls.Add(Me.StatusStrip1)
    Me.SplitContainer2.Size = New System.Drawing.Size(695, 597)
    Me.SplitContainer2.SplitterDistance = 428
    Me.SplitContainer2.TabIndex = 12
    Me.SplitContainer2.TabStop = False
    '
    'ListView1
    '
    Me.ListView1.AllowColumnReorder = True
    Me.ListView1.CheckBoxes = True
    Me.ListView1.ContextMenuStrip = Me.mnxListView
    Me.ListView1.Dock = System.Windows.Forms.DockStyle.Fill
    Me.ListView1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.ListView1.HideSelection = False
    Me.ListView1.LabelEdit = True
    Me.ListView1.LargeImageList = Me.imgThumbnails
    Me.ListView1.Location = New System.Drawing.Point(0, 0)
    Me.ListView1.Name = "ListView1"
    Me.ListView1.Size = New System.Drawing.Size(695, 140)
    Me.ListView1.SmallImageList = Me.imgSmallIcons
    Me.ListView1.TabIndex = 0
    Me.ListView1.UseCompatibleStateImageBehavior = False
    '
    'StatusStrip1
    '
    Me.StatusStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
    Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lbStatus})
    Me.StatusStrip1.Location = New System.Drawing.Point(0, 140)
    Me.StatusStrip1.Name = "StatusStrip1"
    Me.StatusStrip1.Size = New System.Drawing.Size(695, 25)
    Me.StatusStrip1.SizingGrip = False
    Me.StatusStrip1.TabIndex = 1
    Me.StatusStrip1.Text = "StatusStrip1"
    '
    'lbStatus
    '
    Me.lbStatus.Name = "lbStatus"
    Me.lbStatus.Size = New System.Drawing.Size(29, 20)
    Me.lbStatus.Text = "     "
    '
    'txFolder
    '
    Me.txFolder.AcceptsReturn = True
    Me.txFolder.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
    Me.txFolder.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories
    Me.txFolder.BackColor = System.Drawing.SystemColors.Window
    Me.txFolder.Cursor = System.Windows.Forms.Cursors.IBeam
    Me.txFolder.Dock = System.Windows.Forms.DockStyle.Top
    Me.txFolder.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.txFolder.Location = New System.Drawing.Point(0, 0)
    Me.txFolder.MaxLength = 0
    Me.txFolder.Name = "txFolder"
    Me.txFolder.Size = New System.Drawing.Size(278, 25)
    Me.txFolder.TabIndex = 5
    '
    'TreeView
    '
    Me.TreeView.AllowDrop = True
    Me.TreeView.ContextMenuStrip = Me.mnxTreeview
    Me.TreeView.Dock = System.Windows.Forms.DockStyle.Fill
    Me.TreeView.Font = New System.Drawing.Font("Arial", 10.0!)
    Me.TreeView.HideSelection = False
    Me.TreeView.ImageIndex = 0
    Me.TreeView.ImageList = Me.imgTreeView
    Me.TreeView.LabelEdit = True
    Me.TreeView.Location = New System.Drawing.Point(0, 25)
    Me.TreeView.Margin = New System.Windows.Forms.Padding(4)
    Me.TreeView.Name = "TreeView"
    Me.TreeView.SelectedImageIndex = 0
    Me.TreeView.Size = New System.Drawing.Size(278, 572)
    Me.TreeView.StateImageList = Me.imgTreeView
    Me.TreeView.TabIndex = 6
    '
    'mnxTreeview
    '
    Me.mnxTreeview.ImageScalingSize = New System.Drawing.Size(20, 20)
    Me.mnxTreeview.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnxTreeviewNewFolder, Me.mnxTreeviewRenameFolder, Me.mnxTreeviewDeleteFolder, Me.mnxTreeviewRefresh, Me.ToolStripSeparator10, Me.mnxTreeviewTagFolder, Me.mnxTreeviewTagFolderSub})
    Me.mnxTreeview.Name = "mnxTreeview"
    Me.mnxTreeview.Size = New System.Drawing.Size(319, 154)
    '
    'mnxTreeviewNewFolder
    '
    Me.mnxTreeviewNewFolder.Name = "mnxTreeviewNewFolder"
    Me.mnxTreeviewNewFolder.Size = New System.Drawing.Size(318, 24)
    Me.mnxTreeviewNewFolder.Text = "Ne&w Folder"
    '
    'mnxTreeviewRenameFolder
    '
    Me.mnxTreeviewRenameFolder.Name = "mnxTreeviewRenameFolder"
    Me.mnxTreeviewRenameFolder.Size = New System.Drawing.Size(318, 24)
    Me.mnxTreeviewRenameFolder.Text = "Rena&me Folder"
    '
    'mnxTreeviewDeleteFolder
    '
    Me.mnxTreeviewDeleteFolder.Name = "mnxTreeviewDeleteFolder"
    Me.mnxTreeviewDeleteFolder.Size = New System.Drawing.Size(318, 24)
    Me.mnxTreeviewDeleteFolder.Text = "&Delete Folder"
    '
    'mnxTreeviewRefresh
    '
    Me.mnxTreeviewRefresh.Name = "mnxTreeviewRefresh"
    Me.mnxTreeviewRefresh.Size = New System.Drawing.Size(318, 24)
    Me.mnxTreeviewRefresh.Text = "&Refresh"
    '
    'ToolStripSeparator10
    '
    Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
    Me.ToolStripSeparator10.Size = New System.Drawing.Size(315, 6)
    '
    'mnxTreeviewTagFolder
    '
    Me.mnxTreeviewTagFolder.Name = "mnxTreeviewTagFolder"
    Me.mnxTreeviewTagFolder.Size = New System.Drawing.Size(318, 24)
    Me.mnxTreeviewTagFolder.Text = "Tag Photos in Folder"
    '
    'mnxTreeviewTagFolderSub
    '
    Me.mnxTreeviewTagFolderSub.Name = "mnxTreeviewTagFolderSub"
    Me.mnxTreeviewTagFolderSub.Size = New System.Drawing.Size(318, 24)
    Me.mnxTreeviewTagFolderSub.Text = "Tag Photos in Folder and Subfolders"
    '
    'SplitContainer1
    '
    Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
    Me.SplitContainer1.Location = New System.Drawing.Point(0, 53)
    Me.SplitContainer1.Name = "SplitContainer1"
    '
    'SplitContainer1.Panel1
    '
    Me.SplitContainer1.Panel1.Controls.Add(Me.TreeView)
    Me.SplitContainer1.Panel1.Controls.Add(Me.txFolder)
    '
    'SplitContainer1.Panel2
    '
    Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer2)
    Me.SplitContainer1.Size = New System.Drawing.Size(977, 597)
    Me.SplitContainer1.SplitterDistance = 278
    Me.SplitContainer1.TabIndex = 10
    Me.SplitContainer1.TabStop = False
    '
    'mnxViewStyle
    '
    Me.mnxViewStyle.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.mnxViewStyle.ImageScalingSize = New System.Drawing.Size(20, 20)
    Me.mnxViewStyle.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnxVThumbnails, Me.mnxVDetails})
    Me.mnxViewStyle.Name = "mnxViewStyle"
    Me.mnxViewStyle.Size = New System.Drawing.Size(151, 48)
    Me.mnxViewStyle.Text = "View Style"
    '
    'mnxVThumbnails
    '
    Me.mnxVThumbnails.Name = "mnxVThumbnails"
    Me.mnxVThumbnails.Size = New System.Drawing.Size(150, 22)
    Me.mnxVThumbnails.Text = "&Thumbnails"
    '
    'mnxVDetails
    '
    Me.mnxVDetails.Name = "mnxVDetails"
    Me.mnxVDetails.Size = New System.Drawing.Size(150, 22)
    Me.mnxVDetails.Text = "&Details"
    '
    'frmExploref
    '
    Me.AllowDrop = True
    Me.ClientSize = New System.Drawing.Size(977, 650)
    Me.Controls.Add(Me.SplitContainer1)
    Me.Controls.Add(Me.Toolstrip1)
    Me.Controls.Add(Me.mnu)
    Me.Cursor = System.Windows.Forms.Cursors.Default
    Me.Font = New System.Drawing.Font("Arial", 9.0!)
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.Location = New System.Drawing.Point(11, 41)
    Me.MainMenuStrip = Me.mnu
    Me.Name = "frmExploref"
    Me.Text = "Photo Mud Explorer"
    Me.mnu.ResumeLayout(False)
    Me.mnu.PerformLayout()
    Me.mnxToolStrip.ResumeLayout(False)
    Me.mnxListView.ResumeLayout(False)
    CType(Me.dirWatch, System.ComponentModel.ISupportInitialize).EndInit()
    Me.SplitContainer2.Panel2.ResumeLayout(False)
    Me.SplitContainer2.Panel2.PerformLayout()
    CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
    Me.SplitContainer2.ResumeLayout(False)
    Me.StatusStrip1.ResumeLayout(False)
    Me.StatusStrip1.PerformLayout()
    Me.mnxTreeview.ResumeLayout(False)
    Me.SplitContainer1.Panel1.ResumeLayout(False)
    Me.SplitContainer1.Panel1.PerformLayout()
    Me.SplitContainer1.Panel2.ResumeLayout(False)
    CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.SplitContainer1.ResumeLayout(False)
    Me.mnxViewStyle.ResumeLayout(False)
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Public WithEvents mnuFileMru9 As System.Windows.Forms.ToolStripMenuItem
  Public WithEvents mnuFileMru8 As System.Windows.Forms.ToolStripMenuItem
  Public WithEvents mnuFileMru7 As System.Windows.Forms.ToolStripMenuItem
  Public WithEvents mnuFileMru6 As System.Windows.Forms.ToolStripMenuItem
  Public WithEvents mnuFileMru5 As System.Windows.Forms.ToolStripMenuItem
  Public WithEvents mnuFileMru4 As System.Windows.Forms.ToolStripMenuItem
  Public WithEvents mnuFileMru3 As System.Windows.Forms.ToolStripMenuItem
  Public WithEvents mnuFileMru2 As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
  Public WithEvents mnuFileMru1 As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents imgThumbnails As System.Windows.Forms.ImageList
  Friend WithEvents imgSmallIcons As System.Windows.Forms.ImageList
  Friend WithEvents imgTreeView As System.Windows.Forms.ImageList
  Friend WithEvents bkgThumb As System.ComponentModel.BackgroundWorker
  Friend WithEvents bkgPhotoDates As System.ComponentModel.BackgroundWorker
  Friend WithEvents dirWatch As System.IO.FileSystemWatcher
  Friend WithEvents mnxToolStrip As System.Windows.Forms.ContextMenuStrip
  Friend WithEvents mnxListView As System.Windows.Forms.ContextMenuStrip
  Friend WithEvents mnxFSaveAs As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnxFPrint As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnxFemail As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnxFProperties As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents mnxFComment As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents mnxFOpen As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnxFCopyFile As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnxFCopyImage As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnxFCopyFilename As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnxFPasteFile As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents mnxFDelete As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnxFRename As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnxTSmallIcons As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnxTLargeIcons As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents mnxTCustomize As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnxTHideToolbar As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents mnxTHelp As System.Windows.Forms.ToolStripMenuItem
  Public WithEvents Toolstrip1 As System.Windows.Forms.ToolStrip
  Friend WithEvents mnuWindow As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
  Public WithEvents mnuToolsFileFilter As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
  Friend WithEvents TreeView As System.Windows.Forms.TreeView
  Public WithEvents txFolder As System.Windows.Forms.TextBox
  Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
  Friend WithEvents ListView1 As System.Windows.Forms.ListView
  Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
  Friend WithEvents lbStatus As System.Windows.Forms.ToolStripStatusLabel
  Friend WithEvents mnxViewStyle As System.Windows.Forms.ContextMenuStrip
  Friend WithEvents mnxVThumbnails As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnxVDetails As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuToolsCalendar As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents mnxTreeview As System.Windows.Forms.ContextMenuStrip
  Friend WithEvents mnxTreeviewNewFolder As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnxTreeviewRenameFolder As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnxTreeviewDeleteFolder As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnxTreeviewRefresh As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents mnxTreeviewTagFolder As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnxTreeviewTagFolderSub As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuFileCloseAll As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuToolsBatchInfoCopy As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuEditTagDirMatches As System.Windows.Forms.ToolStripMenuItem
  Public WithEvents mnuHelpRegister As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuToolsBugPhotos As System.Windows.Forms.ToolStripMenuItem
  Public WithEvents mnuToolsBugseparator As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents mnuToolsLinkBugPhotos As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuToolsBugQuery As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnxFMap As System.Windows.Forms.ToolStripMenuItem
#End Region
End Class